"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/provider-kit/index.ts
var index_exports = {};
__export(index_exports, {
  NativeTaskRunner: () => NativeTaskRunner,
  NativeTransportFacade: () => NativeTransportFacade,
  captureConfiguration: () => captureConfiguration,
  defaultHomes: () => defaultHomes,
  hashOk: () => hashOk,
  nativeEnvironment: () => nativeEnvironment,
  nativeHash: () => nativeHash,
  nativeIdOk: () => nativeIdOk,
  nativeLaunchArguments: () => nativeLaunchArguments,
  nativeTransportVersion: () => nativeTransportVersion,
  preflightNativeTransport: () => preflightNativeTransport,
  prepareNativeTask: () => prepareNativeTask,
  providerKitSchema: () => providerKitSchema,
  providerKitVersion: () => providerKitVersion,
  readNativeRepositoryIdentity: () => readNativeRepositoryIdentity,
  safeLocalSource: () => safeLocalSource,
  validateNativeSelection: () => validateNativeSelection,
  verifyNativeProjectScope: () => verifyNativeProjectScope
});
module.exports = __toCommonJS(index_exports);

// src/cockpit/configuration.ts
var fs5 = __toESM(require("node:fs/promises"));
var path6 = __toESM(require("node:path"));

// src/feeds/settings.ts
var fs2 = __toESM(require("fs"));
var os = __toESM(require("os"));
var path2 = __toESM(require("path"));

// src/util/redact.ts
var MARK = "[REDACTED]";
var NAME_CORE = "token|secret|passw(?:or)?d|pwd|passphrase|api[_-]?key|access[_-]?key|private[_-]?key|account[_-]?key|shared[_-]?access[_-]?(?:key|signature)|subscription[_-]?key|client[_-]?secret|credentials?|session[_-]?(?:id|token|key)|cookie|auth[_-]?(?:token|key|code)|signing[_-]?key|encryption[_-]?key|conn(?:ection)?[_-]?string|[_-]key";
var NAME = `[A-Za-z0-9_.-]{0,40}(?:${NAME_CORE})[A-Za-z0-9_.-]{0,40}`;
var NAME_RE = new RegExp(`^(?:${NAME})$`, "i");
var COUNT_NAME = /tokens|_count$/i;
var VALUE = `(\\\\"(?:(?!\\\\")[^\\n])*\\\\"|"(?:[^"\\\\\\n]|\\\\.)*"|'[^'\\n]*'|(?![{\\[])[^\\s,;}\\]&"'\\\\<>]+)`;
function keyValue(m, pre, name2, value) {
  if (COUNT_NAME.test(name2) && /^\\?["']?\d{1,12}\\?["']?$/.test(value)) return m;
  if (value.startsWith('\\"')) return `${pre}\\"${MARK}\\"`;
  if (value.startsWith('"')) return `${pre}"${MARK}"`;
  if (value.startsWith("'")) return `${pre}'${MARK}'`;
  return `${pre}${MARK}`;
}
var quoted = (v) => v.startsWith('"') ? `"${MARK}"` : v.startsWith("'") ? `'${MARK}'` : MARK;
var RULES = [
  // PEM private keys (RSA / EC / OPENSSH / ENCRYPTED / PGP ... BLOCK), real or JSON-escaped newlines; a block cut
  // by truncation (no END line) is redacted to the end of the text.
  { re: /-----BEGIN [A-Z0-9 ]{0,40}PRIVATE KEY[A-Z ]{0,10}-----[\s\S]*?(?:-----END [A-Z0-9 ]{0,40}PRIVATE KEY[A-Z ]{0,10}-----|$)/g },
  // AWS secret access key without a label, on the same line as an access key id or the word "aws".
  {
    re: /(\b(?:AKIA|ASIA)[0-9A-Z]{16}\b|\baws\b)([^\n]{0,160}?)(?<![A-Za-z0-9/+])([A-Za-z0-9/+]{40})(?![A-Za-z0-9/+=])/gi,
    to: (m, a, mid, s2) => /[A-Z]/.test(s2) && /[a-z]/.test(s2) ? `${a}${mid}${MARK}` : m
  },
  // Token formats.
  { re: /\bsk-ant-[A-Za-z0-9_-]{8,}/g },
  { re: /\b(?:sk|pk|rk)-[A-Za-z0-9_-]{12,}/g },
  // OpenAI (sk-, sk-proj-) and similar
  { re: /\b(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{10,}/g },
  // Stripe
  { re: /\bgithub_pat_[A-Za-z0-9_]{20,}/g },
  // GitHub fine-grained PAT
  { re: /\bgh[pousr]_[A-Za-z0-9]{20,}/g },
  // GitHub classic tokens
  { re: /\bglpat-[A-Za-z0-9_-]{16,}/g },
  // GitLab
  { re: /\bnpm_[A-Za-z0-9]{30,}/g },
  // npm
  { re: /\bAIza[0-9A-Za-z_-]{30,}/g },
  // Google API key
  { re: /\bya29\.[0-9A-Za-z_-]{20,}/g },
  // Google OAuth access token
  { re: /\bxox[abprse]-[A-Za-z0-9-]{10,}/g },
  // Slack
  { re: /\bxapp-[A-Za-z0-9-]{10,}/g },
  // Slack app token
  { re: /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g },
  // AWS access key id
  { re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/g },
  // JWT
  // Authorization headers ("Bearer xyz" / "Basic xyz" / quoted JSON value).
  {
    re: /\b((?:proxy-)?authorization["']?\s*[:=]\s*)("(?:[^"\\\n]|\\.)*"|'[^'\n]*'|[^\s,;"']+(?:[ \t]+[^\s,;"']+)?)/gi,
    to: (_m, pre, v) => `${pre}${quoted(v)}`
  },
  // Secret headers: curl -H "x-api-key: ...", Cookie: a=b; c=d, Ocp-Apim-Subscription-Key: ...
  {
    re: /\b((?:x-api-key|api-key|x-auth-token|x-goog-api-key|ocp-apim-subscription-key|set-cookie|cookie)[ \t]*:[ \t]*)(?!["'\\])[^\r\n"'\\]+/gi,
    to: (_m, pre) => `${pre}${MARK}`
  },
  { re: /\b(bearer|basic)\s+[A-Za-z0-9._~+/-]{12,}=*/gi, to: (_m, kind) => `${kind} ${MARK}` },
  // Query-string secrets, also after &amp; in HTML-encoded URLs.
  {
    re: /([?&](?:amp;)?(?:key|sig|signature|code|auth|password|pwd|passwd|token|access_token|refresh_token|id_token|api_key|apikey|secret|client_secret|x-amz-signature|x-amz-credential|x-amz-security-token)=)[^&\s#"'<>]+/gi,
    to: (_m, pre) => `${pre}${MARK}`
  },
  // Credentials in URLs; the password may contain '@' (user:p@ss@host): it runs to the last '@' before the host.
  { re: /(:\/\/[^/\s:@]+:)[^\s/]*@(?=[^@\s/]*(?:[/?#\s"'<>]|$))/g, to: (_m, pre) => `${pre}${MARK}@` },
  // name = value / "name": "value" / name: value (env, JSON, escaped JSON, YAML, TOML, connection strings).
  {
    re: new RegExp(`(?<![A-Za-z0-9_.-])((\\\\?["']?)(${NAME})\\\\?["']?(\\s*[:=]\\s*))${VALUE}`, "gi"),
    to: (m, pre, _q, name2, _sep, value) => keyValue(m, pre, name2, value)
  },
  // CLI flags: --password x, --token=x, -password x.
  { re: /(--?(?:password|passwd|pwd|token|secret|api-key|apikey|access-token|auth-token|client-secret)[= ])(\S+)/gi, to: (_m, pre) => `${pre}${MARK}` },
  // mysql-family -p<password> / -p <password> (only after a mysql command on the same line: -p means other things elsewhere).
  { re: /(\b(?:mysql|mysqldump|mysqladmin|mariadb|mariadb-dump)\b[^\n|;&]{0,200}?\s-p)([ \t]*)(?!-)(\S+)/g, to: (_m, pre, sp) => `${pre}${sp}${MARK}` }
];
function redact(text) {
  if (typeof text !== "string") return "";
  if (!text) return text;
  let out = text;
  for (const r of RULES) out = out.replace(r.re, (m, ...g) => r.to ? r.to(m, ...g) : MARK);
  for (const re of [
    /sk-[A-Za-z0-9_-]{20,}/g,
    /gh[pousr]_[A-Za-z0-9]{20,}/g,
    /github_pat_[A-Za-z0-9_]{20,}/g,
    /AKIA[0-9A-Z]{16}/g,
    /xox[baprs]-[A-Za-z0-9-]{10,}/g,
    /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/g
  ]) out = out.replace(re, MARK);
  return out;
}
function bounded(text, max = 100) {
  if (typeof text !== "string") return "";
  const one = redact(text).replace(/\s+/g, " ").trim();
  return one.length > max ? one.slice(0, max - 1) + "\u2026" : one;
}
var ENV_ALLOW_LIST = ["USERPROFILE", "HOME", "CODEX_HOME", "CLAUDE_CONFIG_DIR"];
function safeEnv(env = process.env) {
  const out = {};
  for (const k of ENV_ALLOW_LIST) if (typeof env[k] === "string") out[k] = env[k];
  return out;
}
var CREDENTIAL_FILE = /(^|[\\/])(\.credentials\.jsonl?|auth\.jsonl?|credentials(\.jsonl?)?|(?:tokens?|cookies?|secrets?)\.jsonl?|\.netrc|_netrc|\.npmrc|\.pypirc|\.git-credentials|\.env(\..*)?|id_(rsa|dsa|ecdsa|ed25519)|[^\\/]*\.(pem|key|pfx|p12))$/i;
function isCredentialPath(file) {
  return typeof file === "string" && CREDENTIAL_FILE.test(file.replace(/[\\/]+$/, ""));
}

// src/util/paths.ts
var fs = __toESM(require("fs"));
var path = __toESM(require("path"));
function isPlausibleLocalPath(p) {
  if (typeof p !== "string" || p.length === 0 || p.length > 1024) return false;
  if (p.includes("\0")) return false;
  if (/^\\\\[?.]\\/.test(p)) return false;
  if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(p)) return false;
  return path.isAbsolute(p);
}
function normalizeCase(p) {
  return process.platform === "win32" ? p.replace(/\//g, "\\").toLowerCase() : p;
}
function hasLinkedAncestor(file) {
  try {
    for (let p = file; p !== path.dirname(p); p = path.dirname(p)) if (fs.lstatSync(p).isSymbolicLink()) return true;
    return false;
  } catch {
    return true;
  }
}

// src/feeds/settings.ts
var LAYER_ORDER = ["managed", "local", "project", "user"];
var MAX_BYTES = 1e6;
var MAX_ROOTS = 60;
var MAX_LIST = 200;
var FORBIDDEN = /(^|[\\/])(\.credentials\.json|auth\.json|\.env(\..*)?|.*\.pem|.*\.key)$/i;
var SECRET_NAME = /(token|secret|passw|api_?key|apikey|access_?key|private|credential|auth|bearer|cookie|session_?id)/i;
function isForbidden(file) {
  return FORBIDDEN.test(file);
}
function defaultHomes() {
  const env = safeEnv();
  const home = env.USERPROFILE ?? env.HOME ?? os.homedir();
  return {
    claudeHome: env.CLAUDE_CONFIG_DIR ?? path2.join(home, ".claude"),
    codexHome: env.CODEX_HOME ?? path2.join(home, ".codex"),
    managedFile: process.platform === "win32" ? "C:\\Program Files\\ClaudeCode\\managed-settings.json" : process.platform === "darwin" ? "/Library/Application Support/ClaudeCode/managed-settings.json" : "/etc/claude-code/managed-settings.json"
  };
}
function stat(file) {
  if (hasLinkedAncestor(file)) return void 0;
  try {
    return fs2.statSync(file);
  } catch {
    return void 0;
  }
}
function readSmall(file) {
  if (isForbidden(file)) return { error: "not read (credential file)" };
  const st = stat(file);
  if (!st || !st.isFile()) return {};
  if (st.size > MAX_BYTES) return { st, error: `too large (${st.size} bytes)` };
  try {
    return { text: fs2.readFileSync(file, "utf8"), st };
  } catch (e) {
    return { st, error: String(e.message ?? e).slice(0, 120) };
  }
}
var str = (v, max = 80) => typeof v === "string" && v.trim() ? bounded(v, max) : void 0;
var strArr = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string").slice(0, MAX_LIST).map((x) => bounded(x, 140)) : [];
function parseJsonLoose(text) {
  try {
    return JSON.parse(text);
  } catch {
    const noComments = text.replace(/("(?:\\.|[^"\\])*")|\/\/[^\n]*|\/\*[\s\S]*?\*\//g, (m, s2) => s2 ?? "");
    return JSON.parse(noComments.replace(/,(\s*[}\]])/g, "$1"));
  }
}
function hooksOf(v) {
  const out = [];
  if (!v || typeof v !== "object") return out;
  for (const [event, groups] of Object.entries(v)) {
    if (!Array.isArray(groups)) continue;
    for (const g of groups) {
      if (!g || typeof g !== "object") continue;
      const matcher = str(g.matcher, 60) ?? "";
      const hs = g.hooks;
      for (const h of Array.isArray(hs) ? hs : []) {
        if (!h || typeof h !== "object") continue;
        const r = h;
        const args = Array.isArray(r.args) ? r.args.filter((a) => typeof a === "string").map((a) => /\s/.test(a) ? `"${a}"` : a) : [];
        const command = typeof r.command === "string" ? str([r.command, ...args].join(" "), 160) : void 0;
        out.push({ event: bounded(event, 40), matcher, type: str(r.type, 20) ?? "command", command: command ?? str(r.url, 160) ?? (typeof r.prompt === "string" ? "prompt" : ""), timeout: typeof r.timeout === "number" ? r.timeout : void 0 });
        if (out.length >= MAX_LIST) return out;
      }
    }
  }
  return out;
}
var KNOWN_CLAUDE = /* @__PURE__ */ new Set(["model", "effortLevel", "permissions", "hooks", "outputStyle", "statusLine", "env", "enabledPlugins", "apiKeyHelper"]);
function readClaudeLayer(kind, file, root) {
  const layer = { kind, root, file, exists: false, allow: [], deny: [], ask: [], additionalDirectories: 0, hooks: [], envNames: [], envHidden: 0, enabledPlugins: [], otherKeys: [], apiKeyHelper: false };
  const { text, st, error } = readSmall(file);
  if (st) Object.assign(layer, { exists: true, bytes: st.size, mtime: st.mtimeMs });
  if (error) layer.error = error;
  if (text === void 0) return layer;
  let j;
  try {
    j = parseJsonLoose(text);
  } catch (e) {
    layer.error = `invalid JSON: ${bounded(String(e.message ?? e), 80)}`;
    return layer;
  }
  if (!j || typeof j !== "object" || Array.isArray(j)) {
    layer.error = "not a JSON object";
    return layer;
  }
  const o = j;
  layer.model = str(o.model);
  layer.effortLevel = str(o.effortLevel, 20);
  layer.outputStyle = str(o.outputStyle, 40);
  const p = o.permissions && typeof o.permissions === "object" ? o.permissions : {};
  layer.defaultMode = str(p.defaultMode, 30);
  layer.allow = strArr(p.allow);
  layer.deny = strArr(p.deny);
  layer.ask = strArr(p.ask);
  layer.additionalDirectories = Array.isArray(p.additionalDirectories) ? p.additionalDirectories.length : 0;
  layer.hooks = hooksOf(o.hooks);
  const sl = o.statusLine;
  if (sl && typeof sl === "object") layer.statusLine = str(sl.command, 120) ? `command: ${str(sl.command, 120)}` : "set";
  else if (typeof sl === "string") layer.statusLine = bounded(sl, 120);
  if (o.env && typeof o.env === "object") {
    for (const k of Object.keys(o.env)) {
      if (SECRET_NAME.test(k)) layer.envHidden++;
      else if (layer.envNames.length < 50) layer.envNames.push(bounded(k, 60));
    }
  }
  if (o.enabledPlugins && typeof o.enabledPlugins === "object") {
    layer.enabledPlugins = Object.entries(o.enabledPlugins).filter(([, v]) => v !== false).map(([k]) => bounded(k, 80)).slice(0, MAX_LIST);
  }
  layer.apiKeyHelper = o.apiKeyHelper !== void 0;
  layer.otherKeys = Object.keys(o).filter((k) => !KNOWN_CLAUDE.has(k)).map((k) => SECRET_NAME.test(k) ? "(hidden key)" : bounded(k, 50)).slice(0, 60);
  return layer;
}
function frontMatter(text) {
  const m = /^\uFEFF?---\r?\n([\s\S]*?)\r?\n---/.exec(text);
  const out = {};
  if (!m) return out;
  const lines = m[1].split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const kv = /^([A-Za-z][\w-]*):\s*(.*)$/.exec(lines[i]);
    if (!kv) continue;
    let v = kv[2].trim();
    if (v === "" || v === "|" || v === ">" || v === "|-" || v === ">-") {
      const parts = [];
      while (i + 1 < lines.length && /^\s+\S/.test(lines[i + 1])) parts.push(lines[++i].trim().replace(/^-\s*/, ""));
      v = parts.join(v.startsWith("|") || v.startsWith(">") ? " " : ", ");
    }
    out[kv[1]] = v.replace(/^["']|["']$/g, "");
  }
  return out;
}
function listMd(dir, kind, scope, root, out) {
  let names;
  try {
    names = fs2.readdirSync(dir);
  } catch {
    return;
  }
  for (const n of names.sort()) {
    if (out.length >= 2e3) return;
    let file = path2.join(dir, n);
    const st = stat(file);
    if (!st) continue;
    if (kind === "skill") {
      if (!st.isDirectory()) continue;
      file = path2.join(file, "SKILL.md");
      if (!stat(file)) {
        let sub = [];
        try {
          sub = fs2.readdirSync(path2.join(dir, n));
        } catch {
        }
        for (const s2 of sub.slice(0, 50)) {
          const f = path2.join(dir, n, s2, "SKILL.md");
          if (stat(f)) pushMd(f, kind, scope, root, out, `${n}/${s2}`);
        }
        continue;
      }
      pushMd(file, kind, scope, root, out, n);
    } else if (st.isFile() && n.toLowerCase().endsWith(".md")) pushMd(file, kind, scope, root, out, n.replace(/\.md$/i, ""));
    else if (kind === "command" && st.isDirectory()) {
      let sub = [];
      try {
        sub = fs2.readdirSync(file);
      } catch {
      }
      for (const s2 of sub.filter((x) => x.toLowerCase().endsWith(".md")).slice(0, 100)) pushMd(path2.join(file, s2), kind, scope, root, out, `${n}:${s2.replace(/\.md$/i, "")}`);
    }
  }
}
function pushMd(file, kind, scope, root, out, fallback) {
  const { text, st } = readSmall(file);
  const fm = text ? frontMatter(text) : {};
  out.push({
    kind,
    scope,
    root,
    file,
    name: bounded(fm.name || fallback, 60),
    description: fm.description ? bounded(fm.description, 180) : void 0,
    model: fm.model ? bounded(fm.model, 40) : void 0,
    effort: fm.effort ? bounded(fm.effort, 20) : void 0,
    tools: fm.tools || fm["allowed-tools"] ? bounded(fm.tools || fm["allowed-tools"], 140) : void 0,
    mtime: st?.mtimeMs
  });
}
function memory(file, provider, scope, root, out) {
  const st = stat(file);
  if (!st || !st.isFile()) return;
  let lines = 0;
  if (st.size <= MAX_BYTES) {
    try {
      lines = fs2.readFileSync(file, "utf8").split("\n").length;
    } catch {
    }
  }
  out.push({ provider, scope, root, file, bytes: st.size, mtime: st.mtimeMs, lines });
}
function splitKey(s2) {
  const parts = [];
  let cur = "";
  let q;
  for (let i = 0; i < s2.length; i++) {
    const c = s2[i];
    if (q) {
      if (c === q) q = void 0;
      else if (c === "\\" && q === '"' && i + 1 < s2.length) cur += s2[++i];
      else cur += c;
    } else if (c === '"' || c === "'") q = c;
    else if (c === ".") {
      parts.push(cur.trim());
      cur = "";
    } else cur += c;
  }
  parts.push(cur.trim());
  return parts.filter((p) => p !== "");
}
function parseValue(s2, i) {
  while (s2[i] === " " || s2[i] === "	") i++;
  const c = s2[i];
  if (s2.startsWith('"""', i) || s2.startsWith("'''", i)) {
    const q = s2.slice(i, i + 3);
    const end = s2.indexOf(q, i + 3);
    const e = end < 0 ? s2.length : end;
    return [s2.slice(i + 3, e).replace(/^\r?\n/, ""), e + 3];
  }
  if (c === '"') {
    let out = "";
    let j = i + 1;
    for (; j < s2.length && s2[j] !== '"'; j++) {
      if (s2[j] === "\\" && j + 1 < s2.length) {
        const n = s2[++j];
        out += n === "n" ? "\n" : n === "t" ? "	" : n;
      } else out += s2[j];
    }
    return [out, j + 1];
  }
  if (c === "'") {
    const e = s2.indexOf("'", i + 1);
    return [s2.slice(i + 1, e < 0 ? s2.length : e), (e < 0 ? s2.length : e) + 1];
  }
  if (c === "[") {
    const arr = [];
    let j = i + 1;
    for (; ; ) {
      while (j < s2.length && /[\s,]/.test(s2[j])) j++;
      if (s2[j] === "#") {
        while (j < s2.length && s2[j] !== "\n") j++;
        continue;
      }
      if (j >= s2.length || s2[j] === "]") return [arr, j + 1];
      const [v2, n] = parseValue(s2, j);
      arr.push(v2);
      j = n;
    }
  }
  if (c === "{") {
    const obj2 = {};
    let j = i + 1;
    for (; ; ) {
      while (j < s2.length && /[\s,]/.test(s2[j])) j++;
      if (j >= s2.length || s2[j] === "}") return [obj2, j + 1];
      const eq = s2.indexOf("=", j);
      if (eq < 0) return [obj2, s2.length];
      const key = splitKey(s2.slice(j, eq));
      const [v2, n] = parseValue(s2, eq + 1);
      setPath(obj2, key, v2);
      j = n;
    }
  }
  const m = /^[^,\]}\r\n#]*/.exec(s2.slice(i))[0];
  const raw = m.trim();
  const v = raw === "true" ? true : raw === "false" ? false : /^[+-]?\d[\d_]*(\.\d+)?$/.test(raw) ? Number(raw.replace(/_/g, "")) : raw;
  return [v, i + m.length];
}
function setPath(obj2, keys, v) {
  let o = obj2;
  for (const k of keys.slice(0, -1)) {
    const cur = o[k];
    if (!cur || typeof cur !== "object" || Array.isArray(cur)) o[k] = {};
    o = o[k];
  }
  o[keys[keys.length - 1]] = v;
}
function parseToml(text) {
  const root = {};
  let table = [];
  let i = 0;
  const s2 = text.replace(/^\uFEFF/, "");
  while (i < s2.length) {
    while (i < s2.length && /\s/.test(s2[i])) i++;
    if (i >= s2.length) break;
    if (s2[i] === "#") {
      while (i < s2.length && s2[i] !== "\n") i++;
      continue;
    }
    if (s2[i] === "[") {
      const arrayTable = s2[i + 1] === "[";
      const end = s2.indexOf(arrayTable ? "]]" : "]", i);
      const header = s2.slice(i + (arrayTable ? 2 : 1), end < 0 ? s2.length : end);
      table = splitKey(header);
      if (arrayTable) table = [...table, String(Date.now() + i)];
      setPath(root, table, {});
      i = (end < 0 ? s2.length : end) + (arrayTable ? 2 : 1);
      continue;
    }
    const eq = s2.indexOf("=", i);
    const nl = s2.indexOf("\n", i);
    if (eq < 0 || nl >= 0 && nl < eq) {
      i = nl < 0 ? s2.length : nl + 1;
      continue;
    }
    const key = splitKey(s2.slice(i, eq));
    const [v, n] = parseValue(s2, eq + 1);
    if (key.length) setPath(root, [...table, ...key], v);
    i = n;
    while (i < s2.length && s2[i] !== "\n") i++;
  }
  return root;
}
var tstr = (v, max = 60) => typeof v === "string" && v ? bounded(v, max) : void 0;
var ttab = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var KNOWN_CODEX = /* @__PURE__ */ new Set(["model", "model_reasoning_effort", "approval_policy", "sandbox_mode", "sandbox", "service_tier", "profile", "profiles", "mcp_servers", "notify", "features", "projects", "plugins"]);
function readCodexConfig(file, scope, root) {
  const c = { scope, root, file, exists: false, profiles: [], mcpServers: [], notify: false, features: [], trustedProjects: 0, plugins: [], otherKeys: [] };
  const { text, st, error } = readSmall(file);
  if (st) Object.assign(c, { exists: true, bytes: st.size, mtime: st.mtimeMs });
  if (error) c.error = error;
  if (text === void 0) return c;
  let t;
  try {
    t = parseToml(text);
  } catch (e) {
    c.error = `unreadable TOML: ${bounded(String(e.message ?? e), 80)}`;
    return c;
  }
  c.model = tstr(t.model);
  c.effort = tstr(t.model_reasoning_effort, 20);
  c.approval = tstr(t.approval_policy, 30);
  c.sandbox = tstr(t.sandbox_mode, 30) ?? tstr(t.sandbox, 30);
  c.serviceTier = tstr(t.service_tier, 20);
  c.profile = tstr(t.profile, 40);
  for (const [name2, p] of Object.entries(ttab(t.profiles)).slice(0, 50)) {
    const q = ttab(p);
    c.profiles.push({ name: bounded(name2, 40), model: tstr(q.model), effort: tstr(q.model_reasoning_effort, 20), approval: tstr(q.approval_policy, 30), sandbox: tstr(q.sandbox_mode, 30) ?? tstr(q.sandbox, 30) });
  }
  c.mcpServers = Object.keys(ttab(t.mcp_servers)).slice(0, MAX_LIST).map((k) => bounded(k, 50));
  c.notify = Array.isArray(t.notify) ? t.notify.length > 0 : t.notify !== void 0 && t.notify !== "" && t.notify !== false;
  c.features = Object.entries(ttab(t.features)).filter(([, v]) => typeof v === "boolean").map(([k, v]) => ({ name: bounded(k, 40), on: v === true })).slice(0, 60);
  c.trustedProjects = Object.values(ttab(t.projects)).filter((p) => ttab(p).trust_level === "trusted").length;
  c.plugins = Object.entries(ttab(t.plugins)).map(([k, v]) => ({ name: bounded(k, 60), on: ttab(v).enabled !== false })).slice(0, 80);
  c.otherKeys = Object.keys(t).filter((k) => !KNOWN_CODEX.has(k)).map((k) => SECRET_NAME.test(k) ? "(hidden key)" : bounded(k, 40)).slice(0, 40);
  return c;
}
function collectSettings(input) {
  const homeKey = normalizeCase(path2.dirname(input.claudeHome));
  const roots = [];
  const seen = /* @__PURE__ */ new Set();
  for (const r of input.roots) {
    if (!isPlausibleLocalPath(r)) continue;
    const k = normalizeCase(path2.resolve(r));
    if (seen.has(k) || k === homeKey) continue;
    seen.add(k);
    if (!stat(r)?.isDirectory()) continue;
    roots.push({ path: r, name: path2.basename(r) || r });
    if (roots.length >= MAX_ROOTS) break;
  }
  const layers = [];
  if (input.managedFile) layers.push(readClaudeLayer("managed", input.managedFile));
  layers.push(readClaudeLayer("user", path2.join(input.claudeHome, "settings.json")));
  for (const r of roots) {
    layers.push(readClaudeLayer("project", path2.join(r.path, ".claude", "settings.json"), r.path));
    layers.push(readClaudeLayer("local", path2.join(r.path, ".claude", "settings.local.json"), r.path));
  }
  const items = [];
  const scan = (base, scope, root) => {
    listMd(path2.join(base, "agents"), "agent", scope, root, items);
    listMd(path2.join(base, "skills"), "skill", scope, root, items);
    listMd(path2.join(base, "commands"), "command", scope, root, items);
    listMd(path2.join(base, "output-styles"), "output-style", scope, root, items);
  };
  scan(input.claudeHome, "user");
  for (const r of roots) scan(path2.join(r.path, ".claude"), "project", r.path);
  const mem = [];
  memory(path2.join(input.claudeHome, "CLAUDE.md"), "claude", "user", void 0, mem);
  memory(path2.join(input.codexHome, "AGENTS.md"), "codex", "user", void 0, mem);
  for (const r of roots) {
    memory(path2.join(r.path, "CLAUDE.md"), "claude", "project", r.path, mem);
    memory(path2.join(r.path, ".claude", "CLAUDE.md"), "claude", "project", r.path, mem);
    memory(path2.join(r.path, "CLAUDE.local.md"), "claude", "project", r.path, mem);
    memory(path2.join(r.path, "AGENTS.md"), "codex", "project", r.path, mem);
  }
  const codex = [readCodexConfig(path2.join(input.codexHome, "config.toml"), "user")];
  for (const r of roots) {
    const f = path2.join(r.path, ".codex", "config.toml");
    if (stat(f)) codex.push(readCodexConfig(f, "project", r.path));
  }
  const files = [...layers.filter((l) => l.exists).map((l) => l.file), ...items.map((i) => i.file), ...mem.map((m) => m.file), ...codex.filter((c) => c.exists).map((c) => c.file)].filter((f) => !isForbidden(f));
  return { at: input.now ?? Date.now(), claudeHome: input.claudeHome, codexHome: input.codexHome, roots, layers, items, memory: mem, codex, files };
}
function layersFor(report, root) {
  const k = root ? normalizeCase(root) : void 0;
  return report.layers.filter((l) => l.exists && !l.error && (l.kind === "managed" || l.kind === "user" || k !== void 0 && l.root !== void 0 && normalizeCase(l.root) === k)).sort((a, b) => LAYER_ORDER.indexOf(a.kind) - LAYER_ORDER.indexOf(b.kind));
}
function effective(layers, key) {
  const set = layers.filter((l) => l[key] !== void 0);
  const win = set[0];
  return { value: win?.[key], layer: win?.kind, file: win?.file, shadowed: set.slice(1).map((l) => ({ layer: l.kind, value: l[key] })) };
}
function mergedRules(layers) {
  const u = (f) => new Set(layers.flatMap(f)).size;
  return { allow: u((l) => l.allow), deny: u((l) => l.deny), ask: u((l) => l.ask), hooks: layers.reduce((n, l) => n + l.hooks.length, 0) };
}

// src/feeds/catalog.ts
var fs4 = __toESM(require("fs"));
var path4 = __toESM(require("path"));

// src/git/git.ts
var fs3 = __toESM(require("fs"));
var path3 = __toESM(require("path"));
var HARDEN = ["-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", "-c", "core.quotepath=off", "-c", "diff.external=", "-c", "core.pager=cat", "-c", "credential.helper=", "--no-optional-locks", "--no-pager"];
var exeCache = /* @__PURE__ */ new Map();
function findExe(name2, pathVar, platform = process.platform) {
  if (!/^[A-Za-z0-9][\w.\-]*$/.test(name2)) return void 0;
  const win = platform === "win32";
  const p = win ? path3.win32 : path3.posix;
  const exts = win ? /\.(exe|com)$/i.test(name2) ? [""] : [".exe", ".com"] : [""];
  for (const raw of (pathVar ?? "").split(win ? ";" : ":")) {
    const dir = raw.trim().replace(/^"(.*)"$/, "$1");
    if (!dir || (win ? !/^(?:[A-Za-z]:[\\/]|\\\\[^\\/])/.test(dir) : !p.isAbsolute(dir))) continue;
    for (const ext of exts) {
      const f = p.join(dir, name2 + ext);
      try {
        if (!fs3.statSync(f).isFile()) continue;
        if (!win) fs3.accessSync(f, fs3.constants.X_OK);
        return f;
      } catch {
      }
    }
    if (win && NPM_NATIVE[name2] && fs3.existsSync(p.join(dir, name2 + ".cmd"))) {
      for (const rel of NPM_NATIVE[name2]) {
        const f = p.join(dir, "node_modules", rel);
        try {
          if (fs3.statSync(f).isFile()) return f;
        } catch {
        }
      }
    }
  }
  return void 0;
}
var NPM_NATIVE = {
  codex: [["x64", "x86_64"], ["arm64", "aarch64"]].map(([a, t]) => `@openai/codex/node_modules/@openai/codex-win32-${a}/vendor/${t}-pc-windows-msvc/bin/codex.exe`)
};
function resolveExe(name2) {
  if (exeCache.has(name2)) return exeCache.get(name2);
  const key = Object.keys(process.env).find((k) => k.toUpperCase() === "PATH");
  const exe = findExe(name2, key ? process.env[key] : void 0);
  exeCache.set(name2, exe);
  return exe;
}

// src/feeds/catalog.ts
var MAX_BYTES2 = 1e6;
var MAX_JSON_BYTES = 8e6;
var MAX_ITEMS = 4e3;
var MAX_PLUGINS = 300;
var SECRET_NAME2 = /(token|secret|passw|api_?key|apikey|access_?key|private|credential|auth|bearer|cookie|session_?id|helper)/i;
var SKIP_DIR = /^(secrets?|node_modules|\.git|credentials?)$/i;
var fsp = fs4.promises;
async function stat2(file) {
  if (hasLinkedAncestor(file)) return void 0;
  try {
    return await fsp.stat(file);
  } catch {
    return void 0;
  }
}
async function dirs(dir) {
  if (hasLinkedAncestor(dir)) return [];
  try {
    return (await fsp.readdir(dir, { withFileTypes: true })).filter((e) => (e.isDirectory() || e.isSymbolicLink()) && !SKIP_DIR.test(e.name)).map((e) => e.name).sort();
  } catch {
    return [];
  }
}
async function filesIn(dir, re) {
  if (hasLinkedAncestor(dir)) return [];
  try {
    return (await fsp.readdir(dir, { withFileTypes: true })).filter((e) => e.isFile() && re.test(e.name)).map((e) => e.name).sort();
  } catch {
    return [];
  }
}
async function readText(file, max = MAX_BYTES2) {
  if (isForbidden(file)) return void 0;
  const st = await stat2(file);
  if (!st || !st.isFile() || st.size > max) return void 0;
  try {
    return await fsp.readFile(file, "utf8");
  } catch {
    return void 0;
  }
}
async function readHead(file, max = 16384) {
  if (isForbidden(file)) return void 0;
  let fh;
  try {
    fh = await fsp.open(file, "r");
    const buf = Buffer.alloc(max);
    const { bytesRead } = await fh.read(buf, 0, max, 0);
    return buf.subarray(0, bytesRead).toString("utf8");
  } catch {
    return void 0;
  } finally {
    if (fh) await fh.close().catch(() => void 0);
  }
}
function parseJsonObject(t) {
  try {
    const j = JSON.parse(t.replace(/^\uFEFF/, ""));
    return j && typeof j === "object" && !Array.isArray(j) ? j : void 0;
  } catch {
    try {
      const noComments = t.replace(/("(?:\\.|[^"\\])*")|\/\/[^\n]*|\/\*[\s\S]*?\*\//g, (m, s2) => s2 ?? "").replace(/,(\s*[}\]])/g, "$1");
      const j = JSON.parse(noComments);
      return j && typeof j === "object" && !Array.isArray(j) ? j : void 0;
    } catch {
      return void 0;
    }
  }
}
async function readJson(file, max = MAX_BYTES2) {
  const t = await readText(file, max);
  return t === void 0 ? void 0 : parseJsonObject(t);
}
var obj = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var s = (v, max = 80) => typeof v === "string" && v.trim() ? bounded(v, max) : void 0;
async function countFiles(dir, depth = 4, cap = 500) {
  let n = 0;
  const walk = async (d, left) => {
    let es;
    try {
      es = await fsp.readdir(d, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of es) {
      if (n >= cap) return;
      if (e.isFile()) n++;
      else if (e.isDirectory() && left > 0 && !SKIP_DIR.test(e.name)) await walk(path4.join(d, e.name), left - 1);
    }
  };
  await walk(dir, depth);
  return n;
}
function programOf(command) {
  if (typeof command !== "string" || !command.trim()) return "";
  const words = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let m;
  while ((m = re.exec(command.trim())) && words.length < 2) words.push(m[1] ?? m[2] ?? m[3]);
  const base = (w) => w.replace(/[\\/]+$/, "").split(/[\\/]/).pop() ?? w;
  const prog = base(words[0] ?? "");
  const second = words[1] && /\.(py|js|mjs|cjs|ts|ps1|sh|bash|cmd|bat|rb|pl)$/i.test(words[1]) && !/^-/.test(words[1]) ? base(words[1]) : "";
  return bounded([prog, second].filter(Boolean).join(" "), 60);
}
function headingsOf(text, max = 40) {
  const out = [];
  let fence = false;
  for (const line of text.split(/\r?\n/)) {
    if (/^\s*(```|~~~)/.test(line)) fence = !fence;
    if (fence) continue;
    const m = /^(#{1,3})\s+(.+?)\s*#*\s*$/.exec(line);
    if (m) out.push(`${"  ".repeat(m[1].length - 1)}${bounded(m[2], 90)}`);
    if (out.length >= max) break;
  }
  return out;
}
async function pushItem(out, file, kind, c, fallback, files) {
  if (out.length >= MAX_ITEMS) return;
  const text = await readHead(file);
  const fm = text ? frontMatter(text) : {};
  out.push({
    provider: c.provider,
    kind,
    source: c.source,
    plugin: c.plugin,
    active: c.active,
    root: c.root,
    file,
    name: bounded(fm.name || fallback, 70),
    description: fm.description ? bounded(fm.description, 220) : void 0,
    model: fm.model ? bounded(fm.model, 40) : void 0,
    effort: fm.effort ? bounded(fm.effort, 20) : void 0,
    tools: fm.tools || fm["allowed-tools"] ? bounded(fm.tools || fm["allowed-tools"], 160) : void 0,
    argumentHint: fm["argument-hint"] ? bounded(fm["argument-hint"], 80) : void 0,
    files
  });
}
async function scanSkills(dir, c, out) {
  let n = 0;
  for (const d of await dirs(dir)) {
    if (d.startsWith(".")) continue;
    const f = path4.join(dir, d, "SKILL.md");
    if ((await stat2(f))?.isFile()) {
      await pushItem(out, f, "skill", c, d, c.active ? await countFiles(path4.join(dir, d)) : void 0);
      n++;
      continue;
    }
    for (const sub of (await dirs(path4.join(dir, d))).slice(0, 60)) {
      const g = path4.join(dir, d, sub, "SKILL.md");
      if ((await stat2(g))?.isFile()) {
        await pushItem(out, g, "skill", c, `${d}/${sub}`, c.active ? await countFiles(path4.join(dir, d, sub)) : void 0);
        n++;
      }
    }
  }
  return n;
}
async function scanMd(dir, kind, c, out, ns = "", depth = 3) {
  let n = 0;
  for (const f of await filesIn(dir, /\.md$/i)) {
    if (/^readme\.md$/i.test(f)) continue;
    const base = f.replace(/\.md$/i, "");
    await pushItem(out, path4.join(dir, f), kind, c, ns ? `${ns}:${base}` : base);
    n++;
  }
  if (depth > 0) for (const d of (await dirs(dir)).slice(0, 80)) n += await scanMd(path4.join(dir, d), kind, c, out, ns ? `${ns}:${d}` : d, depth - 1);
  return n;
}
async function scanClaudeDir(base, c, out) {
  const skills = await scanSkills(path4.join(base, "skills"), c, out);
  const agents = await scanMd(path4.join(base, "agents"), "agent", c, out, "", 1);
  const commands = await scanMd(path4.join(base, "commands"), "command", c, out);
  const styles = await scanMd(path4.join(base, "output-styles"), "output-style", c, out, "", 0);
  return { skills, agents, commands, styles };
}
function hooksFrom(v, base, out) {
  let n = 0;
  for (const [event, groups] of Object.entries(obj(v))) {
    if (!Array.isArray(groups)) continue;
    for (const g of groups) {
      const go = obj(g);
      const matcher = s(go.matcher, 60) ?? "";
      for (const h of Array.isArray(go.hooks) ? go.hooks : []) {
        const r = obj(h);
        const type = s(r.type, 20) ?? "command";
        const program = typeof r.command === "string" ? programOf(r.command) : type === "http" || r.url ? "http" : typeof r.prompt === "string" ? "prompt" : "";
        out.push({ ...base, event: bounded(event, 40), matcher, type, program, timeout: typeof r.timeout === "number" ? r.timeout : void 0 });
        n++;
        if (out.length >= MAX_ITEMS) return n;
      }
    }
  }
  return n;
}
function mcpFrom(v, base, out) {
  let n = 0;
  for (const [name2, cfg] of Object.entries(obj(v)).slice(0, 200)) {
    const c = obj(cfg);
    const transport = s(c.type, 20) ?? s(c.transport, 20) ?? (typeof c.command === "string" ? "stdio" : typeof c.url === "string" ? "http" : "?");
    out.push({ ...base, name: SECRET_NAME2.test(name2) && name2.length > 40 ? "(hidden name)" : bounded(name2, 60), transport, program: typeof c.command === "string" ? programOf(c.command).split(" ")[0] : void 0 });
    n++;
  }
  return n;
}
var SHOW_STRING = /* @__PURE__ */ new Set(["model", "effortLevel", "outputStyle", "theme", "language", "defaultMode", "preferredNotifChannel", "forceLoginMethod", "defaultShell", "agent", "autoUpdatesChannel", "subagentModel", "spinnerTipsEnabled", "editorMode", "viewMode"]);
var HIDE_KEYS = /* @__PURE__ */ new Set(["env", "apiKeyHelper", "awsAuthRefresh", "awsCredentialExport", "otelHeadersHelper"]);
function shape(v) {
  if (Array.isArray(v)) return `${v.length} item${v.length === 1 ? "" : "s"}`;
  if (v && typeof v === "object") {
    const n = Object.keys(v).length;
    return `${n} key${n === 1 ? "" : "s"}`;
  }
  return "set";
}
function settingRows(j, layer, file, root, out) {
  const push = (key, value) => out.length < MAX_ITEMS && out.push({ key, value, layer, root, file });
  const val = (name2, v) => typeof v === "boolean" || typeof v === "number" ? String(v) : typeof v === "string" ? SHOW_STRING.has(name2) && !SECRET_NAME2.test(name2) ? bounded(v, 60) : "set" : shape(v);
  for (const [k, v] of Object.entries(j)) {
    if (SECRET_NAME2.test(k) && !HIDE_KEYS.has(k)) {
      push("(hidden key)", "set");
      continue;
    }
    if (k === "env") {
      push("env", `${Object.keys(obj(v)).length} variable name(s), values never read`);
      continue;
    }
    if (HIDE_KEYS.has(k)) {
      push(k, "set");
      continue;
    }
    if (k === "hooks" || k === "enabledPlugins" || k === "mcpServers") {
      push(k, shape(v));
      continue;
    }
    if (v && typeof v === "object" && !Array.isArray(v)) {
      const sub = Object.entries(v);
      if (!sub.length) push(k, "0 keys");
      for (const [k2, v2] of sub.slice(0, 40)) push(`${k}.${SECRET_NAME2.test(k2) ? "(hidden key)" : bounded(k2, 40)}`, SECRET_NAME2.test(k2) ? "set" : val(k2, v2));
    } else push(bounded(k, 50), val(k, v));
  }
}
async function claudePluginRefs(home, enabledIds, errors) {
  const refs = /* @__PURE__ */ new Map();
  const pdir = path4.join(home, "plugins");
  const inst = await readJson(path4.join(pdir, "installed_plugins.json"));
  const ip = obj(inst?.plugins);
  for (const [id, raw] of Object.entries(ip).slice(0, MAX_PLUGINS)) {
    const e = obj(Array.isArray(raw) ? raw[0] : raw);
    const [name2, marketplace] = id.split("@");
    const dir = typeof e.installPath === "string" ? e.installPath : "";
    if (dir) refs.set(id, { name: name2, marketplace, dir, installed: true, version: s(e.version, 30) });
  }
  const known = await readJson(path4.join(pdir, "known_marketplaces.json"));
  const mks = /* @__PURE__ */ new Map();
  for (const [m, e] of Object.entries(obj(known))) if (typeof obj(e).installLocation === "string") mks.set(m, obj(e).installLocation);
  for (const m of await dirs(path4.join(pdir, "marketplaces"))) if (!mks.has(m)) mks.set(m, path4.join(pdir, "marketplaces", m));
  for (const [m, loc] of mks) {
    if (!isPlausibleLocalPath(loc)) continue;
    const cat = await readJson(path4.join(loc, ".claude-plugin", "marketplace.json"), 4e6);
    const list = Array.isArray(cat?.plugins) ? cat.plugins : [];
    if (!cat && await stat2(loc)) errors.push(`marketplace ${bounded(m, 40)}: no readable .claude-plugin/marketplace.json`);
    for (const p of list.slice(0, MAX_PLUGINS)) {
      const o = obj(p);
      const name2 = s(o.name, 60);
      if (!name2) continue;
      const id = `${name2}@${m}`;
      if (refs.has(id)) continue;
      const src = typeof o.source === "string" ? o.source : void 0;
      const dir = src && !/^[a-z]+:/i.test(src) ? path4.resolve(loc, src) : path4.join(loc, "plugins", name2);
      refs.set(id, { name: name2, marketplace: m, dir, installed: false, version: s(o.version, 30) });
    }
  }
  for (const m of await dirs(path4.join(pdir, "cache"))) {
    for (const p of await dirs(path4.join(pdir, "cache", m))) {
      const id = `${p}@${m}`;
      const vs = await dirs(path4.join(pdir, "cache", m, p));
      const v = vs.includes("latest") ? "latest" : vs[vs.length - 1];
      const dir = v ? path4.join(pdir, "cache", m, p, v) : path4.join(pdir, "cache", m, p);
      const prev = refs.get(id);
      if (!prev || !prev.installed) refs.set(id, { name: p, marketplace: m, dir, installed: true, version: prev?.version ?? (v && v !== "latest" ? bounded(v, 30) : void 0) });
    }
  }
  for (const id of enabledIds) if (!refs.has(id)) {
    const [name2, marketplace] = id.split("@");
    refs.set(id, { name: name2, marketplace, dir: "", installed: false });
  }
  return [...refs.values()].slice(0, MAX_PLUGINS);
}
async function scanPlugin(ref, provider, enabled, items, hooks, mcp, files) {
  const id = ref.marketplace ? `${ref.name}@${ref.marketplace}` : ref.name;
  const active = ref.installed || enabled === true;
  const info = { provider, id, name: ref.name, marketplace: ref.marketplace, version: ref.version, enabled, installed: ref.installed, dir: ref.dir, skills: 0, agents: 0, commands: 0, hooks: 0, mcp: 0, projects: [] };
  if (!ref.dir || !(await stat2(ref.dir))?.isDirectory()) return info;
  let manifest;
  for (const f of [path4.join(ref.dir, provider === "codex" ? ".codex-plugin" : ".claude-plugin", "plugin.json"), path4.join(ref.dir, "plugin.json")]) {
    if ((await stat2(f))?.isFile()) {
      manifest = f;
      break;
    }
  }
  if (manifest) {
    const m = await readJson(manifest);
    info.manifest = manifest;
    files.push(manifest);
    info.version = s(m?.version, 30) ?? info.version;
    info.description = s(m?.description, 220);
  }
  if (!active) {
    info.skills = (await dirs(path4.join(ref.dir, "skills"))).filter((d) => !d.startsWith(".")).length;
    info.agents = (await filesIn(path4.join(ref.dir, "agents"), /\.md$/i)).length;
    info.commands = (await filesIn(path4.join(ref.dir, provider === "claude" ? "commands" : "prompts"), /\.md$/i)).length;
    info.hooks = await stat2(path4.join(ref.dir, "hooks", "hooks.json")) ? 1 : 0;
    info.mcp = await stat2(path4.join(ref.dir, ".mcp.json")) ? 1 : 0;
    return info;
  }
  const c = { provider, source: "plugin", plugin: id, active };
  const before = items.length;
  info.skills = await scanSkills(path4.join(ref.dir, "skills"), c, items);
  if (provider === "claude") {
    info.agents = await scanMd(path4.join(ref.dir, "agents"), "agent", c, items, "", 1);
    info.commands = await scanMd(path4.join(ref.dir, "commands"), "command", c, items);
    await scanMd(path4.join(ref.dir, "output-styles"), "output-style", c, items, "", 0);
  } else info.commands = await scanMd(path4.join(ref.dir, "prompts"), "prompt", c, items, "", 0);
  for (const it of items.slice(before)) files.push(it.file);
  const hf = path4.join(ref.dir, "hooks", "hooks.json");
  const hj = await readJson(hf);
  if (hj) {
    info.hooks = hooksFrom(hj.hooks ?? hj, { source: "plugin", plugin: id, file: hf }, hooks);
    files.push(hf);
  }
  const mf = path4.join(ref.dir, ".mcp.json");
  const mj = await readJson(mf);
  if (mj) {
    info.mcp = mcpFrom(mj.mcpServers ?? mj, { provider, source: "plugin", plugin: id, file: mf }, mcp);
    files.push(mf);
  }
  return info;
}
async function instr(file, provider, source, root, out) {
  const st = await stat2(file);
  if (!st || !st.isFile()) return;
  const text = await readText(file) ?? "";
  out.push({ provider, source, root, file, bytes: st.size, lines: text ? text.split("\n").length : 0, headings: headingsOf(text) });
}
async function memoryDirs(home) {
  const out = [];
  const base = path4.join(home, "projects");
  for (const p of await dirs(base)) {
    const dir = path4.join(base, p, "memory");
    const names = await filesIn(dir, /\.md$/i);
    if (!names.length) continue;
    out.push({ project: bounded(p, 120), dir, count: names.length, names: names.slice(0, 100).map((n) => bounded(n, 80)) });
    if (out.length >= 500) break;
  }
  return out;
}
async function collectCatalog(input) {
  const errors = [];
  const homeParent = normalizeCase(path4.dirname(input.claudeHome));
  const roots = [];
  const seen = /* @__PURE__ */ new Set();
  for (const r of input.roots) {
    if (!isPlausibleLocalPath(r)) continue;
    const k = normalizeCase(path4.resolve(r));
    if (seen.has(k) || k === homeParent) continue;
    seen.add(k);
    if ((await stat2(r))?.isDirectory()) roots.push(r);
    if (roots.length >= 80) break;
  }
  const items = [];
  const hooks = [];
  const mcp = [];
  const settings = [];
  const instructions = [];
  const files = [];
  const layers = [];
  if (input.managedFile) layers.push({ kind: "managed", file: input.managedFile });
  layers.push({ kind: "user", file: path4.join(input.claudeHome, "settings.json") });
  for (const r of roots) {
    layers.push({ kind: "project", file: path4.join(r, ".claude", "settings.json"), root: r });
    layers.push({ kind: "local", file: path4.join(r, ".claude", "settings.local.json"), root: r });
  }
  const enabled = /* @__PURE__ */ new Map();
  const enabledBy = /* @__PURE__ */ new Map();
  for (const l of layers) {
    const j = await readJson(l.file);
    if (!j) {
      if ((await stat2(l.file))?.isFile()) errors.push(`${bounded(l.file, 120)}: unreadable or too large`);
      continue;
    }
    files.push(l.file);
    settingRows(j, l.kind, l.file, l.root, settings);
    hooksFrom(j.hooks, { source: l.kind === "project" ? "project" : l.kind, root: l.root, file: l.file }, hooks);
    for (const [id, on] of Object.entries(obj(j.enabledPlugins))) {
      const v = on !== false;
      if (!l.root) {
        if (!enabled.has(id)) enabled.set(id, v);
      } else enabledBy.set(id, (enabledBy.get(id) ?? /* @__PURE__ */ new Set()).add(`${path4.basename(l.root) || l.root}${v ? "" : " (off)"}`));
    }
  }
  const mark = items.length;
  await scanClaudeDir(input.claudeHome, { provider: "claude", source: "user", active: true }, items);
  for (const r of roots) await scanClaudeDir(path4.join(r, ".claude"), { provider: "claude", source: "project", root: r, active: true }, items);
  for (const it of items.slice(mark)) files.push(it.file);
  const plugins = [];
  const enabledIds = /* @__PURE__ */ new Set([...enabled.keys(), ...enabledBy.keys()]);
  for (const ref of await claudePluginRefs(input.claudeHome, enabledIds, errors)) {
    const id = ref.marketplace ? `${ref.name}@${ref.marketplace}` : ref.name;
    const userOn = enabled.has(id) ? enabled.get(id) : void 0;
    const p = await scanPlugin(ref, "claude", userOn, items, hooks, mcp, files);
    p.projects = [...enabledBy.get(id) ?? []].sort();
    plugins.push(p);
  }
  if (input.claudeJson) {
    const cj = await readJson(input.claudeJson, MAX_JSON_BYTES);
    if (cj) {
      mcpFrom(cj.mcpServers, { provider: "claude", source: "user", file: input.claudeJson }, mcp);
      for (const [p, e] of Object.entries(obj(cj.projects)).slice(0, 2e3)) {
        if (!isPlausibleLocalPath(p)) continue;
        mcpFrom(obj(e).mcpServers, { provider: "claude", source: "local", root: p, file: input.claudeJson }, mcp);
      }
    }
  }
  for (const r of roots) {
    const f = path4.join(r, ".mcp.json");
    const j = await readJson(f);
    if (!j) continue;
    files.push(f);
    mcpFrom(j.mcpServers ?? j, { provider: "claude", source: "project", root: r, file: f }, mcp);
  }
  await instr(path4.join(input.claudeHome, "CLAUDE.md"), "claude", "user", void 0, instructions);
  await instr(path4.join(input.codexHome, "AGENTS.md"), "codex", "user", void 0, instructions);
  for (const r of roots) {
    await instr(path4.join(r, "CLAUDE.md"), "claude", "project", r, instructions);
    await instr(path4.join(r, ".claude", "CLAUDE.md"), "claude", "project", r, instructions);
    await instr(path4.join(r, "CLAUDE.local.md"), "claude", "local", r, instructions);
    await instr(path4.join(r, "AGENTS.md"), "codex", "project", r, instructions);
  }
  for (const i of instructions) files.push(i.file);
  const cx = input.codexHome;
  let codexConfig;
  const cfgFile = path4.join(cx, "config.toml");
  if ((await stat2(cfgFile))?.isFile()) {
    codexConfig = readCodexConfig(cfgFile, "user");
    files.push(cfgFile);
    const t = await readText(cfgFile);
    if (t) {
      let toml = {};
      try {
        toml = parseToml(t);
      } catch {
      }
      mcpFrom(toml.mcp_servers, { provider: "codex", source: "user", file: cfgFile }, mcp);
    }
  }
  const cmark = items.length;
  const userSkills = path4.join(cx, "skills");
  await scanSkills(userSkills, { provider: "codex", source: "user", active: true }, items);
  await scanSkills(path4.join(userSkills, ".system"), { provider: "codex", source: "system", active: true }, items);
  await scanMd(path4.join(cx, "prompts"), "prompt", { provider: "codex", source: "user", active: true }, items, "", 0);
  for (const r of roots) await scanSkills(path4.join(r, ".codex", "skills"), { provider: "codex", source: "project", root: r, active: true }, items);
  for (const it of items.slice(cmark)) files.push(it.file);
  const codexOn = new Map((codexConfig?.plugins ?? []).map((p) => [p.name, p.on]));
  for (const m of await dirs(path4.join(cx, "plugins", "cache"))) {
    for (const p of await dirs(path4.join(cx, "plugins", "cache", m))) {
      if (plugins.length >= MAX_PLUGINS * 2) break;
      const vs = await dirs(path4.join(cx, "plugins", "cache", m, p));
      const v = vs.includes("latest") ? "latest" : vs[vs.length - 1];
      const dir = v ? path4.join(cx, "plugins", "cache", m, p, v) : path4.join(cx, "plugins", "cache", m, p);
      const id = `${p}@${m}`;
      const on = codexOn.has(id) ? codexOn.get(id) : codexOn.has(p) ? codexOn.get(p) : void 0;
      plugins.push(await scanPlugin({ name: p, marketplace: m, dir, installed: true, version: v && v !== "latest" ? bounded(v, 30) : vs.filter((x) => x !== "latest").pop() }, "codex", on, items, hooks, mcp, files));
    }
  }
  const codexRules = [];
  for (const f of (await filesIn(path4.join(cx, "rules"), /\.rules$/i)).slice(0, 50)) {
    const file = path4.join(cx, "rules", f);
    const t = await readText(file) ?? "";
    codexRules.push({ file, rules: (t.match(/^\s*prefix_rule\s*\(/gm) ?? []).length });
    files.push(file);
  }
  return {
    at: input.now ?? Date.now(),
    claudeHome: input.claudeHome,
    codexHome: input.codexHome,
    roots,
    items,
    plugins,
    hooks,
    mcp,
    settings,
    instructions,
    memory: await memoryDirs(input.claudeHome),
    codexConfig,
    codexRules,
    files: [...new Set(files)].filter((f) => !isForbidden(f) && (!input.claudeJson || normalizeCase(f) !== normalizeCase(input.claudeJson))),
    errors: errors.slice(0, 20)
  };
}

// src/galaxy/index.ts
var import_crypto = require("crypto");
var CONFIG_SNAPSHOT_SCHEMA = "galaxy.agent-config-snapshot/1";
function sha256(text) {
  return (0, import_crypto.createHash)("sha256").update(text, "utf8").digest("hex");
}
function pathRef(p) {
  if (!p) return void 0;
  const norm = p.replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();
  const name2 = norm.split("/").filter(Boolean).pop() ?? "";
  return { name: name2, hash: sha256(norm).slice(0, 16) };
}
function iso(ms) {
  return ms === void 0 || !Number.isFinite(ms) ? void 0 : new Date(ms).toISOString();
}
function canonicalJson(v) {
  if (v === void 0) return "null";
  if (v === null || typeof v !== "object") return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(canonicalJson).join(",")}]`;
  const o = v;
  return `{${Object.keys(o).filter((k) => o[k] !== void 0).sort().map((k) => `${JSON.stringify(k)}:${canonicalJson(o[k])}`).join(",")}}`;
}
function compactObj(o) {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== void 0));
}

// src/galaxy/configSnapshot.ts
var name = (s2, max = 80) => bounded(s2, max);
var uniq = (xs) => [...new Set(xs)].sort();
var byKey = (xs, key) => [...xs].sort((a, b) => key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0);
function claudePart(r) {
  const layers = r.layers.filter((l) => l.exists && !l.error).map((l) => compactObj({
    kind: l.kind,
    root: pathRef(l.root),
    model: l.model,
    effortLevel: l.effortLevel,
    defaultMode: l.defaultMode,
    outputStyle: l.outputStyle,
    allow: l.allow.length,
    deny: l.deny.length,
    ask: l.ask.length,
    hookEvents: uniq(l.hooks.map((h) => name(h.event, 40))),
    hooks: l.hooks.length,
    env: l.envNames.length + l.envHidden,
    enabledPlugins: uniq(l.enabledPlugins.map((p) => name(p))),
    apiKeyHelper: l.apiKeyHelper
  }));
  const user = layersFor(r);
  return {
    layers: byKey(layers, (l) => `${l.kind}|${l.root?.hash ?? ""}`),
    effective: compactObj({ model: effective(user, "model").value, effortLevel: effective(user, "effortLevel").value, defaultMode: effective(user, "defaultMode").value }),
    rules: mergedRules(user),
    items: byKey(r.items.map((i) => ({ kind: i.kind, scope: i.scope, name: name(i.name) })), (i) => `${i.kind}|${i.scope}|${i.name}`)
  };
}
function codexPart(c) {
  return compactObj({
    scope: c.scope,
    root: pathRef(c.root),
    model: c.model,
    effort: c.effort,
    approval: c.approval,
    sandbox: c.sandbox,
    serviceTier: c.serviceTier,
    profile: c.profile,
    profiles: uniq(c.profiles.map((p) => name(p.name))),
    mcpServers: uniq(c.mcpServers.map((m) => name(m))),
    features: byKey(c.features.map((f) => ({ name: name(f.name), on: f.on })), (f) => f.name),
    plugins: byKey(c.plugins.map((p) => ({ name: name(p.name), on: p.on })), (p) => p.name),
    trustedProjects: c.trustedProjects,
    notify: c.notify
  });
}
function catalogPart(c) {
  return {
    items: byKey(c.items.map((i) => compactObj({ provider: i.provider, kind: i.kind, source: i.source, name: name(i.name), active: i.active, plugin: i.plugin ? name(i.plugin) : void 0 })), (i) => `${i.provider}|${i.kind}|${i.source}|${i.name}`),
    plugins: byKey(c.plugins.map((p) => compactObj({ provider: p.provider, id: name(p.id), version: p.version ? name(p.version, 40) : void 0, enabled: p.enabled, installed: p.installed })), (p) => `${p.provider}|${p.id}`),
    hooks: byKey(c.hooks.map((h) => ({ event: name(h.event, 40), matcher: name(h.matcher, 80), type: h.type, program: name(h.program, 60), source: h.source })), (h) => `${h.event}|${h.matcher}|${h.program}`),
    mcp: byKey(c.mcp.map((m) => ({ provider: m.provider, name: name(m.name), transport: m.transport, source: m.source })), (m) => `${m.provider}|${m.name}`),
    settingsKeys: uniq(c.settings.map((s2) => name(s2.key, 80)))
  };
}
function toConfigSnapshot(input) {
  const codexConfigs = input.settings?.codex.filter((c) => c.exists && !c.error);
  const content = compactObj({
    claude: input.settings ? claudePart(input.settings) : void 0,
    codex: codexConfigs ? byKey(codexConfigs.map(codexPart), (c) => `${c.scope}|${c.root?.hash ?? ""}`) : void 0,
    catalog: input.catalog ? catalogPart(input.catalog) : void 0,
    cli: input.cli ? byKey(input.cli.map((c) => compactObj({ tool: c.tool, status: c.status, version: c.version ? name(c.version, 40) : void 0 })), (c) => c.tool) : void 0
  });
  const kinds = {
    claude: input.settings ? "OBSERVED" : "UNKNOWN",
    "claude.effective": input.settings ? "DERIVED" : "UNKNOWN",
    "claude.rules": input.settings ? "DERIVED" : "UNKNOWN",
    codex: input.settings ? "OBSERVED" : "UNKNOWN",
    catalog: input.catalog ? "OBSERVED" : "UNKNOWN",
    cli: input.cli ? "OBSERVED" : "UNKNOWN",
    contentHash: "DERIVED",
    capturedAt: "OBSERVED"
  };
  return {
    schema: CONFIG_SNAPSHOT_SCHEMA,
    capturedAt: iso(input.capturedAt) ?? (/* @__PURE__ */ new Date(0)).toISOString(),
    contentHash: sha256(canonicalJson(content)),
    kinds,
    ...content
  };
}

// src/cockpit/policy.ts
var import_node_crypto = require("node:crypto");
var path5 = __toESM(require("node:path"));
var digest = (value) => (0, import_node_crypto.createHash)("sha256").update(JSON.stringify(value)).digest("hex");
var repoId = (root) => {
  const p = path5.resolve(root).replace(/\\/g, "/");
  return "repo:" + digest(process.platform === "win32" ? p.toLowerCase() : p).slice(0, 24);
};
var idOk = (v) => typeof v === "string" && /^[a-zA-Z0-9._:/-]{1,160}$/.test(v);
function validateRequest(value) {
  if (!value || typeof value !== "object") return false;
  const r = value, s2 = r.scope;
  return idOk(r.requestId) && !!s2 && idOk(s2.scopeId) && ["organizationIds", "privacyDomainIds", "projectIds", "repoIds"].every((k) => {
    const a = s2[k];
    return Array.isArray(a) && a.length <= 100 && a.every(idOk);
  }) && typeof s2.policyHash === "string" && typeof s2.sourceVectorHash === "string" && /^[a-f0-9]{64}$/.test(s2.policyHash) && /^[a-f0-9]{64}$/.test(s2.sourceVectorHash) && (r.limit === void 0 || Number.isInteger(r.limit) && r.limit > 0 && r.limit <= 500) && (r.cursor === void 0 || /^[0-9]{1,6}$/.test(r.cursor)) && (r.epoch === void 0 || Number.isSafeInteger(r.epoch) && r.epoch >= 0) && (r.generation === void 0 || idOk(r.generation));
}
var ScopePolicy = class {
  grants = /* @__PURE__ */ new Map();
  revision = 0;
  get epoch() {
    return this.revision;
  }
  set(grant) {
    if (!this.grants.has(grant.scope.scopeId) && this.grants.size >= 100) throw new Error("Reviewed scope bound exceeded.");
    this.grants.set(grant.scope.scopeId, structuredClone(grant));
    this.revision++;
  }
  clear() {
    this.grants.clear();
    this.revision++;
  }
  scopes() {
    return [...this.grants.values()].map((g) => structuredClone(g.scope));
  }
  authorize(request) {
    if (!validateRequest(request) || request.epoch !== void 0 && request.epoch !== this.revision || request.generation !== void 0 && !idOk(request.generation)) return void 0;
    const g = this.grants.get(request.scope.scopeId);
    const same = g && Object.keys(g.scope).every((k) => JSON.stringify(g.scope[k]) === JSON.stringify(request.scope[k]));
    return same ? structuredClone(g) : void 0;
  }
  sessions(g, sessions) {
    const keys = new Set(g.sessionKeys);
    return sessions.filter((s2) => {
      const root = s2.repository ?? s2.cwd;
      return keys.has(s2.key) && (root ? g.scope.repoIds.includes(repoId(root)) : g.scope.repoIds.length === 0);
    });
  }
};

// src/cockpit/configuration.ts
async function safeLocalSource(file) {
  if (isForbidden(file) || isCredentialPath(file) || !path6.isAbsolute(file)) return false;
  try {
    for (let p = file; p !== path6.dirname(p); p = path6.dirname(p)) if ((await fs5.lstat(p)).isSymbolicLink()) return false;
    return (await fs5.stat(file)).isFile();
  } catch {
    return false;
  }
}
async function collectConfiguration(selection, provider, sessions, homes) {
  const grant = { roots: selection.roots, scope: { policyHash: selection.policyHash } };
  const at = Date.now();
  const settings = collectSettings({ ...homes, roots: grant.roots, now: at });
  const catalog = await collectCatalog({ ...homes, roots: grant.roots, now: at });
  const snapshot = toConfigSnapshot({ settings, catalog, capturedAt: at });
  const sources = /* @__PURE__ */ new Map();
  for (const file of [...settings.files, ...catalog.files].slice(0, 500)) {
    if (await safeLocalSource(file)) sources.set("source:" + digest([grant.scope.policyHash, file]).slice(0, 32), file);
  }
  const fact = (value, sourceIds = [], kind = "DERIVED") => ({ value: value ? bounded(value, 80) : null, kind: value ? kind : "UNKNOWN", sourceIds, observedAt: new Date(at).toISOString() });
  const sourceFor = (file) => [...sources].filter(([, f]) => f === file).map(([id]) => id);
  const configured = {};
  let layers;
  if (provider === "claude") {
    layers = snapshot.claude?.layers ?? [];
    for (const key of ["model", "effortLevel", "defaultMode"]) {
      const e = grant.roots.length > 1 ? { value: void 0, file: void 0 } : effective(layersFor(settings, grant.roots[0]), key);
      configured[key] = { ...fact(e.value, e.file ? sourceFor(e.file) : []), reason: "Configured precedence only; CLI overrides and active runtime may differ." };
    }
  } else {
    layers = snapshot.codex ?? [];
    const configs = settings.codex.filter((c) => c.exists && !c.error);
    for (const key of ["model", "effort", "approval", "sandbox", "serviceTier", "profile"]) {
      const c = grant.roots.length > 1 ? void 0 : [...configs].reverse().find((c2) => c2[key] !== void 0);
      configured[key] = { ...fact(c?.[key], c ? sourceFor(c.file) : []), reason: "Configured value; profile selection, CLI overrides and runtime resolution are incomplete." };
    }
  }
  const inventory = [
    ...(snapshot.catalog?.items ?? []).filter((i) => i.provider === provider).map((i) => {
      const plugin = i.plugin ? snapshot.catalog?.plugins.find((p) => p.provider === provider && p.id === i.plugin) : void 0;
      return { ...i, installed: i.source === "plugin" ? plugin?.installed ?? "UNKNOWN" : true, enabled: i.source === "plugin" ? plugin?.enabled ?? "UNKNOWN" : "UNKNOWN", authenticated: "UNKNOWN", probed: "UNKNOWN", used: "UNKNOWN" };
    }),
    ...catalog.items.filter((i) => i.provider === provider).map((i) => ({ kind: "declared-native-role", itemKind: i.kind, name: bounded(i.name, 80), source: i.source, sourceIds: sourceFor(i.file), requestedModel: i.model ? bounded(i.model, 80) : null, requestedEffort: i.effort ? bounded(i.effort, 30) : null, declaredTools: i.tools ? bounded(i.tools, 140) : null, observedModel: null, inheritance: "NATIVE_PROVIDER_OWNED" })),
    ...catalog.hooks.filter((h) => {
      const relative3 = path6.relative(homes.codexHome, h.file), isCodex = relative3 !== "" && !relative3.startsWith("..") && !path6.isAbsolute(relative3);
      return provider === "codex" ? isCodex : !isCodex;
    }).map((h) => ({ kind: "hook", event: bounded(h.event, 40), matcher: bounded(h.matcher, 80), type: bounded(h.type, 30), source: h.source, sourceIds: sourceFor(h.file), payload: "OMITTED", execution: "INERT" })),
    ...(snapshot.catalog?.plugins ?? []).filter((i) => i.provider === provider).map((i) => ({ ...i, kind: "plugin", probed: "UNKNOWN", used: "UNKNOWN" })),
    ...(snapshot.catalog?.mcp ?? []).filter((i) => i.provider === provider).map((i) => ({ ...i, kind: "mcp", enabled: "UNKNOWN", probed: "UNKNOWN", used: "UNKNOWN" })),
    ...catalog.instructions.filter((i) => i.provider === provider).map((i) => ({ kind: "instruction", source: i.source, bytes: i.bytes, sourceId: sourceFor(i.file)[0], execution: "INERT" }))
  ].slice(0, 500);
  const observed = sessions.filter((s2) => s2.provider === provider);
  return { at, sources, config: { provider, cliVersion: { value: null, kind: "UNKNOWN", sourceIds: [], reason: "No CLI execution during inventory; session-recorded versions are separate." }, layers, effective: configured, resolution: "PARTIAL", inventory, observedSessions: observed, sourceOpenIds: [...sources.keys()] } };
}

// src/provider-kit/nativeTransport.ts
var fs6 = __toESM(require("node:fs/promises"));
var import_node_crypto2 = require("node:crypto");
var nativeTransportVersion = "1.0.0";
var nativeHash = (value) => sha256(canonicalJson(value));
var hashOk = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
var nativeIdOk = (v) => typeof v === "string" && /^[a-zA-Z0-9._:-]{1,160}$/.test(v);
var identityOk = (v) => typeof v === "string" && /^[a-zA-Z0-9._:/-]{1,160}$/.test(v);
function validateNativeSelection(s2) {
  return !!s2 && ["codex-app-server", "codex-cli", "claude-cli"].includes(s2.transport) && [s2.executable, s2.cwd, s2.home].every((p) => isPlausibleLocalPath(p) && !hasLinkedAncestor(p)) && hashOk(s2.executableSha256) && identityOk(s2.nativeVersion) && nativeIdOk(s2.hostId) && ["read-only", "workspace-write"].includes(s2.permission) && !!s2.requestedIdentity && identityOk(s2.requestedIdentity.model) && (s2.requestedIdentity.effort === null || ["minimal", "low", "medium", "high", "xhigh", "max"].includes(s2.requestedIdentity.effort)) && (s2.requestedIdentity.accountId === null || identityOk(s2.requestedIdentity.accountId)) && !!s2.startup && hashOk(s2.startup.reviewHash) && hashOk(s2.startup.configurationHash) && ["NONE", "REVIEWED"].includes(s2.startup.hooks) && ["NONE", "REVIEWED"].includes(s2.startup.mcp) && ["NONE", "REVIEWED"].includes(s2.startup.managed) && typeof s2.startup.isolated === "boolean" && Array.isArray(s2.startup.supported) && s2.startup.supported.length <= 40 && s2.startup.supported.every(identityOk);
}
async function preflightNativeTransport(selection) {
  const s2 = structuredClone(selection), reasons = [];
  if (!validateNativeSelection(s2)) throw Error("Invalid native transport selection.");
  for (const directory of [s2.cwd, s2.home]) {
    try {
      if (!(await fs6.lstat(directory)).isDirectory() || hasLinkedAncestor(directory)) reasons.push("Reviewed directories must be real local directories.");
    } catch {
      reasons.push("Reviewed directory is unavailable.");
    }
  }
  try {
    const stat4 = await fs6.lstat(s2.executable);
    if (!stat4.isFile() || stat4.isSymbolicLink() || /\.(cmd|bat|ps1|sh|js|cjs|mjs)$/i.test(s2.executable) || stat4.size > 200 * 1024 * 1024 || (0, import_node_crypto2.createHash)("sha256").update(await fs6.readFile(s2.executable)).digest("hex") !== s2.executableSha256) reasons.push("Exact native executable hash is unavailable or changed.");
  } catch {
    reasons.push("Exact native executable is unavailable.");
  }
  if (!s2.startup.isolated) reasons.push("Verified isolated native execution host is required.");
  const required = s2.transport === "codex-app-server" ? ["initialize", "thread/start", "thread/resume", "turn/start", "turn/interrupt"] : s2.transport === "codex-cli" ? ["exec", "json", "resume", "sandbox"] : ["print", "stream-json", "resume", "restricted", "tools", "strict-mcp-config"];
  if (required.some((cap) => !s2.startup.supported.includes(cap))) reasons.push("Installed native version lacks a reviewed required capability.");
  if (s2.transport === "claude-cli" && s2.requestedIdentity.effort !== null && !s2.startup.supported.includes("effort")) reasons.push("Requested effort is not supported by this installed version.");
  return {
    schema: "datapass.native-preflight/1",
    version: nativeTransportVersion,
    state: reasons.length ? "BLOCKED" : "READY",
    selectionHash: nativeHash(s2),
    reasons,
    capabilities: { start: !reasons.length, stream: !reasons.length, resume: !reasons.length, cancel: s2.transport === "codex-app-server" ? "OWNED_TURN" : "OWNED_PROCESS", securityRequests: "NATIVE_REFUSAL", observedIdentity: "PROVIDER_EVIDENCE_ONLY" }
  };
}
function prepareNativeTask(input) {
  const i = structuredClone(input);
  if (!validateNativeSelection(i.selection) || !nativeIdOk(i.taskId) || typeof i.text !== "string" || !i.text.trim() || Buffer.byteLength(i.text) > 64 * 1024 || i.text.includes("\0") || ![i.targetHash, i.permissionHash, i.configHash, i.presetHash, i.promptHash, i.bindingHash, i.scopeHash, i.configScopeHash].every(hashOk) || i.resumeFromTaskId !== void 0 && !nativeIdOk(i.resumeFromTaskId)) throw Error("Invalid exact prepared native task.");
  const task = { ...i, schema: "datapass.native-task/1" };
  return { ...task, preparedHash: nativeHash(task) };
}
function nativeLaunchArguments(task, resumeId) {
  const s2 = task.selection;
  if (resumeId !== void 0 && !nativeIdOk(resumeId)) throw Error("Invalid owned native session.");
  if (s2.transport === "codex-app-server") return ["app-server", "--listen", "stdio://"];
  if (s2.transport === "codex-cli") {
    const args = ["exec", ...resumeId ? ["resume", resumeId] : [], "--json", "-c", 'approval_policy="never"', "-c", `sandbox_mode="${s2.permission}"`, "-c", "sandbox_workspace_write.network_access=false", "--model", s2.requestedIdentity.model];
    if (s2.requestedIdentity.effort) args.push("-c", `model_reasoning_effort="${s2.requestedIdentity.effort}"`);
    return [...args, "-"];
  }
  const tools = s2.permission === "read-only" ? "Read,Glob,Grep" : "Read,Glob,Grep,Edit,Write";
  return ["--print", "--input-format", "text", "--output-format", "stream-json", "--verbose", "--include-partial-messages", "--restricted", "--tools", tools, "--allowedTools", tools, "--disallowedTools", "mcp__*", "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}', "--model", s2.requestedIdentity.model, ...s2.requestedIdentity.effort ? ["--effort", s2.requestedIdentity.effort] : [], ...resumeId ? ["--resume", resumeId] : []];
}
function nativeEnvironment(selection) {
  return { HOME: selection.home, USERPROFILE: selection.home, CODEX_HOME: selection.home, CLAUDE_CONFIG_DIR: selection.home, ...process.platform === "win32" ? { SystemRoot: process.env.SystemRoot } : {} };
}

// src/provider-kit/nativeRunner.ts
var fs8 = __toESM(require("node:fs/promises"));
var fsSync = __toESM(require("node:fs"));
var path8 = __toESM(require("node:path"));
var import_node_child_process2 = require("node:child_process");
var import_node_crypto3 = require("node:crypto");

// src/provider-kit/nativeProjectScope.ts
var path7 = __toESM(require("node:path"));
var fs7 = __toESM(require("node:fs/promises"));
var import_node_child_process = require("node:child_process");
async function verifyNativeProjectScope(input) {
  if (!input || ![input.organizationId, input.privacyDomainId, input.projectId].every(nativeIdOk) || !/^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+$/.test(input.repoId) || !isPlausibleLocalPath(input.root) || hasLinkedAncestor(input.root) || !/^[a-f0-9]{40}$/.test(input.revision) || ![input.sourceVectorHash, input.policyHash].every(hashOk)) throw Error("Invalid exact project execution scope.");
  const observed = await readNativeRepositoryIdentity(input.root);
  const canonical = (s2) => process.platform === "win32" ? path7.resolve(s2).toLowerCase() : path7.resolve(s2);
  if (canonical(observed.root) !== canonical(input.root) || observed.revision !== input.revision || observed.repoId.toLowerCase() !== input.repoId.toLowerCase()) throw Error("Exact project root, canonical origin or revision changed.");
}
async function readNativeRepositoryIdentity(root) {
  if (!isPlausibleLocalPath(root) || hasLinkedAncestor(root) || !(await fs7.lstat(root)).isDirectory()) throw Error("Reviewed project root is unavailable.");
  const git = resolveExe("git");
  if (!git) throw Error("Git identity verification unavailable.");
  const env = { GIT_TERMINAL_PROMPT: "0" };
  for (const key of ["PATH", "Path", "SystemRoot"]) if (process.env[key]) env[key] = process.env[key];
  const read = (args) => new Promise((resolve6, reject) => (0, import_node_child_process.execFile)(git, [...HARDEN, "-c", "core.hooksPath=NUL", ...args], { cwd: root, env, shell: false, windowsHide: true, timeout: 1e4, maxBuffer: 64 * 1024 }, (error, out) => error ? reject(Error("Project Git identity unavailable.")) : resolve6(out.toString().trim())));
  const [worktree, head, remote, common] = await Promise.all([read(["rev-parse", "--show-toplevel"]), read(["rev-parse", "HEAD"]), read(["config", "--get", "remote.origin.url"]), read(["rev-parse", "--git-common-dir"])]);
  const match = /^(?:https:\/\/|git@)(github\.com|gitlab\.com)(?:\/|:)([a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+?)(?:\.git)?$/.exec(remote);
  if (!match || !/^[a-f0-9]{40}$/.test(head)) throw Error("Exact project canonical origin or revision unavailable.");
  const commonDirectory = await fs7.realpath(path7.resolve(root, common));
  if (hasLinkedAncestor(commonDirectory)) throw Error("Linked Git metadata denied.");
  return { root: await fs7.realpath(worktree), revision: head, repoId: match[2], remoteHost: match[1], commonDirectory };
}

// src/provider-kit/nativeRunner.ts
var NativeTaskRunner = class {
  constructor(ledgerDirectory, spawnProcess = import_node_child_process2.spawn) {
    this.ledgerDirectory = ledgerDirectory;
    this.spawnProcess = spawnProcess;
    let ancestor = ledgerDirectory;
    while (!fsSync.existsSync(ancestor) && ancestor !== path8.dirname(ancestor)) ancestor = path8.dirname(ancestor);
    if (!isPlausibleLocalPath(ledgerDirectory) || hasLinkedAncestor(ancestor)) throw Error("A real owned ledger directory is required.");
  }
  live = /* @__PURE__ */ new Map();
  file(id) {
    if (!nativeIdOk(id)) throw Error("Invalid owned task identity.");
    return path8.join(this.ledgerDirectory, nativeHash(id) + ".json");
  }
  async lookup(id) {
    if (this.live.has(id)) return this.live.get(id).handle.observation();
    try {
      if (!fsSync.existsSync(this.ledgerDirectory)) return null;
      if (hasLinkedAncestor(this.ledgerDirectory)) throw Error("Linked ledger denied.");
      const file = this.file(id);
      if (!fsSync.existsSync(file)) return null;
      if (hasLinkedAncestor(file)) throw Error("Linked ledger file denied.");
      const raw = await fs8.readFile(file, "utf8");
      if (raw.length > 128 * 1024) throw Error("Oversize ledger.");
      const o = JSON.parse(raw);
      if (o.schema !== "datapass.native-task-observation/1" || o.taskId !== id) throw Error("Invalid task ledger.");
      if (["SPAWN_INTENT", "RUNNING", "NEEDS_INPUT"].includes(o.state)) return { ...o, state: "UNCERTAIN", reason: "Prior owned process outcome is unknown; no blind retry or automatic resume." };
      return o;
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw e;
    }
  }
  async cancel(id) {
    const live = this.live.get(id);
    if (!live) throw Error("Cancel is limited to an active process owned by this host instance.");
    return live.cancel();
  }
  async dispose() {
    await Promise.allSettled([...this.live.values()].map((t) => t.cancel()));
  }
  async start(input, reviewedHash, stillAuthorized = () => true) {
    const task = structuredClone(input), { schema, preparedHash, ...i } = task;
    if (schema !== "datapass.native-task/1" || prepareNativeTask(i).preparedHash !== preparedHash || reviewedHash !== preparedHash || !stillAuthorized()) throw Error("Exact prepared task approval is required.");
    const preflight = await preflightNativeTransport(task.selection);
    if (preflight.state !== "READY") throw Error("Native startup blocked: " + preflight.reasons.join(" "));
    let resumeId;
    if (task.resumeFromTaskId) {
      const prior = await this.lookup(task.resumeFromTaskId);
      if (!prior || !["COMPLETED", "INTERRUPTED"].includes(prior.state) || prior.quiescence !== "NATIVE_TURN_SETTLED" || !prior.sessionId || prior.selectionHash !== nativeHash(task.selection) || prior.targetHash !== task.targetHash || prior.permissionHash !== task.permissionHash || prior.configHash !== task.configHash || prior.presetHash !== task.presetHash || prior.bindingHash !== task.bindingHash || prior.scopeHash !== task.scopeHash || prior.configScopeHash !== task.configScopeHash) throw Error("Resume requires an owned settled native session with unchanged reviewed target, configuration and permission.");
      resumeId = prior.sessionId;
    }
    await fs8.mkdir(this.ledgerDirectory, { recursive: true });
    if (hasLinkedAncestor(this.ledgerDirectory) || !stillAuthorized()) throw Error("Owned ledger/authority changed before launch.");
    const filename = this.file(task.taskId), selection = task.selection;
    let observation = { schema: "datapass.native-task-observation/1", taskId: task.taskId, preparedHash, selectionHash: nativeHash(selection), targetHash: task.targetHash, permissionHash: task.permissionHash, configHash: task.configHash, presetHash: task.presetHash, promptHash: task.promptHash, bindingHash: task.bindingHash, scopeHash: task.scopeHash, configScopeHash: task.configScopeHash, state: "SPAWN_INTENT", sessionId: resumeId ?? null, turnId: null, sequence: 0, requestedIdentity: selection.requestedIdentity, observedIdentity: { model: null, effort: null, accountId: null }, resultText: "", resultHash: null, reason: null, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), evidence: "NO_COMPLETION_EVIDENCE", quiescence: "UNKNOWN" };
    const intent = await fs8.open(filename, "wx", 384);
    try {
      await intent.writeFile(JSON.stringify(observation));
      await intent.sync();
    } finally {
      await intent.close();
    }
    const lease = resumeId ? path8.join(this.ledgerDirectory, "session-" + nativeHash(resumeId) + ".lease") : void 0;
    if (lease) {
      const fd = await fs8.open(lease, "wx", 384);
      try {
        await fd.writeFile(task.taskId);
        await fd.sync();
      } finally {
        await fd.close();
      }
    }
    const repoLeases = [];
    if (selection.permission === "workspace-write") {
      const identity = await readNativeRepositoryIdentity(selection.cwd);
      const keys = [nativeHash({ host: identity.remoteHost, repo: identity.repoId.toLowerCase() }), nativeHash(process.platform === "win32" ? identity.commonDirectory.toLowerCase() : identity.commonDirectory)];
      try {
        for (const key of [...new Set(keys)].sort()) {
          const file = path8.join(this.ledgerDirectory, "repo-" + key + ".lease"), fd = await fs8.open(file, "wx", 384);
          try {
            await fd.writeFile(JSON.stringify({ taskId: task.taskId, preparedHash, identityHash: nativeHash(identity) }));
            await fd.sync();
          } finally {
            await fd.close();
          }
          repoLeases.push(file);
        }
      } catch (e) {
        for (const file of repoLeases) await fs8.unlink(file);
        throw Error("Another owned native writer or uncertain write lease holds this canonical repository.");
      }
    }
    let child, finished = false, cancelRequested = false, cliCompleted = false, nativeTerminal = false, buffer = "", resultText = "", queued = Promise.resolve();
    let complete;
    const result = new Promise((resolve6) => {
      complete = resolve6;
    });
    const listeners = /* @__PURE__ */ new Set();
    const snapshot = () => structuredClone(observation);
    const persist = async (value) => {
      const temporary = filename + "." + (0, import_node_crypto3.randomUUID)() + ".tmp", fd = await fs8.open(temporary, "wx", 384);
      try {
        await fd.writeFile(JSON.stringify(value));
        await fd.sync();
      } finally {
        await fd.close();
      }
      await fs8.rename(temporary, filename);
    };
    const emit = (type) => {
      for (const fn of listeners) try {
        fn({ type, observation: snapshot() });
      } catch {
      }
    };
    const update = async (fields, type = "STATE") => {
      const next = { ...observation, ...fields, sequence: observation.sequence + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await persist(next);
      observation = next;
      emit(type);
    };
    const enqueue = (action) => {
      queued = queued.then(action).catch(() => {
        finished = true;
        observation = { ...observation, state: "UNCERTAIN", reason: "Durable native state commit failed; do not retry." };
        child?.kill();
        clearTimeout(timeout);
        clearInterval(authorityWatch);
        this.live.delete(task.taskId);
        complete(snapshot());
      });
    };
    const finish = async (state, reason = null, settled = false) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      clearInterval(authorityWatch);
      await update({ state, reason, resultText: bounded(resultText, 32 * 1024), resultHash: resultText ? nativeHash(bounded(resultText, 32 * 1024)) : null, evidence: state === "COMPLETED" ? "NATIVE_REPORTED" : "NO_COMPLETION_EVIDENCE", quiescence: settled ? "NATIVE_TURN_SETTLED" : "UNKNOWN" });
      if (lease && settled) await fs8.unlink(lease);
      if (settled) for (const file of repoLeases) await fs8.unlink(file);
      this.live.delete(task.taskId);
      complete(snapshot());
      child?.stdin.end();
      child?.kill();
    };
    const send = (value) => {
      if (!child || !child.stdin.writable) throw Error("Owned native stdin closed.");
      child.stdin.write(JSON.stringify(value) + "\n");
    };
    const cancel = async () => {
      if (finished) return snapshot();
      cancelRequested = true;
      if (selection.transport === "codex-app-server" && observation.sessionId && observation.turnId) {
        send({ id: 4, method: "turn/interrupt", params: { threadId: observation.sessionId, turnId: observation.turnId } });
      } else child?.kill();
      return snapshot();
    };
    const handle = { taskId: task.taskId, observation: snapshot, result, subscribe: (fn) => {
      if (listeners.size >= 20) throw Error("Native subscription bound exceeded.");
      listeners.add(fn);
      return { dispose: () => listeners.delete(fn) };
    }, cancel };
    this.live.set(task.taskId, { handle, cancel });
    const timeout = setTimeout(() => {
      enqueue(() => finish("UNCERTAIN", "Native completion deadline reached; owned process cancellation requested, no automatic retry."));
    }, 10 * 60 * 1e3);
    const authorityWatch = setInterval(() => {
      if (!finished && !stillAuthorized()) enqueue(() => finish("UNCERTAIN", "Reviewed authority was revoked; owned process stopped, native descendants require reconciliation."));
    }, 250);
    const threadParams = { cwd: selection.cwd, model: selection.requestedIdentity.model, approvalPolicy: "never", sandbox: selection.permission === "read-only" ? "readOnly" : "workspaceWrite", ...resumeId ? { threadId: resumeId } : {} };
    const turnParams = () => ({ threadId: observation.sessionId, input: [{ type: "text", text: task.text }], cwd: selection.cwd, model: selection.requestedIdentity.model, ...selection.requestedIdentity.effort ? { effort: selection.requestedIdentity.effort } : {}, approvalPolicy: "never", sandboxPolicy: selection.permission === "read-only" ? { type: "readOnly" } : { type: "workspaceWrite", writableRoots: [selection.cwd], networkAccess: false } });
    const consume = async (message) => {
      if (finished) return;
      if (!stillAuthorized()) {
        await cancel();
        return;
      }
      if (selection.transport === "codex-app-server") {
        if (message.error) {
          await finish("FAILED", "Native protocol request failed.");
          return;
        }
        if (message.id === 0 && message.result) {
          send({ method: "initialized", params: {} });
          send({ id: 1, method: resumeId ? "thread/resume" : "thread/start", params: threadParams });
          return;
        }
        if (message.id === 1 && message.result?.thread) {
          const thread = message.result.thread;
          if (!nativeIdOk(thread.id) || resumeId && thread.id !== resumeId) {
            await finish("UNCERTAIN", "Native thread identity mismatch.");
            return;
          }
          await update({ sessionId: thread.id, observedIdentity: { model: typeof message.result.model === "string" ? bounded(message.result.model, 160) : null, effort: null, accountId: null } });
          send({ id: 2, method: "turn/start", params: turnParams() });
          return;
        }
        if (message.id === 2 && message.result?.turn) {
          const t = message.result.turn;
          if (!nativeIdOk(t.id)) {
            await finish("UNCERTAIN", "Invalid native turn identity.");
            return;
          }
          await update({ turnId: t.id });
          return;
        }
        if (message.method && message.id !== void 0) {
          send({ id: message.id, error: { code: -32e3, message: "Agent transport requires native/manual handling for server requests." } });
          await finish("INTERRUPTED", "Native input/security request requires the owned native interface; refused automatically.");
          return;
        }
        const p = message.params;
        if (!p || p.threadId !== observation.sessionId || observation.turnId && (p.turnId ?? p.turn?.id) !== observation.turnId) return;
        if (message.method === "item/agentMessage/delta") {
          await update({}, "PROGRESS");
          return;
        }
        if (message.method === "item/completed" && p.item?.type === "agentMessage" && typeof p.item.text === "string") {
          resultText = bounded(p.item.text, 32 * 1024);
          await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
        }
        if (message.method === "turn/completed") {
          if (!observation.turnId && nativeIdOk(p.turn?.id)) await update({ turnId: p.turn.id });
          if (p.turn?.id !== observation.turnId) {
            await finish("UNCERTAIN", "Native completion identity mismatch.");
            return;
          }
          if (!["completed", "failed", "interrupted"].includes(p.turn.status)) {
            await finish("UNCERTAIN", "Unknown native terminal status; retain owned leases.");
            return;
          }
          await finish(p.turn.status === "completed" ? "COMPLETED" : p.turn.status === "interrupted" ? "INTERRUPTED" : "FAILED", p.turn.status === "completed" ? null : "Native turn did not complete successfully.", true);
        }
      } else if (selection.transport === "codex-cli") {
        if (message.type === "thread.started" && nativeIdOk(message.thread_id)) {
          if (resumeId && resumeId !== message.thread_id) {
            await finish("UNCERTAIN", "Resumed native session mismatch.");
            return;
          }
          await update({ sessionId: message.thread_id });
        } else if (message.type === "item.completed" && message.item?.type === "agent_message" && typeof message.item.text === "string") {
          resultText = bounded(message.item.text, 32 * 1024);
          await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
        } else if (message.type === "turn.completed") {
          if (observation.sessionId) {
            cliCompleted = true;
            nativeTerminal = true;
          } else await finish("UNCERTAIN", "Native session identity missing.");
        } else if (message.type === "turn.failed") {
          nativeTerminal = true;
          await update({ reason: "Native CLI reported failed turn." });
        } else if (message.type === "error") await finish("FAILED", "Native CLI reported failure.");
        else if (message.type === "item.started") await update({}, "PROGRESS");
      } else {
        if (message.type === "system" && message.subtype === "init") {
          if (!nativeIdOk(message.session_id) || resumeId && resumeId !== message.session_id) {
            await finish("UNCERTAIN", "Native session identity mismatch.");
            return;
          }
          await update({ sessionId: message.session_id, observedIdentity: { model: typeof message.model === "string" ? bounded(message.model, 160) : null, effort: null, accountId: null } });
        } else if (message.type === "stream_event") await update({}, "PROGRESS");
        else if (message.type === "assistant") {
          const text = Array.isArray(message.message?.content) ? message.message.content.filter((b) => b.type === "text" && typeof b.text === "string").map((b) => b.text).join("\n") : "";
          if (text) {
            resultText = bounded(text, 32 * 1024);
            await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
          }
        } else if (message.type === "result") {
          if (message.session_id !== observation.sessionId) {
            await finish("UNCERTAIN", "Native result session mismatch.");
            return;
          }
          if (typeof message.result === "string") resultText = bounded(message.result, 32 * 1024);
          nativeTerminal = true;
          if (!message.is_error && message.subtype === "success") cliCompleted = true;
          else await update({ reason: "Native CLI reported failed result." });
        }
      }
    };
    try {
      if (!stillAuthorized()) throw Error("Native authority revoked before spawn.");
      child = this.spawnProcess(selection.executable, nativeLaunchArguments(task, resumeId), { cwd: selection.cwd, env: nativeEnvironment(selection), windowsHide: true, shell: false, stdio: ["pipe", "pipe", "pipe"] });
      child.on("error", () => enqueue(() => finish("UNCERTAIN", "Native process startup outcome uncertain; no blind retry.")));
      child.stdin.on("error", () => enqueue(() => finish("UNCERTAIN", "Native stdin failed after launch; no blind retry.")));
      child.on("spawn", () => enqueue(async () => {
        await update({ state: "RUNNING" });
        if (selection.transport === "codex-app-server") send({ id: 0, method: "initialize", params: { clientInfo: { name: "datapass_agent", title: "DataPass Agent", version: "1.0.0" } } });
        else child.stdin.end(task.text + "\n");
      }));
      let totalBytes = 0, totalRecords = 0;
      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (data) => {
        if (finished) return;
        buffer += data;
        totalBytes += Buffer.byteLength(data);
        if (buffer.length > 1024 * 1024 || totalBytes > 8 * 1024 * 1024) {
          enqueue(() => finish("UNCERTAIN", "Native output exceeded bounded parser limit."));
          return;
        }
        let newline;
        while ((newline = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, newline);
          buffer = buffer.slice(newline + 1);
          if (!line.trim()) continue;
          if (++totalRecords > 2e4) {
            enqueue(() => finish("UNCERTAIN", "Native event count exceeded bounded parser limit."));
            return;
          }
          try {
            const message = JSON.parse(line);
            enqueue(() => consume(message));
          } catch {
            enqueue(() => finish("UNCERTAIN", "Malformed native event; no retry."));
          }
        }
      });
      child.stderr.on("data", () => {
      });
      child.on("close", (code, signal) => enqueue(async () => {
        if (buffer.trim()) {
          try {
            await consume(JSON.parse(buffer));
          } catch {
            await finish("UNCERTAIN", "Incomplete native event on process close.");
          }
        }
        if (!finished) await finish(cancelRequested ? "INTERRUPTED" : code === 0 && cliCompleted ? "COMPLETED" : nativeTerminal ? "FAILED" : code === 0 ? "UNCERTAIN" : "FAILED", cancelRequested ? "Owned process cancellation observed." : code === 0 && cliCompleted ? null : "Native process exited without a matching successful completion event.", !cancelRequested && nativeTerminal);
      }));
    } catch {
      await finish("UNCERTAIN", "Native spawn attempt could not be confirmed; intent is retained, no blind retry.");
    }
    return handle;
  }
};

// src/provider-kit/nativeFacade.ts
var fs9 = __toESM(require("node:fs/promises"));
var path9 = __toESM(require("node:path"));
var NativeTransportFacade = class {
  constructor(runner, policy, hostId, review, trusted = () => true, reviewProject = async () => false) {
    this.runner = runner;
    this.policy = policy;
    this.hostId = hostId;
    this.review = review;
    this.trusted = trusted;
    this.reviewProject = reviewProject;
    this.api = Object.freeze({
      major: 1,
      version: nativeTransportVersion,
      reviewProjectScope: async (i) => this.projectScope(i),
      preflight: async (r, s2) => {
        this.selection(r, s2);
        return preflightNativeTransport(s2);
      },
      prepare: async (r, i) => this.prepare(r, i),
      review: async (r, h) => this.approve(r, h),
      start: async (r, i) => this.start(r, i),
      lookup: async (r, i) => this.lookup(r, i.taskId),
      cancel: async (r, i) => {
        await this.lookupRequired(r, i.taskId);
        return this.runner.cancel(i.taskId);
      },
      subscribe: async (r, i, listener) => {
        await this.lookupRequired(r, i.taskId);
        const handle = this.handles.get(i.taskId);
        if (!handle) throw Error("Owned live stream unavailable; poll the durable ledger.");
        return handle.subscribe((event) => {
          if (this.allowed(r, event.observation)) listener(event);
        });
      },
      getRoleRuntime: async (i) => this.roleRuntime(i)
    });
  }
  api;
  preparations = /* @__PURE__ */ new Map();
  handles = /* @__PURE__ */ new Map();
  executionPolicies = /* @__PURE__ */ new Map();
  projectScopes = /* @__PURE__ */ new Map();
  activePolicy(r) {
    const execution = this.executionPolicies.get(r?.scope?.scopeId);
    return execution?.authorize(r) ? execution : this.policy.authorize(r) ? this.policy : void 0;
  }
  async projectScope(input) {
    const i = structuredClone(input);
    if (!this.trusted()) throw Error("Trusted owned workspace is required.");
    await verifyNativeProjectScope(i);
    const { revision, ...stable } = i, scopeId = "native-project:" + nativeHash(stable).slice(0, 32), existing = this.executionPolicies.get(scopeId);
    if (existing && nativeHash(this.projectScopes.get(scopeId)) === nativeHash(i)) {
      const scope2 = existing.scopes()[0];
      return { approved: true, scope: scope2, epoch: existing.epoch, scopeHash: digest(scope2) };
    }
    const approved = await this.reviewProject(i);
    if (!approved) return { approved: false, scope: null, epoch: existing?.epoch ?? 0, scopeHash: null };
    if (!this.trusted()) throw Error("Workspace trust changed during local review.");
    await verifyNativeProjectScope(i);
    const scope = { scopeId, organizationIds: [i.organizationId], privacyDomainIds: [i.privacyDomainId], projectIds: [i.projectId], repoIds: [repoId(i.root)], sourceVectorHash: i.sourceVectorHash, policyHash: i.policyHash };
    if (!existing && this.executionPolicies.size >= 100) throw Error("Native project scope bound exceeded.");
    const policy = existing ?? new ScopePolicy();
    policy.set({ scope, roots: [i.root], sessionKeys: [], configuration: false, exportConsent: false });
    this.executionPolicies.set(scopeId, policy);
    this.projectScopes.set(scope.scopeId, i);
    return { approved: true, scope: structuredClone(scope), epoch: policy.epoch, scopeHash: digest(scope) };
  }
  selection(r, s2) {
    const p = this.activePolicy(r), g = p?.authorize(r);
    if (!this.trusted() || !g || s2.hostId !== this.hostId || !g.roots.includes(s2.cwd) || !g.scope.repoIds.includes(repoId(s2.cwd))) throw Error("Reviewed Agent target and current trusted host scope are required.");
  }
  allowed(r, o) {
    return !!this.activePolicy(r) && this.trusted() && digest(r.scope) === o.scopeHash;
  }
  async prepare(r, i) {
    const request = structuredClone(r), task = prepareNativeTask(i);
    this.selection(request, task.selection);
    const project = this.projectScopes.get(request.scope.scopeId);
    if (project) await verifyNativeProjectScope(project);
    if (task.scopeHash !== digest(request.scope)) throw Error("Exact reviewed scope hash mismatch.");
    if (this.preparations.size >= 100) throw Error("Prepared native task bound exceeded.");
    if (await this.runner.lookup(task.taskId)) throw Error("Task already has a durable spawn intent; do not retry.");
    this.preparations.set(task.preparedHash, { task, request, epoch: this.activePolicy(request).epoch, approved: false });
    return structuredClone(task);
  }
  prepared(r, hash) {
    const p = this.preparations.get(hash);
    if (!p || p.epoch !== this.activePolicy(r)?.epoch || digest(r.scope) !== p.task.scopeHash || !this.trusted()) throw Error("Prepared native task scope/epoch is stale or unavailable.");
    this.selection(r, p.task.selection);
    return p;
  }
  async approve(r, hash) {
    const p = this.prepared(r, hash), check = await preflightNativeTransport(p.task.selection);
    if (check.state !== "READY") throw Error("Native startup effects or capabilities are blocked: " + check.reasons.join(" "));
    const accepted = await this.review(structuredClone(p.task));
    this.prepared(r, hash);
    p.approved = accepted;
    return { approved: accepted, preparedHash: hash };
  }
  async start(r, i) {
    const p = this.prepared(r, i.preparedHash);
    if (!p.approved || p.task.taskId !== i.taskId) throw Error("Independent exact host-owned execution approval is required.");
    const project = this.projectScopes.get(r.scope.scopeId);
    if (project) await verifyNativeProjectScope(project);
    p.approved = false;
    const handle = await this.runner.start(p.task, i.preparedHash, () => this.trusted() && p.epoch === this.activePolicy(p.request)?.epoch);
    this.handles.set(i.taskId, handle);
    void handle.result.finally(() => this.handles.delete(i.taskId));
    return handle.observation();
  }
  async lookup(r, id) {
    if (!this.activePolicy(r) || !this.trusted()) throw Error("Reviewed Agent scope is required.");
    const o = await this.runner.lookup(id);
    if (o && !this.allowed(r, o)) throw Error("Owned native task is outside this reviewed scope.");
    return o;
  }
  async lookupRequired(r, id) {
    const o = await this.lookup(r, id);
    if (!o) throw Error("Owned native task unavailable.");
    return o;
  }
  async roleRuntime(i) {
    const unknown = { ...i, state: "UNKNOWN", nativeSessionId: null, nativeReceiptRef: null, observedAt: null };
    if (!hashOk(i.bindingHash) || !hashOk(i.scopeHash) || !this.trusted()) return unknown;
    let files;
    try {
      files = await fs9.readdir(this.runner.ledgerDirectory);
    } catch {
      return unknown;
    }
    const names = files.filter((f) => /^[a-f0-9]{64}\.json$/.test(f));
    if (names.length > 1e3) return unknown;
    const matches = [];
    for (const f of names) {
      try {
        const raw = await fs9.readFile(path9.join(this.runner.ledgerDirectory, f), "utf8");
        if (raw.length > 128 * 1024) continue;
        const o2 = JSON.parse(raw);
        if (o2.bindingHash === i.bindingHash && o2.configScopeHash === i.scopeHash && [...this.policy.scopes(), ...[...this.executionPolicies.values()].flatMap((p) => p.scopes())].some((s2) => digest(s2) === o2.scopeHash)) {
          const current = await this.runner.lookup(o2.taskId);
          if (current) matches.push(current);
        }
      } catch {
      }
    }
    const o = matches.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
    if (!o || !o.sessionId || !["RUNNING", "NEEDS_INPUT", "COMPLETED", "INTERRUPTED", "FAILED"].includes(o.state) || ["COMPLETED", "INTERRUPTED", "FAILED"].includes(o.state) && o.quiescence !== "NATIVE_TURN_SETTLED") return unknown;
    return { ...i, state: ["RUNNING", "NEEDS_INPUT"].includes(o.state) ? "RUNNING" : "STOPPED", nativeSessionId: o.sessionId, nativeReceiptRef: nativeHash(o), observedAt: o.updatedAt };
  }
  async dispose() {
    this.preparations.clear();
    for (const policy of this.executionPolicies.values()) policy.clear();
    this.executionPolicies.clear();
    this.projectScopes.clear();
    await this.runner.dispose();
  }
};

// src/provider-kit/index.ts
var providerKitVersion = "1.1.0";
var providerKitSchema = "datapass.provider-kit-capture/1";
async function captureConfiguration(input) {
  if (!input || !["codex", "claude"].includes(input.provider) || !["CLI", "Desktop", "IDE", "API"].includes(input.surface) || !/^[a-f0-9]{64}$/.test(input.policyHash) || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(input.hostId) || !Array.isArray(input.roots) || input.roots.length > 60 || input.roots.some((r) => !isPlausibleLocalPath(r) || hasLinkedAncestor(r)) || !input.homes || ![input.homes.codexHome, input.homes.claudeHome, input.homes.managedFile].every(isPlausibleLocalPath) || [input.nativeVersion, input.accountId].some((v) => v !== null && (typeof v !== "string" || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(v)))) throw new Error("Invalid reviewed capture selection.");
  const selection = structuredClone(input);
  const read = await collectConfiguration(selection, selection.provider, [], selection.homes);
  const capturedAt = new Date(read.at).toISOString();
  const identity = { provider: selection.provider, surface: selection.surface, nativeVersion: selection.nativeVersion, hostId: selection.hostId, accountId: selection.accountId };
  const sourceRefs = [...read.sources.keys()].map((id) => ({ id, kind: "LOCAL_FILE", observedAt: capturedAt }));
  const configuration = read.config;
  const hashConfig = structuredClone(configuration);
  for (const fact of Object.values(hashConfig.effective)) delete fact.observedAt;
  return {
    schema: providerKitSchema,
    kitVersion: providerKitVersion,
    capturedAt,
    sourceHash: sha256(canonicalJson({ identity, configuration: hashConfig, sources: sourceRefs.map((s2) => s2.id), policyHash: selection.policyHash })),
    identity,
    configuration,
    sourceRefs,
    omissions: [
      "Safe observed projection hash; not an exact-byte backup of native files.",
      "CLI overrides, managed native resolution and session-effective state remain PARTIAL.",
      "No auth files, environment values, hook payloads, MCP args/URLs/headers or instruction content.",
      "Installed/configured does not prove authentication or tool usability.",
      "No history reader, provider task launch, config apply or CLI execution."
    ]
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  NativeTaskRunner,
  NativeTransportFacade,
  captureConfiguration,
  defaultHomes,
  hashOk,
  nativeEnvironment,
  nativeHash,
  nativeIdOk,
  nativeLaunchArguments,
  nativeTransportVersion,
  preflightNativeTransport,
  prepareNativeTask,
  providerKitSchema,
  providerKitVersion,
  readNativeRepositoryIdentity,
  safeLocalSource,
  validateNativeSelection,
  verifyNativeProjectScope
});

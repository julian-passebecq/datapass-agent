import type { EvidenceKind, SessionStatus, TestObservation, TestOutcome } from '../model';
/** What a checking command is. Only `test` counts as a test; builds, lints and type checks are their own kinds. */
export type CheckKind = 'test' | 'typecheck' | 'lint' | 'build';
/** One command of a shell line. `masked` has quoted strings emptied; `sep` is the separator before it. */
export interface CommandSegment {
    text: string;
    masked: string;
    sep: '' | 'newline' | '&&' | '||' | ';' | '|';
}
/**
 * Splits a shell line into commands at newline, `&&`, `||`, `;` and `|` outside quotes (heredoc bodies dropped).
 * `2>&1` and other redirections are not separators.
 */
export declare function commandSegments(cmd: string): CommandSegment[];
/** Kind of one command (matched at command position only), or undefined when it is not a check. */
export declare function segmentKind(seg: CommandSegment): CheckKind | undefined;
/** Kind of a shell line: `test` when any command of it is a test, else the first build / lint / typecheck. */
export declare function checkKind(cmd: string): CheckKind | undefined;
/**
 * A command counts as a test only by the program it runs at command position, never by what its arguments,
 * quoted strings or output say (`grep -rn tsc`, `echo go build`, `git log --grep="npm test"` are not tests).
 * Builds, lints and type checks are not tests (TestObservation has no kind field to keep them apart).
 */
export declare function isVerificationCommand(cmd: string): boolean;
/** The test command of a line plus the commands it pipes into, e.g. "npm test" out of "printf … > a.js && npm test && git commit". */
export declare function verificationLabel(cmd: string): string;
/** True when the test of `cmd` pipes into another command: its own exit status is hidden behind the pipeline's. */
export declare function isPipedTest(cmd: string): boolean;
export declare function stripHeredocs(cmd: string): string;
/** Display form of a command: drops a leading `cd <dir> &&` that only sets the working directory. */
export declare function commandLabel(cmd: string): string;
export declare function isGitCommit(cmd: string): boolean;
/** Codex wraps commands as ["powershell.exe","-Command","..."] or ["bash","-lc","..."]; keep the script part. */
export declare function commandText(cmd: unknown): string;
export interface LiveSignal {
    /** Provider says the session is ended (or its artifact was archived). */
    explicitEnded?: boolean;
    /** Live registry entry exists and its process is alive. */
    registryAlive?: boolean;
    registryStatus?: string;
    /** A turn started and has not completed/aborted. */
    openTurn?: boolean;
    lastActivityAt?: number;
    /** Process for a non-interactive run is known to have finished (e.g. codex exec turn complete). */
    oneShotDone?: boolean;
    /** The provider exposes a live registry, so its absence means the process is gone. */
    providerHasRegistry?: boolean;
}
/** Conservative status derivation (documented in README "Live status"). */
export declare function deriveStatus(s: LiveSignal, now: number, idleMs: number): {
    status: SessionStatus;
    reason: string;
};
/** Reason of an end inferred from the absence of a live registry entry (no end event was recorded). */
export declare const REGISTRY_GONE = "no live registry entry: process no longer active (inferred, no end recorded)";
/** True when an ENDED status is only inferred (registry entry gone), not recorded by the provider. */
export declare function endInferred(s: {
    status: SessionStatus;
    statusReason?: string;
}): boolean;
export declare const CHAIN_MARK = " \u00B7 in command chain";
export declare const PIPE_MARK = " \u00B7 piped";
/**
 * Bounded, redacted test label. A chained test is marked (its recorded outcome is the whole chain's status);
 * a piped test is marked "piped" (its own exit status is hidden behind the pipeline's).
 */
export declare function testLabel(cmd: string): string;
export interface TestVerdict {
    outcome: TestOutcome;
    kind: EvidenceKind;
    basis: string;
}
/**
 * Outcome of one test observation as far as it is evidence for the test itself. A chained or piped command
 * whose provider only recorded a tool error flag gets UNKNOWN (the flag is the last command's status, not the
 * test's). With a recorded exit code the outcome stays, labelled as the exit status of the whole line.
 */
export declare function testVerdict(t: Pick<TestObservation, 'command' | 'outcome' | 'source'>): TestVerdict;
/** Status as display text with its evidence kind: an inferred end reads "no longer active (inferred)". */
export declare function statusEvidenceOf(s: {
    status: SessionStatus;
    statusReason?: string;
    provider?: string;
}): {
    text: string;
    kind: EvidenceKind;
    basis: string;
};

export interface ProcessMetadata {
    pid: number;
    alive: boolean | null;
    name: string | null;
    parentPid: number | null;
    startedAt: string | null;
    source: 'LOCAL_CIM_PID_QUERY' | 'LOCAL_PID_EXISTENCE';
}
export type ProcessLookup = {
    state: 'OBSERVED' | 'ABSENT' | 'BLOCKED';
    process: ProcessMetadata;
    reason?: 'PID_LOOKUP_DENIED' | 'PID_METADATA_INVALID';
};
export declare const validPid: (pid: unknown) => pid is number;
/** One reviewed PID only. Never reads arguments, environment, executable path, or unrelated processes. */
export declare function readProcessMetadata(pid: number): Promise<ProcessLookup>;

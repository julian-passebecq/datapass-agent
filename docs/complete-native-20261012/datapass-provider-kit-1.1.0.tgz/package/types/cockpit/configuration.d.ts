import { defaultHomes } from '../feeds/settings';
import type { LocalGrant } from './policy';
import type { ProviderConfig, SessionRef } from './interfaces';
export interface ConfigRead {
    config: ProviderConfig;
    sources: Map<string, string>;
    at: number;
}
/** Reject linked ancestors before either collection or reveal; source files are inert. */
export declare function safeLocalSource(file: string): Promise<boolean>;
/** Panel reads are synchronous. Recheck linked ancestors without reading source content. */
export declare function safeLocalPathSync(file: string, kind?: 'file' | 'directory'): boolean;
export declare function localSourceIdentity(file: string): string | null;
export declare function readConfiguration(grant: LocalGrant, provider: 'codex' | 'claude', sessions: SessionRef[], homes?: {
    claudeHome: string;
    codexHome: string;
    managedFile: string;
}): Promise<ConfigRead>;
/** Shared inert collector. Clients must review roots themselves; this does not create an Agent grant. */
export declare function collectConfiguration(selection: {
    roots: string[];
    policyHash: string;
}, provider: 'codex' | 'claude', sessions: SessionRef[], homes: ReturnType<typeof defaultHomes>): Promise<ConfigRead>;

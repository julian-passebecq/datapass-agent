import type { Request, Scope } from './interfaces';
import type { AgentSessionSnapshot } from '../model';
export declare const digest: (value: unknown) => string;
export declare const repoId: (root: string) => string;
export declare const idOk: (v: unknown) => v is string;
export interface LocalGrant {
    scope: Scope;
    sessionKeys: string[];
    roots: string[];
    configuration: boolean;
    exportConsent: boolean;
}
export declare function makeGrant(input: {
    id: string;
    organization: string;
    project: string;
    privacy: string;
    sessions: AgentSessionSnapshot[];
    configuration: boolean;
    exportConsent: boolean;
}): LocalGrant;
export declare function validateRequest(value: unknown): value is Request;
/** Only host-owned grants authorize; request fields never create grants. */
export declare class ScopePolicy {
    private grants;
    private revision;
    get epoch(): number;
    set(grant: LocalGrant): void;
    clear(): void;
    scopes(): Scope[];
    authorize(request: Request): LocalGrant | undefined;
    sessions(g: LocalGrant, sessions: AgentSessionSnapshot[]): AgentSessionSnapshot[];
}

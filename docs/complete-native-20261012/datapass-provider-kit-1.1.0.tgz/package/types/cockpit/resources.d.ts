import type { LocalGrant } from './policy';
import type { ProcessLookup, ProcessMetadata } from './processMetadata';
import type { AgentSessionSnapshot } from '../model';
export interface SelectedFileResource {
    id: string;
    file: string;
    kind: 'SCRIPT' | 'LOCK' | 'TASK_METADATA' | 'FILE';
    enabled: boolean | null;
    staleAfterMs: number | null;
}
export interface SelectedProcessResource {
    id: string;
    pid: number;
    kind: 'PROCESS';
    expectedStartedAt: string | null;
}
export type SelectedResource = SelectedFileResource | SelectedProcessResource;
export interface ResourceTimeRelation {
    sessionId: string;
    timestampKind: 'FILE_MODIFICATION' | 'PROCESS_CREATION';
    relation: 'BEFORE_RECORDED_WINDOW' | 'WITHIN_RECORDED_WINDOW' | 'AFTER_RECORDED_WINDOW';
    recordedStartAt: string;
    recordedEndAt: string;
}
export interface ResourceObservation {
    id: string;
    kind: SelectedResource['kind'];
    state: 'OBSERVED' | 'DISABLED' | 'STALE' | 'ABSENT' | 'BLOCKED';
    bytes: number | null;
    modifiedAt: string | null;
    enabled: boolean | null;
    enabledBasis: 'HOST_REVIEWED_ASSERTION' | 'UNKNOWN';
    capturedAt: string;
    causality: 'UNKNOWN';
    process?: ProcessMetadata;
    reason?: string;
    timeRelations?: ResourceTimeRelation[];
    timeRelationCoverage?: {
        eligibleRecordedWindows: number;
        unavailableRecordedWindows: number;
        returned: number;
        complete: boolean;
        basis: string;
    };
}
/** Timestamp comparison only: a file modification or process birth is not proof of execution or causality. */
export declare function correlateResourceTime(observation: ResourceObservation, sessions: AgentSessionSnapshot[]): ResourceObservation;
/** Metadata-only read of exact host-reviewed resources. No task/script execution, watcher repair, or process kill. */
export declare function observeResources(selection: SelectedResource[], stillAuthorized: () => boolean, processReader?: (pid: number) => Promise<ProcessLookup>, sessions?: AgentSessionSnapshot[]): Promise<ResourceObservation[]>;
export declare function validateResources(grant: LocalGrant, items: SelectedResource[]): void;

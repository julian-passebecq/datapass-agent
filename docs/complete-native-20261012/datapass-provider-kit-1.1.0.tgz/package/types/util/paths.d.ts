/** True when `candidate` resolves (following symlinks) to a location inside `root`. Rejects traversal and injected paths. */
export declare function isInside(root: string, candidate: string): boolean;
/** Absolute local path with no NUL, no UNC/device prefix, no URL scheme. Used for cwd values read from artifacts. */
export declare function isPlausibleLocalPath(p: unknown): p is string;
export declare function normalizeCase(p: string): string;
/** Read-only feeds never follow a linked file or directory into another scope. */
export declare function hasLinkedAncestor(file: string): boolean;
/** Repo-relative display path when `file` is inside `root`. */
export declare function relTo(root: string | undefined, file: string): string;
/** Long, case-correct path when it (or its parent, for deleted files) exists; otherwise unchanged. */
export declare function canonical(p: string): string;

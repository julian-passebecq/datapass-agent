import type { CatalogReport, CliInfo } from '../feeds/catalog';
import { LayerKind, SettingsReport } from '../feeds/settings';
import { EvidenceKind } from '../model';
import { CONFIG_SNAPSHOT_SCHEMA, PathRef } from './index';
export interface GalaxyClaudeLayer {
    kind: LayerKind;
    /** Repository of a project / local layer. */
    root?: PathRef;
    model?: string;
    effortLevel?: string;
    defaultMode?: string;
    outputStyle?: string;
    allow: number;
    deny: number;
    ask: number;
    /** Hook events with a hook in this layer (commands are never exported). */
    hookEvents: string[];
    hooks: number;
    /** Count of env variables set (names and values are never exported). */
    env: number;
    enabledPlugins: string[];
    apiKeyHelper: boolean;
}
export interface GalaxyCodexConfig {
    scope: 'user' | 'project';
    root?: PathRef;
    model?: string;
    effort?: string;
    approval?: string;
    sandbox?: string;
    serviceTier?: string;
    profile?: string;
    profiles: string[];
    mcpServers: string[];
    features: {
        name: string;
        on: boolean;
    }[];
    plugins: {
        name: string;
        on: boolean;
    }[];
    trustedProjects: number;
    notify: boolean;
}
export interface GalaxyConfigContent {
    claude?: {
        layers: GalaxyClaudeLayer[];
        /** User-scope effective values (managed > user), DERIVED from the layers. */
        effective: {
            model?: string;
            effortLevel?: string;
            defaultMode?: string;
        };
        /** Distinct permission rules over the user-scope layers, DERIVED. */
        rules: {
            allow: number;
            deny: number;
            ask: number;
            hooks: number;
        };
        /** Subagent / skill / command / output-style names from the settings feed. */
        items: {
            kind: string;
            scope: 'user' | 'project';
            name: string;
        }[];
    };
    codex?: GalaxyCodexConfig[];
    catalog?: {
        items: {
            provider: string;
            kind: string;
            source: string;
            name: string;
            active: boolean;
            plugin?: string;
        }[];
        plugins: {
            provider: string;
            id: string;
            version?: string;
            enabled?: boolean;
            installed: boolean;
        }[];
        hooks: {
            event: string;
            matcher: string;
            type: string;
            program: string;
            source: string;
        }[];
        mcp: {
            provider: string;
            name: string;
            transport: string;
            source: string;
        }[];
        /** Distinct settings key names (values are never exported). */
        settingsKeys: string[];
    };
    /** CLI probes (Catalog `--version`), when that opt-out probe ran. */
    cli?: {
        tool: string;
        status: string;
        version?: string;
    }[];
}
export interface GalaxyConfigSnapshot extends GalaxyConfigContent {
    schema: typeof CONFIG_SNAPSHOT_SCHEMA;
    capturedAt: string;
    /** sha256 of the canonical JSON of the content (everything except schema, capturedAt, contentHash, kinds). */
    contentHash: string;
    kinds: Record<string, EvidenceKind>;
}
export interface ConfigSnapshotInput {
    settings?: SettingsReport;
    catalog?: CatalogReport;
    cli?: CliInfo[];
    capturedAt: number;
}
/** Projects whatever feeds are available; a missing feed leaves its section out (UNKNOWN), never empty-as-fact. */
export declare function toConfigSnapshot(input: ConfigSnapshotInput): GalaxyConfigSnapshot;

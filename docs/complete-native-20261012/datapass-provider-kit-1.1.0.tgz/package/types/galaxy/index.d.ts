export declare const OBSERVATION_SCHEMA: "galaxy.agent-observation/1";
export declare const CONFIG_SNAPSHOT_SCHEMA: "galaxy.agent-config-snapshot/1";
export declare const GALAXY_SCHEMAS: readonly ["galaxy.agent-observation/1", "galaxy.agent-config-snapshot/1"];
/** A local path as Galaxy may see it: the folder name and a stable hash, never the absolute path. */
export interface PathRef {
    name: string;
    /** sha256 of the normalised path (lower case, forward slashes, no trailing slash), first 16 hex chars. */
    hash: string;
}
export declare function sha256(text: string): string;
export declare function pathRef(p: string | undefined): PathRef | undefined;
export declare function iso(ms: number | undefined): string | undefined;
/** JSON with object keys sorted at every level, so equal content always hashes the same. */
export declare function canonicalJson(v: unknown): string;
/** Drops undefined fields (Galaxy documents never carry "undefined"; an absent field means not exposed). */
export declare function compactObj<T extends object>(o: T): T;
/** Minimal structural check of a projected document: right schema id, ISO capturedAt, kinds from the grammar. */
export declare function validateGalaxyDoc(doc: unknown): string[];

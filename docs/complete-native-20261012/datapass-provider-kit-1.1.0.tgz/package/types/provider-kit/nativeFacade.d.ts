import type { Request, Scope } from '../cockpit/interfaces';
import { ScopePolicy } from '../cockpit/policy';
import { NativeSelection, NativeTaskInput, PreparedNativeTask, nativeTransportVersion, preflightNativeTransport } from './nativeTransport';
import { NativeTaskRunner, NativeTaskObservation, NativeTaskEvent } from './nativeRunner';
import { NativeProjectScopeInput } from './nativeProjectScope';
export interface NativeRoleRuntime {
    bindingHash: string;
    scopeHash: string;
    state: 'RUNNING' | 'STOPPED' | 'UNKNOWN';
    nativeSessionId: string | null;
    nativeReceiptRef: string | null;
    observedAt: string | null;
}
export interface NativeTransportApi {
    readonly major: 1;
    readonly version: typeof nativeTransportVersion;
    reviewProjectScope(input: NativeProjectScopeInput): Promise<{
        approved: boolean;
        scope: Scope | null;
        epoch: number;
        scopeHash: string | null;
    }>;
    preflight(request: Request, selection: NativeSelection): ReturnType<typeof preflightNativeTransport>;
    prepare(request: Request, input: NativeTaskInput): Promise<PreparedNativeTask>;
    review(request: Request, preparedHash: string): Promise<{
        approved: boolean;
        preparedHash: string;
    }>;
    start(request: Request, input: {
        taskId: string;
        preparedHash: string;
    }): Promise<NativeTaskObservation>;
    lookup(request: Request, input: {
        taskId: string;
    }): Promise<NativeTaskObservation | null>;
    cancel(request: Request, input: {
        taskId: string;
    }): Promise<NativeTaskObservation>;
    subscribe(request: Request, input: {
        taskId: string;
    }, listener: (event: NativeTaskEvent) => void): Promise<{
        dispose(): void;
    }>;
    getRoleRuntime(input: {
        bindingHash: string;
        scopeHash: string;
    }): Promise<NativeRoleRuntime>;
}
/** Only this host-owned facade is exported by the installed Agent; observer scope does not grant execution. */
export declare class NativeTransportFacade {
    private runner;
    private policy;
    private hostId;
    private review;
    private trusted;
    private reviewProject;
    readonly api: NativeTransportApi;
    private preparations;
    private handles;
    private executionPolicies;
    private projectScopes;
    constructor(runner: NativeTaskRunner, policy: ScopePolicy, hostId: string, review: (task: PreparedNativeTask) => Promise<boolean>, trusted?: () => boolean, reviewProject?: (input: NativeProjectScopeInput) => Promise<boolean>);
    private activePolicy;
    private projectScope;
    private selection;
    private allowed;
    private prepare;
    private prepared;
    private approve;
    private start;
    private lookup;
    private lookupRequired;
    private roleRuntime;
    dispose(): Promise<void>;
}

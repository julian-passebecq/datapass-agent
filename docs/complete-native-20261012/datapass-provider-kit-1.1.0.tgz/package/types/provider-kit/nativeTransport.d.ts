export declare const nativeTransportVersion: "1.0.0";
export type NativeTransport = 'codex-app-server' | 'codex-cli' | 'claude-cli';
export interface NativeIdentity {
    model: string;
    effort: string | null;
    accountId: string | null;
}
export interface NativeSelection {
    transport: NativeTransport;
    /** Regular executable, never a shell, script shim, PATH lookup or caller-supplied argv. */
    executable: string;
    executableSha256: string;
    nativeVersion: string;
    cwd: string;
    home: string;
    hostId: string;
    permission: 'read-only' | 'workspace-write';
    requestedIdentity: NativeIdentity;
    /** Reviewed exact startup effect inventory; local host must independently approve its digest. */
    startup: {
        reviewHash: string;
        configurationHash: string;
        hooks: 'NONE' | 'REVIEWED';
        mcp: 'NONE' | 'REVIEWED';
        managed: 'NONE' | 'REVIEWED';
        isolated: boolean;
        supported: string[];
    };
}
export interface NativeTaskInput {
    selection: NativeSelection;
    taskId: string;
    text: string;
    targetHash: string;
    permissionHash: string;
    configHash: string;
    presetHash: string;
    promptHash: string;
    bindingHash: string;
    scopeHash: string;
    configScopeHash: string;
    /** Only an Agent-owned, completed/interrupted session ledger can be resumed. */
    resumeFromTaskId?: string;
}
export interface PreparedNativeTask extends NativeTaskInput {
    schema: 'datapass.native-task/1';
    preparedHash: string;
}
export interface NativePreflight {
    schema: 'datapass.native-preflight/1';
    version: typeof nativeTransportVersion;
    state: 'READY' | 'BLOCKED';
    selectionHash: string;
    reasons: string[];
    capabilities: {
        start: boolean;
        stream: boolean;
        resume: boolean;
        cancel: 'OWNED_TURN' | 'OWNED_PROCESS';
        securityRequests: 'NATIVE_REFUSAL';
        observedIdentity: 'PROVIDER_EVIDENCE_ONLY';
    };
}
export declare const nativeHash: (value: unknown) => string;
export declare const hashOk: (v: unknown) => v is string;
export declare const nativeIdOk: (v: unknown) => v is string;
export declare function validateNativeSelection(s: NativeSelection): boolean;
export declare function preflightNativeTransport(selection: NativeSelection): Promise<NativePreflight>;
export declare function prepareNativeTask(input: NativeTaskInput): PreparedNativeTask;
/** Fixed native command vocabulary. Prompt is delivered over stdin, never shell text or argv. */
export declare function nativeLaunchArguments(task: PreparedNativeTask, resumeId?: string): string[];
/** Deliberately no inherited PATH, credentials, command hooks, agents or token environment. Native owns auth in reviewed home. */
export declare function nativeEnvironment(selection: NativeSelection): NodeJS.ProcessEnv;

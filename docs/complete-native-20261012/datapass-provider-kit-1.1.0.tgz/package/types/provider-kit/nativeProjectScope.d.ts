export interface NativeProjectScopeInput {
    organizationId: string;
    privacyDomainId: string;
    projectId: string;
    repoId: string;
    root: string;
    revision: string;
    sourceVectorHash: string;
    policyHash: string;
}
export interface NativeRepositoryIdentity {
    root: string;
    revision: string;
    repoId: string;
    remoteHost: string;
    commonDirectory: string;
}
/** Inert Git identity lookup with hardened executable and config; no network, hooks, history or task. */
export declare function verifyNativeProjectScope(input: NativeProjectScopeInput): Promise<void>;
/** Reused for execution project grants and durable native write leases. No external-writer inference. */
export declare function readNativeRepositoryIdentity(root: string): Promise<NativeRepositoryIdentity>;

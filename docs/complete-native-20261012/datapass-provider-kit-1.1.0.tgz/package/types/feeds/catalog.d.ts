import { CodexConfig, LayerKind } from './settings';
export type Provider = 'claude' | 'codex';
/** Where an item comes from. `system` = shipped with the CLI (Codex .system skills). */
export type Source = 'user' | 'project' | 'local' | 'plugin' | 'system' | 'managed';
export type ItemKind = 'skill' | 'agent' | 'command' | 'output-style' | 'prompt';
export interface CatItem {
    provider: Provider;
    kind: ItemKind;
    source: Source;
    /** Plugin id (name@marketplace or name) when source = plugin. */
    plugin?: string;
    /** False for an item of a plugin that is available in a marketplace but neither installed nor enabled. */
    active: boolean;
    root?: string;
    file: string;
    name: string;
    description?: string;
    model?: string;
    effort?: string;
    tools?: string;
    argumentHint?: string;
    /** Skills: files in the skill folder (DERIVED, capped). */
    files?: number;
}
export interface PluginInfo {
    provider: Provider;
    id: string;
    name: string;
    marketplace?: string;
    version?: string;
    description?: string;
    /** undefined = not mentioned in any enabledPlugins / config. */
    enabled?: boolean;
    installed: boolean;
    dir: string;
    manifest?: string;
    skills: number;
    agents: number;
    commands: number;
    hooks: number;
    mcp: number;
    /** Repos whose project settings enable / disable it. */
    projects: string[];
}
export interface HookRow {
    event: string;
    matcher: string;
    type: string;
    /** Program name only (basename of the first word), plus a script basename when the second word is a script. */
    program: string;
    source: Source;
    plugin?: string;
    root?: string;
    file: string;
    timeout?: number;
}
export interface McpRow {
    provider: Provider;
    name: string;
    transport: string;
    /** Basename of the command, never its args, env, headers or URL. */
    program?: string;
    source: Source;
    plugin?: string;
    root?: string;
    /** Where it is declared. ~/.claude.json is listed but never offered for opening. */
    file: string;
}
export interface SettingRow {
    key: string;
    /** Scalar value when it is safe to show, else a shape ("set", "3 items"). */
    value: string;
    layer: LayerKind;
    root?: string;
    file: string;
}
export interface InstrFile {
    provider: Provider;
    source: Source;
    root?: string;
    file: string;
    bytes: number;
    lines: number;
    headings: string[];
}
export interface MemoryDir {
    /** Encoded project folder name under ~/.claude/projects. */
    project: string;
    dir: string;
    count: number;
    names: string[];
}
export interface CodexRules {
    file: string;
    rules: number;
}
export interface CliFlag {
    flag: string;
    short?: string;
    arg?: string;
    description: string;
}
export interface CliCommand {
    name: string;
    args?: string;
    description: string;
}
export interface CliInfo {
    tool: Provider;
    status: 'ok' | 'untrusted' | 'missing' | 'error' | 'off';
    exe?: string;
    version?: string;
    error?: string;
    flags: CliFlag[];
    commands: CliCommand[];
    at: number;
}
export interface CatalogReport {
    at: number;
    claudeHome: string;
    codexHome: string;
    roots: string[];
    items: CatItem[];
    plugins: PluginInfo[];
    hooks: HookRow[];
    mcp: McpRow[];
    settings: SettingRow[];
    instructions: InstrFile[];
    memory: MemoryDir[];
    codexConfig?: CodexConfig;
    codexRules: CodexRules[];
    /** Every path the screen may open (validated against it in actions). */
    files: string[];
    errors: string[];
}
export interface CatalogInput {
    claudeHome: string;
    codexHome: string;
    /** ~/.claude.json (MCP server names only are read from it). */
    claudeJson?: string;
    managedFile?: string;
    roots: string[];
    now?: number;
}
/** Counts files under a folder (depth ≤ 4, cap 500). DERIVED. */
export declare function countFiles(dir: string, depth?: number, cap?: number): Promise<number>;
/** Program name of a command line: basename of the first word, plus the basename of a script second word. */
export declare function programOf(command: unknown): string;
/** Heading lines (#, ##, ###) outside code fences. */
export declare function headingsOf(text: string, max?: number): string[];
interface ItemCtx {
    provider: Provider;
    source: Source;
    root?: string;
    plugin?: string;
    active: boolean;
}
/** skills/<name>/SKILL.md (and one nested level for grouped skills). */
export declare function scanSkills(dir: string, c: ItemCtx, out: CatItem[]): Promise<number>;
/** <dir>/*.md, with sub-folders as namespaces (commands/ns/x.md → ns:x), depth ≤ 3. */
export declare function scanMd(dir: string, kind: ItemKind, c: ItemCtx, out: CatItem[], ns?: string, depth?: number): Promise<number>;
export declare function hooksFrom(v: unknown, base: Omit<HookRow, 'event' | 'matcher' | 'type' | 'program' | 'timeout'>, out: HookRow[]): number;
export declare function mcpFrom(v: unknown, base: Omit<McpRow, 'name' | 'transport' | 'program'>, out: McpRow[]): number;
/** Flattens a settings file to depth 2 with safe values only. */
export declare function settingRows(j: Record<string, unknown>, layer: LayerKind, file: string, root: string | undefined, out: SettingRow[]): void;
export declare function collectCatalog(input: CatalogInput): Promise<CatalogReport>;
/** Parses commander (claude) and clap (codex) style --help output into flags and sub-commands. */
export declare function parseHelp(text: string): {
    flags: CliFlag[];
    commands: CliCommand[];
};
export type HelpRunner = (exe: string, args: string[]) => Promise<{
    ok: boolean;
    out: string;
    err: string;
}>;
export declare const execHelp: HelpRunner;
/** `<tool> --version` and `<tool> --help`, cached a day per executable. Untrusted: nothing runs. */
export declare function loadCli(tool: Provider, opts: {
    trusted: boolean;
    enabled: boolean;
    now: number;
    run?: HelpRunner;
    resolve?: (n: string) => string | undefined;
}): Promise<CliInfo>;
export declare function clearCliCache(): void;
export {};

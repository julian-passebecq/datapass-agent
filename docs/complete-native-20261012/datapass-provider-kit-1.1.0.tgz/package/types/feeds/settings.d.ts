export type LayerKind = 'managed' | 'local' | 'project' | 'user';
/** Claude Code precedence, highest first (CC /settings: managed > local project > shared project > user). */
export declare const LAYER_ORDER: LayerKind[];
export interface HookEntry {
    event: string;
    matcher: string;
    type: string;
    /** Redacted, single line, bounded. */
    command: string;
    timeout?: number;
}
export interface ClaudeLayer {
    kind: LayerKind;
    /** Repo root for project / local layers. */
    root?: string;
    file: string;
    exists: boolean;
    bytes?: number;
    mtime?: number;
    error?: string;
    model?: string;
    effortLevel?: string;
    defaultMode?: string;
    outputStyle?: string;
    /** "command: …" (redacted) or "set". */
    statusLine?: string;
    allow: string[];
    deny: string[];
    ask: string[];
    additionalDirectories: number;
    hooks: HookEntry[];
    /** Env variable names only (secret-like names are counted, not listed). */
    envNames: string[];
    envHidden: number;
    enabledPlugins: string[];
    /** Other top-level key names (no values). */
    otherKeys: string[];
    apiKeyHelper: boolean;
}
export interface MdItem {
    kind: 'agent' | 'skill' | 'command' | 'output-style';
    scope: 'user' | 'project';
    root?: string;
    file: string;
    name: string;
    description?: string;
    model?: string;
    effort?: string;
    tools?: string;
    mtime?: number;
}
export interface MemoryFile {
    provider: 'claude' | 'codex';
    scope: 'user' | 'project';
    root?: string;
    file: string;
    bytes: number;
    mtime: number;
    lines: number;
}
export interface CodexProfile {
    name: string;
    model?: string;
    effort?: string;
    approval?: string;
    sandbox?: string;
}
export interface CodexConfig {
    scope: 'user' | 'project';
    root?: string;
    file: string;
    exists: boolean;
    bytes?: number;
    mtime?: number;
    error?: string;
    model?: string;
    effort?: string;
    approval?: string;
    sandbox?: string;
    serviceTier?: string;
    profile?: string;
    profiles: CodexProfile[];
    mcpServers: string[];
    notify: boolean;
    features: {
        name: string;
        on: boolean;
    }[];
    trustedProjects: number;
    plugins: {
        name: string;
        on: boolean;
    }[];
    /** Other table / key names (no values). */
    otherKeys: string[];
}
export interface RootInfo {
    path: string;
    name: string;
}
export interface SettingsReport {
    at: number;
    claudeHome: string;
    codexHome: string;
    roots: RootInfo[];
    layers: ClaudeLayer[];
    items: MdItem[];
    memory: MemoryFile[];
    codex: CodexConfig[];
    /** Every path the screen may open (validated against it in actions). */
    files: string[];
}
export interface SettingsInput {
    claudeHome: string;
    codexHome: string;
    roots: string[];
    managedFile?: string;
    now?: number;
}
export declare function isForbidden(file: string): boolean;
export declare function defaultHomes(): {
    claudeHome: string;
    codexHome: string;
    managedFile: string;
};
export declare function readClaudeLayer(kind: LayerKind, file: string, root?: string): ClaudeLayer;
/** Minimal YAML front-matter reader: top-level `key: value` pairs only. */
export declare function frontMatter(text: string): Record<string, string>;
export type TomlValue = string | number | boolean | TomlValue[] | {
    [k: string]: TomlValue;
};
/** Small TOML reader good enough for Codex config.toml (tables, dotted / quoted keys, strings, arrays, inline tables). */
export declare function parseToml(text: string): {
    [k: string]: TomlValue;
};
export declare function readCodexConfig(file: string, scope: CodexConfig['scope'], root?: string): CodexConfig;
/** Distinct repo roots (repository, else cwd) of the given sessions, most recent first. */
export declare function rootsOf(sessions: {
    repository?: string;
    cwd?: string;
    lastActivityAt?: number;
}[]): string[];
export declare function collectSettings(input: SettingsInput): SettingsReport;
export interface Effective<T> {
    value?: T;
    layer?: LayerKind;
    file?: string;
    /** Lower layers that also set it (shadowed). */
    shadowed: {
        layer: LayerKind;
        value: T;
    }[];
}
/** Layers that apply to one scope: managed + user, plus project / local of `root` (undefined = user scope only). */
export declare function layersFor(report: SettingsReport, root?: string): ClaudeLayer[];
export declare function effective<K extends 'model' | 'effortLevel' | 'defaultMode' | 'outputStyle' | 'statusLine'>(layers: ClaudeLayer[], key: K): Effective<string>;
/** Permission rules merge across layers (CC: deny wins over ask over allow). */
export declare function mergedRules(layers: ClaudeLayer[]): {
    allow: number;
    deny: number;
    ask: number;
    hooks: number;
};

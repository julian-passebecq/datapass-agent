import { AgentSessionSnapshot } from '../model';
/** Config overrides that stop a repository named by an artifact from running its own programs (fsmonitor hooks,
 *  external diff/textconv drivers, pagers, credential prompts). */
export declare const HARDEN: string[];
/**
 * Absolute path of `name` found on PATH, or undefined. Never looks in the current directory: on Windows a bare
 * `execFile('git', …, { cwd })` would run a `git.exe` planted in that cwd (a session worktree) before PATH.
 * Only absolute PATH entries are scanned (empty, '.' and relative entries are skipped). On Windows only `.exe` / `.com`
 * are tried: `execFile` cannot start a `.cmd` / `.bat` without a shell, which Agent never uses.
 */
export declare function findExe(name: string, pathVar: string | undefined, platform?: NodeJS.Platform): string | undefined;
/** `findExe` on this process's PATH, cached per name. Callers report the tool as unavailable when it returns undefined. */
export declare function resolveExe(name: string): string | undefined;
export declare function clearExeCache(): void;
/** Read-only git invocations. Git is the authority for Git; Agent never writes to a repository. */
export declare const gitStats: {
    calls: number;
    ms: number;
    byCmd: Record<string, number>;
};
export interface GitLocation {
    repository: string;
    worktree: string;
    isLinkedWorktree: boolean;
    branch?: string;
    detachedHead: boolean;
    head?: string;
    dirty?: boolean;
}
export declare function locate(cwd: string, maxAgeMs?: number, withStatus?: boolean): Promise<GitLocation | undefined>;
/** Commit HEAD pointed at, at time t (first-parent reflog-free approximation: last commit reachable from HEAD before t). */
export declare function headAt(cwd: string, t: number): Promise<string | undefined>;
export interface DiffStat {
    files: string[];
    added: number;
    removed: number;
}
export declare function diffStat(cwd: string, from: string, to: string): Promise<DiffStat | undefined>;
/** Fill repository/worktree/branch/HEAD/commit fields with git evidence. Mutates and returns the snapshot. */
export declare function correlate(s: AgentSessionSnapshot, now?: number, windowStart?: number): Promise<AgentSessionSnapshot>;
interface GitDirs {
    gitDir: string;
    commonDir: string;
}
/** The repository's git dir (per worktree) and common dir for `cwd`, found by walking up to `.git` (a dir, or a
 *  `gitdir:` file in a linked worktree). Plain fs reads of a few bytes: no git spawn. */
export declare function gitDirs(cwd: string): GitDirs | undefined;
/**
 * Cheap change signal for the git state seen from `cwd`: mtime/size of HEAD, its reflog, the index, the checked-out
 * branch ref and packed-refs (a commit, checkout, reset, merge, stage or ref update changes one of them). Same string
 * means nothing git-visible moved, so a correlation keyed on it can be reused. When it changes, the cached location
 * (HEAD, branch, dirty) for this cwd is dropped so the next `locate` asks git again.
 */
export declare function gitSignal(cwd: string | undefined): string;
export declare function clearGitCache(): void;
export {};

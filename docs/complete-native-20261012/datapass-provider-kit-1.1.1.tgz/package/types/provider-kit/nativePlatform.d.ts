import type { NativeSelection } from './nativeTransport';
import type { NativeStartupManifest } from './nativeStartup';
export interface NativePlatformVerifier {
    issuerId: string;
    publicKeyPem: string;
    fingerprint: string;
}
export interface NativePlatformProof {
    schema: 'datapass.native-platform-proof/1';
    issuerId: string;
    keyFingerprint: string;
    signature: string;
    payload: {
        hostId: string;
        transport: NativeSelection['transport'];
        cwd: string;
        home: string;
        permission: NativeSelection['permission'];
        executableSha256: string;
        nativeVersion: string;
        startupManifestHash: string;
        environmentHash: string;
        toolPolicyHash: string;
        supportedCapabilities: string[];
        managed: {
            state: 'COMPLETE_NO_STARTUP_EFFECTS';
            sourceHash: string;
            sourceRef: string;
        };
        ambient: {
            state: 'DISABLED_OR_SEALED';
            sourceHash: string;
            sourceRef: string;
        };
        isolation: {
            state: 'ENFORCED';
            descendants: 'ENFORCED';
            boundaryId: string;
            policyHash: string;
        };
        issuedAt: string;
        expiresAt: string;
    };
}
export interface NativePlatformVerification {
    state: 'TRUSTED_VERIFIER_REPORTED' | 'UNKNOWN';
    issuerId: string | null;
    reason: string | null;
}
export declare function validateNativePlatformVerifier(value: NativePlatformVerifier): boolean;
/** Keys come from Agent host authority, never selection JSON. Signatures authenticate the verifier's report. */
export declare function verifyNativePlatformProof(selection: NativeSelection, manifest: NativeStartupManifest, trustedKeys: NativePlatformVerifier[], environmentHash: string, toolPolicyHash: string, now?: number): NativePlatformVerification;

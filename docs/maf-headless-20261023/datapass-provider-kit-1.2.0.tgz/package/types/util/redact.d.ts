export declare const MARK = "[REDACTED]";
/** True when a key name (JSON / env / header) is one whose value Agent never shows. */
export declare function isSecretKeyName(name: string): boolean;
export declare function redact(text: string): string;
/** Single-line, redacted, length-bounded. */
export declare function bounded(text: unknown, max?: number): string;
/** Native message bodies keep formatting; redact the complete unit before the UTF-8 byte bound. */
export declare function boundedMultiline(text: unknown, max?: number): string;
/**
 * Deep copy of a JSON-like value with every string redacted and every secret-named key's string value replaced by
 * MARK. Use before showing or exporting structured provider data.
 */
export declare function redactDeep<T>(value: T, depth?: number): T;
/** The only environment variables Agent ever reads. Never persist a full environment snapshot. */
export declare const ENV_ALLOW_LIST: readonly ["USERPROFILE", "HOME", "CODEX_HOME", "CLAUDE_CONFIG_DIR"];
export declare function safeEnv(env?: NodeJS.ProcessEnv): Partial<Record<(typeof ENV_ALLOW_LIST)[number], string>>;
export declare function isCredentialPath(file: string): boolean;

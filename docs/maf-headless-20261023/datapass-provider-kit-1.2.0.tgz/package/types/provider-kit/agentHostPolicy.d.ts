import type { AHPExecutionPolicy } from './agentHostTypes';
export declare const readOnlyConfig: () => {
    'codex.sandboxMode': string;
    'codex.approvalPolicy': string;
    'codex.networkAccessEnabled': boolean;
    'codex.webSearchMode': string;
    'codex.additionalDirectories': never[];
    permissions: {
        allow: never[];
        deny: never[];
    };
};
export declare class AHPPermissionError extends Error {
    constructor(message: string);
}
export declare function validExecutionPolicy(p: unknown): p is AHPExecutionPolicy;
export declare function restrictiveValues(v: unknown): boolean;
/** Only declared public schema keys and server-resolved values; no private tool filter. */
export declare function validateResolvedPolicy(result: unknown): Record<string, unknown>;
/** Hash only security-related host state, never account metadata or connection secrets. */
export declare function reviewedHostPolicy(root: unknown): Record<string, unknown>;
/** Public AHP 1.0/0.9 publishes configuration, not independent native sandbox/tool enforcement. */
export declare function requireEffectivePermissionEvidence(): never;

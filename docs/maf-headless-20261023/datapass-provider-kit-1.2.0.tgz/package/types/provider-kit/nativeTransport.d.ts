import { NativeStartupManifest } from './nativeStartup';
import { NativePlatformProof, NativePlatformVerifier, NativePlatformVerification } from './nativePlatform';
import { MafRuntime, MafAction } from './nativeMaf';
export declare const nativeTransportVersion: "1.0.3";
export type NativeTransport = 'codex-app-server' | 'codex-cli' | 'claude-cli' | 'maf-harness';
export interface NativeIdentity {
    model: string;
    effort: string | null;
    accountId: string | null;
}
export interface NativeSelection {
    transport: NativeTransport;
    /** Explicit host-registered runtime, currently the offline replay backend only. */
    mafRuntimeHash?: string;
    /** Regular executable, never a shell, script shim, PATH lookup or caller-supplied argv. */
    executable: string;
    executableSha256: string;
    nativeVersion: string;
    cwd: string;
    home: string;
    hostId: string;
    /** Explicit provider-state directory; omitted legacy targets use home directly. Never discover credentials. */
    providerHome?: string;
    permission: 'read-only' | 'workspace-write';
    requestedIdentity: NativeIdentity;
    /** Explicit Config reference to native-name mapping, independently reported by the platform verifier. */
    nativeTools?: {
        configToolRefs: string[];
        toolNames: string[];
    };
    /** Reviewed exact startup effect inventory; local host must independently approve its digest. */
    startup: {
        reviewHash: string;
        configurationHash: string;
        hooks: 'NONE' | 'REVIEWED';
        mcp: 'NONE' | 'REVIEWED';
        managed: 'NONE' | 'REVIEWED';
        isolated: boolean;
        supported: string[];
        manifest?: NativeStartupManifest;
        platformProof?: NativePlatformProof;
    };
}
export interface NativeTaskInput {
    selection: NativeSelection;
    taskId: string;
    text: string;
    mafAction?: MafAction;
    targetHash: string;
    permissionHash: string;
    configHash: string;
    presetHash: string;
    promptHash: string;
    bindingHash: string;
    scopeHash: string;
    configScopeHash: string;
    /** Only an Agent-owned, completed/interrupted session ledger can be resumed. */
    resumeFromTaskId?: string;
}
export interface PreparedNativeTask extends NativeTaskInput {
    schema: 'datapass.native-task/1';
    preparedHash: string;
}
export interface NativePreflight {
    schema: 'datapass.native-preflight/1';
    version: typeof nativeTransportVersion;
    state: 'READY' | 'BLOCKED';
    selectionHash: string;
    reasons: string[];
    verification: {
        installed: 'EXACT_BINARY_VERIFIED' | 'UNKNOWN';
        configured: 'LOCAL_MANIFEST_VERIFIED' | 'UNKNOWN';
        authenticated: 'UNKNOWN';
        working: 'UNKNOWN';
        platform: NativePlatformVerification;
        capabilities: 'TRUSTED_VERIFIER_REPORTED' | 'ASSERTED';
    };
    limitations: string[];
    tools: {
        policy: 'NATIVE_PROVIDER_OWNED_UNPROBED' | 'RESTRICTED_DEFAULT_UNPROBED' | 'MAPPED_REPORTED_UNPROBED' | 'EXACT_MAF_ACTION';
        toolNames: string[] | null;
        working: 'UNKNOWN';
        humanApprovalRoundTrip: 'NATIVE_REFUSAL' | 'UNSUPPORTED_CLI_MANUAL' | 'EXACT_HOST_REVIEW';
    };
    capabilities: {
        start: boolean;
        stream: boolean;
        resume: boolean;
        cancel: 'OWNED_TURN' | 'OWNED_PROCESS';
        securityRequests: 'NATIVE_REFUSAL';
        observedIdentity: 'PROVIDER_EVIDENCE_ONLY';
    };
}
export declare const nativeHash: (value: unknown) => string;
/** Renewing a signed proof alone does not change an owned session's native identity/configuration. */
export declare function nativeSelectionBinding(selection: NativeSelection): string;
export declare const hashOk: (v: unknown) => v is string;
export declare const nativeIdOk: (v: unknown) => v is string;
export declare function nativeToolPolicy(selection: NativeSelection): {
    configToolRefs: string[];
    toolNames: string[];
} | null;
export declare function validateNativeSelection(s: NativeSelection): boolean;
export declare function preflightNativeTransport(selection: NativeSelection, trustedKeys?: NativePlatformVerifier[], mafRuntime?: MafRuntime): Promise<NativePreflight>;
export declare function prepareNativeTask(input: NativeTaskInput): PreparedNativeTask;
/** Fixed native command vocabulary. Prompt is delivered over stdin, never shell text or argv. */
export declare function nativeLaunchArguments(task: PreparedNativeTask, resumeId?: string, mafRuntime?: MafRuntime): string[];
/** Deliberately no inherited PATH, credentials, command hooks, agents or token environment. Native owns auth in reviewed home. */
export declare function nativeEnvironment(selection: NativeSelection): NodeJS.ProcessEnv;

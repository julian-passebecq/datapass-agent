import type { AhpTransport } from '@microsoft/agent-host-protocol/client';
import type { SessionModelInfo } from '@microsoft/agent-host-protocol';
import type { Request } from '../cockpit/interfaces';
import type { AHPBinding, AHPHost, AHPInspection, AHPPrepared, AHPObservation, AHPReply, AgentHostApi, AHPApproval } from './agentHostTypes';
export * from './agentHostTypes';
export declare const ahpHash: (value: unknown) => string;
export declare const ahpTextHash: (value: string) => string;
/** Exact Stable/Insiders native schema key; no permission/config enum guessing. */
export declare function qualifiedAHPEfforts(provider: string, model: SessionModelInfo): string[];
/** Only the extension host can register a connection. No transport/token is accepted in request JSON. */
export interface ReviewedAHPHost {
    host: AHPHost;
    scopeHash: string;
    root: string;
    revision: string;
    authorized(): boolean;
    open(): Promise<AhpTransport>;
}
export interface AHPStorage {
    load(): unknown;
    save(records: AHPLedger[]): Promise<void>;
}
export interface AHPLedger {
    prepared: AHPPrepared;
    observation: AHPObservation;
    request: Request;
    clientId: string;
    phase: 'PREPARED' | 'CREATE_INTENT' | 'SESSION_BOUND' | 'SEND_INTENT' | 'SENT';
    integrityHash: string;
}
export interface AHPServices {
    storage: AHPStorage;
    authorize(request: Request): boolean;
    sourceGrantCurrent?(request: Request): boolean;
    verifySource(binding: AHPBinding, request?: Request): Promise<boolean>;
    reviewProject(request: Request, binding: AHPBinding): Promise<boolean>;
    reviewConnection(request: Request, binding: AHPBinding): Promise<ReviewedAHPHost | null>;
    reviewTask(prepared: AHPPrepared): Promise<boolean>;
}
/** Agent-owned protocol adapter. Native tools, approvals, auth and subagents remain on the host. */
export declare class AgentHostAdapter {
    private services;
    readonly api: AgentHostApi;
    private hosts;
    private connections;
    private prepared;
    private records;
    private sourceGrants;
    private listeners;
    private writes;
    private execution;
    private corrupt;
    constructor(services: AHPServices);
    private reply;
    private authorized;
    private reviewedRoots;
    private reviewedBindings;
    private rootFor;
    reviewProject(r: Request, b: AHPBinding): Promise<AHPReply<{
        authorized: boolean;
    }>>;
    reviewConnection(r: Request, b: AHPBinding): Promise<AHPReply<AHPInspection>>;
    /** Host-owned only; synthetic fixtures use this same entry point with explicit SYNTHETIC identity. */
    registerHost(selection: ReviewedAHPHost): void;
    private empty;
    private connect;
    private inventory;
    private snapshot;
    private pump;
    private monitor;
    inspect(r: Request, provider: 'codex' | 'claude', hostId?: string, b?: AHPBinding): Promise<AHPReply<AHPInspection>>;
    private errorState;
    private resolvePolicy;
    private verifySessionPolicy;
    prepare(r: Request, b: AHPBinding, hostId: string): Promise<AHPReply<AHPPrepared | null>>;
    private persist;
    private transition;
    private emit;
    execute(r: Request, hash: string, a: AHPApproval): Promise<AHPReply<AHPObservation | null>>;
    private initialObservation;
    private sessionMatches;
    private chatMatches;
    private readySession;
    private project;
    observe(r: Request, id: string, recover: boolean): Promise<AHPReply<AHPObservation | null>>;
    private cancel;
    private subscribe;
    revoke(): void;
    dispose(): Promise<void>;
}

import { LocalGrant } from '../cockpit/policy';
import { PreparedNativeTask } from './nativeTransport';
import { NativePlatformVerifier } from './nativePlatform';
import { MafRuntime } from './nativeMaf';
/** Explicit host composition, with no editor discovery, default grants or automatic review. */
export declare function createHeadlessNativeHost(options: {
    ledgerDirectory: string;
    hostId: string;
    grant: LocalGrant;
    review: (task: PreparedNativeTask) => Promise<boolean>;
    trusted: () => boolean;
    platformVerifiers: () => NativePlatformVerifier[];
    mafRuntime?: MafRuntime;
}): Readonly<{
    api: import("./nativeFacade").NativeTransportApi;
    epoch: number;
    revoke: () => void;
    dispose: () => Promise<void>;
}>;

import type { ReviewedAHPHost } from './agentHost';
/** Pure validator used on selected bytes only. Never returns tokens to PM or diagnostics. */
export declare function validateSelectedEndpoint(value: unknown, file: string, userData: string, pidAlive: (pid: number) => boolean): boolean;
/** This function requires an independently confirmed sensitive-access grant BEFORE invocation. */
export declare function selectedEndpointHost(input: {
    file: string;
    userData: string;
    root: string;
    revision: string;
    scopeHash: string;
    authorized: () => boolean;
}): Promise<ReviewedAHPHost>;

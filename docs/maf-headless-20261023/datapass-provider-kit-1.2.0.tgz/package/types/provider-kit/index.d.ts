import { safeLocalSource } from '../cockpit/configuration';
import type { ProviderConfig } from '../cockpit/interfaces';
import { defaultHomes } from '../feeds/settings';
export declare const providerKitVersion: "1.2.0";
export declare const providerKitSchema: "datapass.provider-kit-capture/1";
export { safeLocalSource, defaultHomes };
export type { ProviderConfig, Fact, SessionRef } from '../cockpit/interfaces';
export * from './nativeTransport';
export * from './nativeRunner';
export * from './nativeFacade';
export * from './nativeProjectScope';
export * from './nativeStartup';
export * from './nativePlatform';
export * from './nativeMaf';
export * from './headlessNativeHost';
export * from './agentHost';
export * from './agentHostEndpoint';
export * from './agentHostProject';
export interface CaptureSelection {
    provider: 'codex' | 'claude';
    surface: 'CLI' | 'Desktop' | 'IDE' | 'API';
    nativeVersion: string | null;
    hostId: string;
    accountId: string | null;
    /** Exact reviewed local roots; selection does not grant native action permissions. */
    roots: string[];
    policyHash: string;
    homes: ReturnType<typeof defaultHomes>;
}
export interface ConfigurationCapture {
    schema: typeof providerKitSchema;
    kitVersion: typeof providerKitVersion;
    capturedAt: string;
    sourceHash: string;
    identity: Pick<CaptureSelection, 'provider' | 'surface' | 'nativeVersion' | 'hostId' | 'accountId'>;
    configuration: ProviderConfig;
    sourceRefs: {
        id: string;
        kind: 'LOCAL_FILE';
        observedAt: string;
    }[];
    omissions: string[];
}
/** Same collector used by Agent cockpitV1. No session/history discovery, process spawn, writes or network. */
export declare function captureConfiguration(input: CaptureSelection): Promise<ConfigurationCapture>;

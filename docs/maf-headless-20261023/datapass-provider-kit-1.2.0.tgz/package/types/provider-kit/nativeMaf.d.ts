/** Registered by the Agent host, never accepted as executable paths from a task. */
export interface MafRuntime {
    schema: 'datapass.maf-runtime/1';
    python: string;
    pythonSha256: string;
    worker: string;
    workerSha256: string;
    sitePackages: string;
    files: {
        path: string;
        sha256: string;
    }[];
}
export interface MafAction {
    tool: 'write_artifact';
    filename: string;
    content: string;
}
export declare const mafRuntimeHash: (runtime: MafRuntime) => string;
export declare const mafActionHash: (action: MafAction) => string;
export declare function validateMafAction(action: MafAction): boolean;
/** Verify the host-reviewed import tree, including unexpected added files. No Python execution. */
export declare function verifyMafRuntime(runtime: MafRuntime | undefined, expectedHash: string, python: string, pythonHash: string): Promise<void>;

import type { NativeSelection } from './nativeTransport';
export interface NativeStartupManifest {
    schema: 'datapass.native-startup-manifest/1';
    transport: NativeSelection['transport'];
    cwd: string;
    home: string;
    files: {
        id: string;
        state: 'ABSENT' | 'HASHED' | 'PRESENT_UNREVIEWED' | 'UNKNOWN';
        sha256: string | null;
        bytes: number | null;
    }[];
    directories: {
        id: string;
        state: 'ABSENT' | 'EMPTY' | 'PRESENT_UNREVIEWED' | 'UNKNOWN';
    }[];
    localState: 'VERIFIED_NO_CUSTOMIZATIONS' | 'PARTIAL';
    managedState: 'UNKNOWN';
    isolationState: 'ASSERTED';
    omissions: string[];
    manifestHash: string;
}
/** Fixed startup inventory only. No CLI, auth store, history, arbitrary file path or payload projection. */
export declare function captureNativeStartupManifest(selection: Pick<NativeSelection, 'transport' | 'cwd' | 'home' | 'providerHome' | 'mafRuntimeHash'>): Promise<NativeStartupManifest>;
/** A review digest binds actual local file facts and clearly labelled remaining assertions. */
export declare function nativeStartupReviewHash(selection: NativeSelection, manifest: NativeStartupManifest): string;

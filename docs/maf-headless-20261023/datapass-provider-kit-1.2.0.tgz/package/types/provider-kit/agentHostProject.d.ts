import type { AHPBinding } from './agentHostTypes';
/** Inert exact Git root and HEAD check shared by production AHP reviews and recovery. No remote/auth read. */
export declare function verifyAHPProject(binding: AHPBinding, approvedRepoIds?: string[]): Promise<boolean>;

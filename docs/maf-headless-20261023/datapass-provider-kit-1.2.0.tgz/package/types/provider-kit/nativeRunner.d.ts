import { spawn } from 'node:child_process';
import { NativeIdentity, NativeSelection, PreparedNativeTask } from './nativeTransport';
import type { NativePlatformVerifier } from './nativePlatform';
import { MafRuntime } from './nativeMaf';
export type NativeTaskState = 'SPAWN_INTENT' | 'RUNNING' | 'NEEDS_INPUT' | 'COMPLETED' | 'FAILED' | 'INTERRUPTED' | 'UNCERTAIN';
export interface NativeTaskObservation {
    schema: 'datapass.native-task-observation/1';
    taskId: string;
    preparedHash: string;
    selectionHash: string;
    targetHash: string;
    permissionHash: string;
    configHash: string;
    presetHash: string;
    promptHash: string;
    bindingHash: string;
    scopeHash: string;
    configScopeHash: string;
    state: NativeTaskState;
    sessionId: string | null;
    turnId: string | null;
    sequence: number;
    requestedIdentity: NativeIdentity;
    observedIdentity: {
        model: string | null;
        effort: string | null;
        accountId: string | null;
    };
    resultText: string;
    resultHash: string | null;
    reason: string | null;
    updatedAt: string;
    /** Native completion is not independent acceptance or Git/CI verification. */
    evidence: 'NATIVE_REPORTED' | 'NO_COMPLETION_EVIDENCE';
    quiescence: 'NATIVE_TURN_SETTLED' | 'UNKNOWN';
    maf?: {
        mode: 'offline-replay';
        actionHash: string;
        artifact: {
            filename: string;
            sha256: string;
            bytes: number;
        };
        sessionSha256: string;
    };
}
export interface NativeTaskEvent {
    type: 'STATE' | 'PROGRESS' | 'MESSAGE';
    observation: NativeTaskObservation;
}
export interface NativeTaskHandle {
    taskId: string;
    observation(): NativeTaskObservation;
    result: Promise<NativeTaskObservation>;
    subscribe(listener: (event: NativeTaskEvent) => void): {
        dispose(): void;
    };
    cancel(): Promise<NativeTaskObservation>;
}
/** The standalone kit is a transport, never a scheduler/cognitive loop. The installed facade supplies authority. */
export declare class NativeTaskRunner {
    readonly ledgerDirectory: string;
    private spawnProcess;
    private platformVerifiers;
    private mafRuntime?;
    private live;
    constructor(ledgerDirectory: string, spawnProcess?: typeof spawn, platformVerifiers?: () => NativePlatformVerifier[], mafRuntime?: MafRuntime | undefined);
    preflight(selection: NativeSelection): Promise<import("./nativeTransport").NativePreflight>;
    private file;
    lookup(id: string): Promise<NativeTaskObservation | null>;
    cancel(id: string): Promise<NativeTaskObservation>;
    dispose(): Promise<void>;
    start(input: PreparedNativeTask, reviewedHash: string, stillAuthorized?: () => boolean): Promise<NativeTaskHandle>;
}

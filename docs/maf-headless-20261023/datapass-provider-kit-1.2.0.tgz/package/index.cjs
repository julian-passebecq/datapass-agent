"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name2 in all)
    __defProp(target, name2, { get: all[name2], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/@microsoft/agent-host-protocol/dist/types/common/state.js
var init_state = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/state.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/state.js
var PolicyState;
var init_state2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/state.js"() {
    (function(PolicyState2) {
      PolicyState2["Enabled"] = "enabled";
      PolicyState2["Disabled"] = "disabled";
      PolicyState2["Unconfigured"] = "unconfigured";
    })(PolicyState || (PolicyState = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/state.js
var SessionLifecycle, SessionStatus, SessionOriginKind, SessionInputRequestKind, CustomizationType, CustomizationEnablementKind, CustomizationLoadStatus, McpServerStatus, McpAuthRequiredReason;
var init_state3 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/state.js"() {
    (function(SessionLifecycle2) {
      SessionLifecycle2["Creating"] = "creating";
      SessionLifecycle2["Ready"] = "ready";
      SessionLifecycle2["Failed"] = "failed";
    })(SessionLifecycle || (SessionLifecycle = {}));
    (function(SessionStatus2) {
      SessionStatus2[SessionStatus2["Idle"] = 1] = "Idle";
      SessionStatus2[SessionStatus2["Error"] = 2] = "Error";
      SessionStatus2[SessionStatus2["InProgress"] = 8] = "InProgress";
      SessionStatus2[SessionStatus2["InputNeeded"] = 24] = "InputNeeded";
      SessionStatus2[SessionStatus2["IsRead"] = 32] = "IsRead";
      SessionStatus2[SessionStatus2["IsArchived"] = 64] = "IsArchived";
    })(SessionStatus || (SessionStatus = {}));
    (function(SessionOriginKind2) {
      SessionOriginKind2["Automation"] = "automation";
    })(SessionOriginKind || (SessionOriginKind = {}));
    (function(SessionInputRequestKind2) {
      SessionInputRequestKind2["ChatInput"] = "chatInput";
      SessionInputRequestKind2["ToolConfirmation"] = "toolConfirmation";
      SessionInputRequestKind2["ToolClientExecution"] = "toolClientExecution";
      SessionInputRequestKind2["ToolAuthentication"] = "toolAuthentication";
    })(SessionInputRequestKind || (SessionInputRequestKind = {}));
    (function(CustomizationType2) {
      CustomizationType2["Plugin"] = "plugin";
      CustomizationType2["Directory"] = "directory";
      CustomizationType2["Agent"] = "agent";
      CustomizationType2["Skill"] = "skill";
      CustomizationType2["Prompt"] = "prompt";
      CustomizationType2["Rule"] = "rule";
      CustomizationType2["Hook"] = "hook";
      CustomizationType2["McpServer"] = "mcpServer";
    })(CustomizationType || (CustomizationType = {}));
    (function(CustomizationEnablementKind2) {
      CustomizationEnablementKind2["Global"] = "global";
      CustomizationEnablementKind2["Workspace"] = "workspace";
      CustomizationEnablementKind2["Session"] = "session";
    })(CustomizationEnablementKind || (CustomizationEnablementKind = {}));
    (function(CustomizationLoadStatus2) {
      CustomizationLoadStatus2["Loading"] = "loading";
      CustomizationLoadStatus2["Loaded"] = "loaded";
      CustomizationLoadStatus2["Degraded"] = "degraded";
      CustomizationLoadStatus2["Error"] = "error";
    })(CustomizationLoadStatus || (CustomizationLoadStatus = {}));
    (function(McpServerStatus2) {
      McpServerStatus2["Starting"] = "starting";
      McpServerStatus2["Ready"] = "ready";
      McpServerStatus2["AuthRequired"] = "authRequired";
      McpServerStatus2["Error"] = "error";
      McpServerStatus2["Stopped"] = "stopped";
    })(McpServerStatus || (McpServerStatus = {}));
    (function(McpAuthRequiredReason2) {
      McpAuthRequiredReason2["Required"] = "required";
      McpAuthRequiredReason2["Expired"] = "expired";
      McpAuthRequiredReason2["InsufficientScope"] = "insufficientScope";
    })(McpAuthRequiredReason || (McpAuthRequiredReason = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/state.js
var BackgroundWorkKind, ChatOriginKind, ChatInteractivity, PendingMessageKind, ChatInputResponseKind, ChatInputQuestionKind, ChatInputAnswerValueKind, ChatInputAnswerState, TurnState, MessageAttachmentKind, MessageKind, ResponsePartKind, ToolCallStatus, ToolCallConfirmationReason, ToolCallRiskAssessmentKind, ToolCallRiskAssessmentStatus, ToolCallCancellationReason, ConfirmationOptionKind, ToolCallContributorKind, ToolResultContentType;
var init_state4 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/state.js"() {
    (function(BackgroundWorkKind2) {
      BackgroundWorkKind2["Shell"] = "shell";
      BackgroundWorkKind2["Subagent"] = "subagent";
    })(BackgroundWorkKind || (BackgroundWorkKind = {}));
    (function(ChatOriginKind2) {
      ChatOriginKind2["User"] = "user";
      ChatOriginKind2["Fork"] = "fork";
      ChatOriginKind2["SideChat"] = "sideChat";
      ChatOriginKind2["Tool"] = "tool";
    })(ChatOriginKind || (ChatOriginKind = {}));
    (function(ChatInteractivity2) {
      ChatInteractivity2["Full"] = "full";
      ChatInteractivity2["ReadOnly"] = "read-only";
      ChatInteractivity2["Hidden"] = "hidden";
    })(ChatInteractivity || (ChatInteractivity = {}));
    (function(PendingMessageKind2) {
      PendingMessageKind2["Steering"] = "steering";
      PendingMessageKind2["Queued"] = "queued";
    })(PendingMessageKind || (PendingMessageKind = {}));
    (function(ChatInputResponseKind2) {
      ChatInputResponseKind2["Accept"] = "accept";
      ChatInputResponseKind2["Decline"] = "decline";
      ChatInputResponseKind2["Cancel"] = "cancel";
    })(ChatInputResponseKind || (ChatInputResponseKind = {}));
    (function(ChatInputQuestionKind2) {
      ChatInputQuestionKind2["Text"] = "text";
      ChatInputQuestionKind2["Number"] = "number";
      ChatInputQuestionKind2["Integer"] = "integer";
      ChatInputQuestionKind2["Boolean"] = "boolean";
      ChatInputQuestionKind2["SingleSelect"] = "single-select";
      ChatInputQuestionKind2["MultiSelect"] = "multi-select";
    })(ChatInputQuestionKind || (ChatInputQuestionKind = {}));
    (function(ChatInputAnswerValueKind2) {
      ChatInputAnswerValueKind2["Text"] = "text";
      ChatInputAnswerValueKind2["Number"] = "number";
      ChatInputAnswerValueKind2["Boolean"] = "boolean";
      ChatInputAnswerValueKind2["Selected"] = "selected";
      ChatInputAnswerValueKind2["SelectedMany"] = "selected-many";
    })(ChatInputAnswerValueKind || (ChatInputAnswerValueKind = {}));
    (function(ChatInputAnswerState2) {
      ChatInputAnswerState2["Draft"] = "draft";
      ChatInputAnswerState2["Submitted"] = "submitted";
      ChatInputAnswerState2["Skipped"] = "skipped";
    })(ChatInputAnswerState || (ChatInputAnswerState = {}));
    (function(TurnState2) {
      TurnState2["Complete"] = "complete";
      TurnState2["Cancelled"] = "cancelled";
      TurnState2["Error"] = "error";
    })(TurnState || (TurnState = {}));
    (function(MessageAttachmentKind2) {
      MessageAttachmentKind2["Simple"] = "simple";
      MessageAttachmentKind2["EmbeddedResource"] = "embeddedResource";
      MessageAttachmentKind2["Resource"] = "resource";
      MessageAttachmentKind2["Annotations"] = "annotations";
      MessageAttachmentKind2["Chat"] = "chat";
    })(MessageAttachmentKind || (MessageAttachmentKind = {}));
    (function(MessageKind2) {
      MessageKind2["User"] = "user";
      MessageKind2["Agent"] = "agent";
      MessageKind2["Tool"] = "tool";
      MessageKind2["Automation"] = "automation";
      MessageKind2["SystemNotification"] = "systemNotification";
    })(MessageKind || (MessageKind = {}));
    (function(ResponsePartKind2) {
      ResponsePartKind2["Markdown"] = "markdown";
      ResponsePartKind2["ContentRef"] = "contentRef";
      ResponsePartKind2["ToolCall"] = "toolCall";
      ResponsePartKind2["Reasoning"] = "reasoning";
      ResponsePartKind2["SystemNotification"] = "systemNotification";
      ResponsePartKind2["InputRequest"] = "inputRequest";
      ResponsePartKind2["Error"] = "error";
    })(ResponsePartKind || (ResponsePartKind = {}));
    (function(ToolCallStatus2) {
      ToolCallStatus2["Streaming"] = "streaming";
      ToolCallStatus2["PendingConfirmation"] = "pending-confirmation";
      ToolCallStatus2["Running"] = "running";
      ToolCallStatus2["AuthRequired"] = "auth-required";
      ToolCallStatus2["PendingResultConfirmation"] = "pending-result-confirmation";
      ToolCallStatus2["Completed"] = "completed";
      ToolCallStatus2["Cancelled"] = "cancelled";
    })(ToolCallStatus || (ToolCallStatus = {}));
    (function(ToolCallConfirmationReason2) {
      ToolCallConfirmationReason2["NotNeeded"] = "not-needed";
      ToolCallConfirmationReason2["UserAction"] = "user-action";
      ToolCallConfirmationReason2["Setting"] = "setting";
    })(ToolCallConfirmationReason || (ToolCallConfirmationReason = {}));
    (function(ToolCallRiskAssessmentKind2) {
      ToolCallRiskAssessmentKind2["Judge"] = "judge";
    })(ToolCallRiskAssessmentKind || (ToolCallRiskAssessmentKind = {}));
    (function(ToolCallRiskAssessmentStatus2) {
      ToolCallRiskAssessmentStatus2["Loading"] = "loading";
      ToolCallRiskAssessmentStatus2["Complete"] = "complete";
    })(ToolCallRiskAssessmentStatus || (ToolCallRiskAssessmentStatus = {}));
    (function(ToolCallCancellationReason2) {
      ToolCallCancellationReason2["Denied"] = "denied";
      ToolCallCancellationReason2["Skipped"] = "skipped";
      ToolCallCancellationReason2["ResultDenied"] = "result-denied";
    })(ToolCallCancellationReason || (ToolCallCancellationReason = {}));
    (function(ConfirmationOptionKind2) {
      ConfirmationOptionKind2["Approve"] = "approve";
      ConfirmationOptionKind2["Deny"] = "deny";
    })(ConfirmationOptionKind || (ConfirmationOptionKind = {}));
    (function(ToolCallContributorKind2) {
      ToolCallContributorKind2["Client"] = "client";
      ToolCallContributorKind2["MCP"] = "mcp";
    })(ToolCallContributorKind || (ToolCallContributorKind = {}));
    (function(ToolResultContentType2) {
      ToolResultContentType2["Text"] = "text";
      ToolResultContentType2["EmbeddedResource"] = "embeddedResource";
      ToolResultContentType2["Resource"] = "resource";
      ToolResultContentType2["FileEdit"] = "fileEdit";
      ToolResultContentType2["Terminal"] = "terminal";
      ToolResultContentType2["Subagent"] = "subagent";
    })(ToolResultContentType || (ToolResultContentType = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-canvas/state.js
var init_state5 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-canvas/state.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/state.js
var TerminalLifecycleStatus, TerminalClaimKind;
var init_state6 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/state.js"() {
    (function(TerminalLifecycleStatus2) {
      TerminalLifecycleStatus2["Running"] = "running";
      TerminalLifecycleStatus2["Exited"] = "exited";
    })(TerminalLifecycleStatus || (TerminalLifecycleStatus = {}));
    (function(TerminalClaimKind2) {
      TerminalClaimKind2["Client"] = "client";
      TerminalClaimKind2["Session"] = "session";
    })(TerminalClaimKind || (TerminalClaimKind = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/state.js
var ChangesetStatus, ChangesetOperationStatus, ChangesetOperationScope;
var init_state7 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/state.js"() {
    (function(ChangesetStatus2) {
      ChangesetStatus2["Computing"] = "computing";
      ChangesetStatus2["Recomputing"] = "recomputing";
      ChangesetStatus2["Ready"] = "ready";
      ChangesetStatus2["Error"] = "error";
    })(ChangesetStatus || (ChangesetStatus = {}));
    (function(ChangesetOperationStatus2) {
      ChangesetOperationStatus2["Idle"] = "idle";
      ChangesetOperationStatus2["Running"] = "running";
      ChangesetOperationStatus2["Error"] = "error";
      ChangesetOperationStatus2["Disabled"] = "disabled";
    })(ChangesetOperationStatus || (ChangesetOperationStatus = {}));
    (function(ChangesetOperationScope2) {
      ChangesetOperationScope2["Changeset"] = "changeset";
      ChangesetOperationScope2["Resource"] = "resource";
      ChangesetOperationScope2["Range"] = "range";
    })(ChangesetOperationScope || (ChangesetOperationScope = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-annotations/state.js
var init_state8 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-annotations/state.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-otlp/state.js
var init_state9 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-otlp/state.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/state.js
var ResourceChangeType;
var init_state10 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/state.js"() {
    (function(ResourceChangeType2) {
      ResourceChangeType2["Added"] = "added";
      ResourceChangeType2["Updated"] = "updated";
      ResourceChangeType2["Deleted"] = "deleted";
    })(ResourceChangeType || (ResourceChangeType = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/state.js
var AutomationOperation, AutomationMisfirePolicy, AutomationTriggerKind, AutomationDisableConditionKind;
var init_state11 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/state.js"() {
    (function(AutomationOperation2) {
      AutomationOperation2["Update"] = "update";
      AutomationOperation2["Remove"] = "remove";
      AutomationOperation2["Run"] = "run";
    })(AutomationOperation || (AutomationOperation = {}));
    (function(AutomationMisfirePolicy2) {
      AutomationMisfirePolicy2["Skip"] = "skip";
      AutomationMisfirePolicy2["RunOnce"] = "runOnce";
    })(AutomationMisfirePolicy || (AutomationMisfirePolicy = {}));
    (function(AutomationTriggerKind2) {
      AutomationTriggerKind2["Schedule"] = "schedule";
      AutomationTriggerKind2["Event"] = "event";
    })(AutomationTriggerKind || (AutomationTriggerKind = {}));
    (function(AutomationDisableConditionKind2) {
      AutomationDisableConditionKind2["AfterRuns"] = "afterRuns";
      AutomationDisableConditionKind2["AfterDate"] = "afterDate";
    })(AutomationDisableConditionKind || (AutomationDisableConditionKind = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation-run/state.js
var AutomationRunStatus, AutomationRunOriginKind;
var init_state12 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation-run/state.js"() {
    (function(AutomationRunStatus2) {
      AutomationRunStatus2["Pending"] = "pending";
      AutomationRunStatus2["Running"] = "running";
      AutomationRunStatus2["Completed"] = "completed";
      AutomationRunStatus2["Failed"] = "failed";
      AutomationRunStatus2["Cancelled"] = "cancelled";
    })(AutomationRunStatus || (AutomationRunStatus = {}));
    (function(AutomationRunOriginKind2) {
      AutomationRunOriginKind2["Manual"] = "manual";
      AutomationRunOriginKind2["Trigger"] = "trigger";
    })(AutomationRunOriginKind || (AutomationRunOriginKind = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/state.js
var init_state13 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/state.js"() {
    init_state();
    init_state2();
    init_state3();
    init_state4();
    init_state5();
    init_state6();
    init_state7();
    init_state8();
    init_state9();
    init_state10();
    init_state11();
    init_state12();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/actions.js
var ActionType;
var init_actions = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/actions.js"() {
    (function(ActionType2) {
      ActionType2["RootAgentsChanged"] = "root/agentsChanged";
      ActionType2["RootActiveSessionsChanged"] = "root/activeSessionsChanged";
      ActionType2["SessionReady"] = "session/ready";
      ActionType2["SessionCreationFailed"] = "session/creationFailed";
      ActionType2["SessionChatAdded"] = "session/chatAdded";
      ActionType2["SessionChatRemoved"] = "session/chatRemoved";
      ActionType2["SessionChatUpdated"] = "session/chatUpdated";
      ActionType2["SessionChatsReordered"] = "session/chatsReordered";
      ActionType2["SessionDefaultChatChanged"] = "session/defaultChatChanged";
      ActionType2["ChatTurnStarted"] = "chat/turnStarted";
      ActionType2["ChatDelta"] = "chat/delta";
      ActionType2["ChatResponsePart"] = "chat/responsePart";
      ActionType2["ChatToolCallStart"] = "chat/toolCallStart";
      ActionType2["ChatToolCallDelta"] = "chat/toolCallDelta";
      ActionType2["ChatToolCallReady"] = "chat/toolCallReady";
      ActionType2["ChatToolCallConfirmed"] = "chat/toolCallConfirmed";
      ActionType2["ChatToolCallComplete"] = "chat/toolCallComplete";
      ActionType2["ChatToolCallResultConfirmed"] = "chat/toolCallResultConfirmed";
      ActionType2["ChatToolCallContentChanged"] = "chat/toolCallContentChanged";
      ActionType2["ChatToolCallAuthRequired"] = "chat/toolCallAuthRequired";
      ActionType2["ChatToolCallAuthResolved"] = "chat/toolCallAuthResolved";
      ActionType2["ChatTurnComplete"] = "chat/turnComplete";
      ActionType2["ChatTurnCancelled"] = "chat/turnCancelled";
      ActionType2["ChatError"] = "chat/error";
      ActionType2["ChatTurnResume"] = "chat/turnResume";
      ActionType2["ChatActivityChanged"] = "chat/activityChanged";
      ActionType2["ChatBackgroundWorkSet"] = "chat/backgroundWorkSet";
      ActionType2["ChatBackgroundWorkRemoved"] = "chat/backgroundWorkRemoved";
      ActionType2["ChatMovableChanged"] = "chat/movableChanged";
      ActionType2["ChatChangesetsChanged"] = "chat/changesetsChanged";
      ActionType2["ChatCanvasesChanged"] = "chat/canvasesChanged";
      ActionType2["CanvasStateChanged"] = "canvas/stateChanged";
      ActionType2["ChatWorkingDirectorySet"] = "chat/workingDirectorySet";
      ActionType2["ChatWorkingDirectoryRemoved"] = "chat/workingDirectoryRemoved";
      ActionType2["SessionTitleChanged"] = "session/titleChanged";
      ActionType2["ChatUsage"] = "chat/usage";
      ActionType2["ChatReasoning"] = "chat/reasoning";
      ActionType2["SessionServerToolsChanged"] = "session/serverToolsChanged";
      ActionType2["SessionActiveClientSet"] = "session/activeClientSet";
      ActionType2["SessionActiveClientRemoved"] = "session/activeClientRemoved";
      ActionType2["SessionWorkingDirectorySet"] = "session/workingDirectorySet";
      ActionType2["SessionWorkingDirectoryRemoved"] = "session/workingDirectoryRemoved";
      ActionType2["SessionWorkingDirectoryReplaced"] = "session/workingDirectoryReplaced";
      ActionType2["SessionInputNeededSet"] = "session/inputNeededSet";
      ActionType2["SessionInputNeededRemoved"] = "session/inputNeededRemoved";
      ActionType2["ChatPendingMessageSet"] = "chat/pendingMessageSet";
      ActionType2["ChatPendingMessageRemoved"] = "chat/pendingMessageRemoved";
      ActionType2["ChatQueuedMessagesReordered"] = "chat/queuedMessagesReordered";
      ActionType2["ChatDraftChanged"] = "chat/draftChanged";
      ActionType2["ChatIsReadChanged"] = "chat/isReadChanged";
      ActionType2["ChatIsArchivedChanged"] = "chat/isArchivedChanged";
      ActionType2["ChatInputRequested"] = "chat/inputRequested";
      ActionType2["ChatInputAnswerChanged"] = "chat/inputAnswerChanged";
      ActionType2["ChatInputCompleted"] = "chat/inputCompleted";
      ActionType2["SessionCustomizationsChanged"] = "session/customizationsChanged";
      ActionType2["SessionCustomizationToggled"] = "session/customizationToggled";
      ActionType2["SessionCustomizationUpdated"] = "session/customizationUpdated";
      ActionType2["SessionCustomizationRemoved"] = "session/customizationRemoved";
      ActionType2["SessionMcpServerStateChanged"] = "session/mcpServerStateChanged";
      ActionType2["SessionMcpServerStartRequested"] = "session/mcpServerStartRequested";
      ActionType2["SessionMcpServerStopRequested"] = "session/mcpServerStopRequested";
      ActionType2["SessionMcpServerBackgroundRequested"] = "session/mcpServerBackgroundRequested";
      ActionType2["ChatTruncated"] = "chat/truncated";
      ActionType2["ChatTurnsLoaded"] = "chat/turnsLoaded";
      ActionType2["SessionIsReadChanged"] = "session/isReadChanged";
      ActionType2["SessionIsArchivedChanged"] = "session/isArchivedChanged";
      ActionType2["SessionActivityChanged"] = "session/activityChanged";
      ActionType2["SessionChangesetsChanged"] = "session/changesetsChanged";
      ActionType2["SessionConfigChanged"] = "session/configChanged";
      ActionType2["SessionMetaChanged"] = "session/metaChanged";
      ActionType2["ChangesetStatusChanged"] = "changeset/statusChanged";
      ActionType2["ChangesetFileSet"] = "changeset/fileSet";
      ActionType2["ChangesetFileRemoved"] = "changeset/fileRemoved";
      ActionType2["ChangesetFilesReviewChanged"] = "changeset/filesReviewChanged";
      ActionType2["ChangesetContentChanged"] = "changeset/contentChanged";
      ActionType2["ChangesetOperationsChanged"] = "changeset/operationsChanged";
      ActionType2["ChangesetOperationStatusChanged"] = "changeset/operationStatusChanged";
      ActionType2["ChangesetCleared"] = "changeset/cleared";
      ActionType2["AnnotationsSet"] = "annotations/set";
      ActionType2["AnnotationsUpdated"] = "annotations/updated";
      ActionType2["AnnotationsRemoved"] = "annotations/removed";
      ActionType2["AnnotationsEntrySet"] = "annotations/entrySet";
      ActionType2["AnnotationsEntryRemoved"] = "annotations/entryRemoved";
      ActionType2["RootTerminalsChanged"] = "root/terminalsChanged";
      ActionType2["RootConfigChanged"] = "root/configChanged";
      ActionType2["TerminalData"] = "terminal/data";
      ActionType2["TerminalInput"] = "terminal/input";
      ActionType2["TerminalResized"] = "terminal/resized";
      ActionType2["TerminalClaimed"] = "terminal/claimed";
      ActionType2["TerminalTitleChanged"] = "terminal/titleChanged";
      ActionType2["TerminalCwdChanged"] = "terminal/cwdChanged";
      ActionType2["TerminalExited"] = "terminal/exited";
      ActionType2["TerminalCleared"] = "terminal/cleared";
      ActionType2["TerminalCommandDetectionAvailable"] = "terminal/commandDetectionAvailable";
      ActionType2["TerminalCommandExecuted"] = "terminal/commandExecuted";
      ActionType2["TerminalCommandFinished"] = "terminal/commandFinished";
      ActionType2["ResourceWatchChanged"] = "resourceWatch/changed";
      ActionType2["AutomationCreateRequested"] = "automation/createRequested";
      ActionType2["AutomationUpdateRequested"] = "automation/updateRequested";
      ActionType2["AutomationSet"] = "automation/set";
      ActionType2["AutomationRemoved"] = "automation/removed";
      ActionType2["AutomationRunLifecycleChanged"] = "automationRun/lifecycleChanged";
      ActionType2["AutomationRunSessionSet"] = "automationRun/sessionSet";
      ActionType2["AutomationRunSessionRemoved"] = "automationRun/sessionRemoved";
      ActionType2["AutomationRunPrimarySessionChanged"] = "automationRun/primarySessionChanged";
      ActionType2["AutomationRunCancelRequested"] = "automationRun/cancelRequested";
    })(ActionType || (ActionType = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/actions.js
var init_actions2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/actions.js
var init_actions3 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/actions.js
var init_actions4 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-canvas/actions.js
var init_actions5 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-canvas/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/actions.js
var init_actions6 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/actions.js
var init_actions7 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-annotations/actions.js
var init_actions8 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-annotations/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/actions.js
var init_actions9 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/actions.js
var init_actions10 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation-run/actions.js
var init_actions11 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation-run/actions.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/actions.js
var init_actions12 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/actions.js"() {
    init_actions();
    init_actions2();
    init_actions3();
    init_actions4();
    init_actions5();
    init_actions6();
    init_actions7();
    init_actions8();
    init_actions9();
    init_actions10();
    init_actions11();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/action-origin.generated.js
var IS_CLIENT_DISPATCHABLE;
var init_action_origin_generated = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/action-origin.generated.js"() {
    init_actions12();
    IS_CLIENT_DISPATCHABLE = {
      [ActionType.RootAgentsChanged]: false,
      [ActionType.RootActiveSessionsChanged]: false,
      [ActionType.RootTerminalsChanged]: false,
      [ActionType.RootConfigChanged]: true,
      [ActionType.SessionReady]: false,
      [ActionType.SessionCreationFailed]: false,
      [ActionType.SessionChatAdded]: false,
      [ActionType.SessionChatRemoved]: false,
      [ActionType.SessionChatUpdated]: false,
      [ActionType.SessionChatsReordered]: false,
      [ActionType.SessionDefaultChatChanged]: false,
      [ActionType.SessionTitleChanged]: true,
      [ActionType.SessionServerToolsChanged]: false,
      [ActionType.SessionActiveClientSet]: true,
      [ActionType.SessionActiveClientRemoved]: true,
      [ActionType.SessionWorkingDirectorySet]: true,
      [ActionType.SessionWorkingDirectoryRemoved]: true,
      [ActionType.SessionWorkingDirectoryReplaced]: true,
      [ActionType.SessionInputNeededSet]: false,
      [ActionType.SessionInputNeededRemoved]: false,
      [ActionType.SessionCustomizationsChanged]: false,
      [ActionType.SessionCustomizationToggled]: true,
      [ActionType.SessionCustomizationUpdated]: false,
      [ActionType.SessionCustomizationRemoved]: false,
      [ActionType.SessionMcpServerStateChanged]: false,
      [ActionType.SessionMcpServerStartRequested]: true,
      [ActionType.SessionMcpServerStopRequested]: true,
      [ActionType.SessionMcpServerBackgroundRequested]: true,
      [ActionType.SessionIsReadChanged]: true,
      [ActionType.SessionIsArchivedChanged]: true,
      [ActionType.SessionActivityChanged]: false,
      [ActionType.SessionChangesetsChanged]: false,
      [ActionType.SessionConfigChanged]: true,
      [ActionType.SessionMetaChanged]: false,
      [ActionType.ChatTurnStarted]: true,
      [ActionType.ChatDelta]: false,
      [ActionType.ChatResponsePart]: false,
      [ActionType.ChatToolCallStart]: false,
      [ActionType.ChatToolCallDelta]: false,
      [ActionType.ChatToolCallReady]: false,
      [ActionType.ChatToolCallConfirmed]: true,
      [ActionType.ChatToolCallComplete]: true,
      [ActionType.ChatToolCallResultConfirmed]: true,
      [ActionType.ChatToolCallContentChanged]: true,
      [ActionType.ChatToolCallAuthRequired]: false,
      [ActionType.ChatToolCallAuthResolved]: false,
      [ActionType.ChatTurnComplete]: false,
      [ActionType.ChatTurnCancelled]: true,
      [ActionType.ChatError]: false,
      [ActionType.ChatTurnResume]: true,
      [ActionType.ChatActivityChanged]: false,
      [ActionType.ChatBackgroundWorkSet]: false,
      [ActionType.ChatBackgroundWorkRemoved]: false,
      [ActionType.ChatMovableChanged]: false,
      [ActionType.ChatChangesetsChanged]: false,
      [ActionType.ChatCanvasesChanged]: false,
      [ActionType.CanvasStateChanged]: false,
      [ActionType.ChatWorkingDirectorySet]: true,
      [ActionType.ChatWorkingDirectoryRemoved]: true,
      [ActionType.ChatUsage]: false,
      [ActionType.ChatReasoning]: false,
      [ActionType.ChatPendingMessageSet]: true,
      [ActionType.ChatPendingMessageRemoved]: true,
      [ActionType.ChatQueuedMessagesReordered]: true,
      [ActionType.ChatDraftChanged]: true,
      [ActionType.ChatIsReadChanged]: true,
      [ActionType.ChatIsArchivedChanged]: true,
      [ActionType.ChatInputRequested]: false,
      [ActionType.ChatInputAnswerChanged]: true,
      [ActionType.ChatInputCompleted]: true,
      [ActionType.ChatTruncated]: true,
      [ActionType.ChatTurnsLoaded]: false,
      [ActionType.ChangesetStatusChanged]: false,
      [ActionType.ChangesetFileSet]: false,
      [ActionType.ChangesetFileRemoved]: false,
      [ActionType.ChangesetFilesReviewChanged]: true,
      [ActionType.ChangesetContentChanged]: false,
      [ActionType.ChangesetOperationsChanged]: false,
      [ActionType.ChangesetOperationStatusChanged]: false,
      [ActionType.ChangesetCleared]: false,
      [ActionType.AnnotationsSet]: true,
      [ActionType.AnnotationsUpdated]: true,
      [ActionType.AnnotationsRemoved]: true,
      [ActionType.AnnotationsEntrySet]: true,
      [ActionType.AnnotationsEntryRemoved]: true,
      [ActionType.TerminalData]: false,
      [ActionType.TerminalInput]: true,
      [ActionType.TerminalResized]: true,
      [ActionType.TerminalClaimed]: true,
      [ActionType.TerminalTitleChanged]: true,
      [ActionType.TerminalCwdChanged]: false,
      [ActionType.TerminalExited]: false,
      [ActionType.TerminalCleared]: true,
      [ActionType.TerminalCommandDetectionAvailable]: false,
      [ActionType.TerminalCommandExecuted]: false,
      [ActionType.TerminalCommandFinished]: false,
      [ActionType.ResourceWatchChanged]: false,
      [ActionType.AutomationCreateRequested]: true,
      [ActionType.AutomationUpdateRequested]: true,
      [ActionType.AutomationSet]: false,
      [ActionType.AutomationRemoved]: true,
      [ActionType.AutomationRunLifecycleChanged]: false,
      [ActionType.AutomationRunSessionSet]: false,
      [ActionType.AutomationRunSessionRemoved]: false,
      [ActionType.AutomationRunPrimarySessionChanged]: false,
      [ActionType.AutomationRunCancelRequested]: true
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/commands.js
var ReconnectResultType, ContentEncoding, ResourceWriteMode, ResourceType;
var init_commands = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/commands.js"() {
    (function(ReconnectResultType2) {
      ReconnectResultType2["Replay"] = "replay";
      ReconnectResultType2["Snapshot"] = "snapshot";
    })(ReconnectResultType || (ReconnectResultType = {}));
    (function(ContentEncoding2) {
      ContentEncoding2["Base64"] = "base64";
      ContentEncoding2["Utf8"] = "utf-8";
    })(ContentEncoding || (ContentEncoding = {}));
    (function(ResourceWriteMode2) {
      ResourceWriteMode2["Truncate"] = "truncate";
      ResourceWriteMode2["Append"] = "append";
      ResourceWriteMode2["Insert"] = "insert";
    })(ResourceWriteMode || (ResourceWriteMode = {}));
    (function(ResourceType2) {
      ResourceType2["File"] = "file";
      ResourceType2["Directory"] = "directory";
      ResourceType2["Symlink"] = "symlink";
    })(ResourceType || (ResourceType = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/commands.js
var init_commands2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/commands.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/commands.js
var CompletionItemKind;
var init_commands3 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/commands.js"() {
    (function(CompletionItemKind2) {
      CompletionItemKind2["UserMessage"] = "userMessage";
    })(CompletionItemKind || (CompletionItemKind = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/commands.js
var ChatSourceKind, ChatMoveDestinationKind;
var init_commands4 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/commands.js"() {
    (function(ChatSourceKind2) {
      ChatSourceKind2["Fork"] = "fork";
      ChatSourceKind2["SideChat"] = "sideChat";
    })(ChatSourceKind || (ChatSourceKind = {}));
    (function(ChatMoveDestinationKind2) {
      ChatMoveDestinationKind2["Session"] = "session";
      ChatMoveDestinationKind2["NewSession"] = "newSession";
    })(ChatMoveDestinationKind || (ChatMoveDestinationKind = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/commands.js
var init_commands5 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/commands.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/commands.js
var ChangesetOperationTargetKind;
var init_commands6 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/commands.js"() {
    (function(ChangesetOperationTargetKind2) {
      ChangesetOperationTargetKind2["Resource"] = "resource";
      ChangesetOperationTargetKind2["Range"] = "range";
    })(ChangesetOperationTargetKind || (ChangesetOperationTargetKind = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/commands.js
var init_commands7 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/commands.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/commands.js
var init_commands8 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/commands.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/commands.js
var init_commands9 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/commands.js"() {
    init_commands();
    init_commands2();
    init_commands3();
    init_commands4();
    init_commands5();
    init_commands6();
    init_commands7();
    init_commands8();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/notifications.js
var AuthRequiredReason;
var init_notifications = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/notifications.js"() {
    (function(AuthRequiredReason2) {
      AuthRequiredReason2["Required"] = "required";
      AuthRequiredReason2["Expired"] = "expired";
    })(AuthRequiredReason || (AuthRequiredReason = {}));
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/notifications.js
var init_notifications2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/notifications.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-otlp/notifications.js
var init_notifications3 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-otlp/notifications.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/notifications.js
var init_notifications4 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/notifications.js"() {
    init_notifications();
    init_notifications2();
    init_notifications3();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/messages.js
var init_messages = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/messages.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/messages.js
var init_messages2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/messages.js"() {
    init_messages();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/errors.js
var JsonRpcErrorCodes, AhpErrorCodes;
var init_errors = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/errors.js"() {
    JsonRpcErrorCodes = {
      /** Invalid JSON */
      ParseError: -32700,
      /** Not a valid JSON-RPC request */
      InvalidRequest: -32600,
      /** Unknown method name */
      MethodNotFound: -32601,
      /** Invalid method parameters */
      InvalidParams: -32602,
      /** Unspecified server error */
      InternalError: -32603
    };
    AhpErrorCodes = {
      /** The referenced session URI does not exist */
      SessionNotFound: -32001,
      /** The requested agent provider is not registered */
      ProviderNotFound: -32002,
      /** A session with the given URI already exists */
      SessionAlreadyExists: -32003,
      /** The operation requires no active turn, but one is in progress */
      TurnInProgress: -32004,
      /**
       * The server cannot speak any of the protocol versions offered by the
       * client in `InitializeParams.protocolVersions`. The `data` field of the
       * JSON-RPC error MUST carry an `UnsupportedProtocolVersionErrorData`
       * advertising the protocol versions the server is willing to speak.
       */
      UnsupportedProtocolVersion: -32005,
      /**
       * A command failed because the client has not authenticated for a required
       * protected resource. The `data` field of the JSON-RPC error MUST be an
       * `AuthRequiredErrorData` describing the resources that require
       * authentication.
       *
       * @see {@link /specification/authentication | Authentication}
       */
      AuthRequired: -32007,
      /** The requested file, folder, or URI does not exist */
      NotFound: -32008,
      /**
       * The client is not permitted to access the requested resource.
       *
       * Servers SHOULD return this when a client attempts to read or browse
       * a path outside the allowed set (e.g. outside the session's working
       * directory or workspace roots).
       *
       * The `data` field of the JSON-RPC error MAY be a
       * `PermissionDeniedErrorData` advertising a `resourceRequest` that, if
       * granted, would unlock the operation.
       */
      PermissionDenied: -32009,
      /**
       * The target resource already exists and the operation does not allow
       * overwriting (e.g. `resourceWrite` with `createOnly: true`).
       */
      AlreadyExists: -32010,
      /**
       * An optimistic-concurrency precondition failed.
       *
       * Returned when a request carries a precondition token that no longer
       * matches the receiver's current state — for example, `resourceWrite`
       * with an `ifMatch` etag that has been superseded by a concurrent
       * write. Callers SHOULD re-read the resource (e.g. via
       * `resourceResolve`) and decide whether to retry the operation with the
       * fresh token or surface the conflict to the user.
       */
      Conflict: -32011
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/errors.js
var init_errors2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/errors.js"() {
    init_errors();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/version/registry.js
function parseSemver(version) {
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(version);
  if (!match || match[0] !== version) {
    throw new Error(`Invalid protocol version: ${version}`);
  }
  const parts = [Number(match[1]), Number(match[2]), Number(match[3])];
  return parts;
}
function negotiateProtocolVersion(offered) {
  let selected;
  for (const version of offered) {
    const [major, minor, patch] = parseSemver(version);
    const compatible = SUPPORTED_PROTOCOL_VERSIONS.some((baseline) => {
      const [baseMajor, baseMinor, basePatch] = parseSemver(baseline);
      return major === baseMajor && (major > 0 || minor === baseMinor) && (major > 0 || minor > 0 || patch === basePatch) && compareProtocolVersions(version, baseline) >= 0;
    });
    if (compatible && (selected === void 0 || compareProtocolVersions(version, selected) > 0)) {
      selected = version;
    }
  }
  return selected;
}
function compareProtocolVersions(a, b) {
  const [aMajor, aMinor, aPatch] = parseSemver(a);
  const [bMajor, bMinor, bPatch] = parseSemver(b);
  return aMajor - bMajor || aMinor - bMinor || aPatch - bPatch;
}
function isActionKnownToVersion(action, clientVersion) {
  return compareProtocolVersions(ACTION_INTRODUCED_IN[action.type], clientVersion) <= 0;
}
function isNotificationKnownToVersion(method, clientVersion) {
  return compareProtocolVersions(NOTIFICATION_INTRODUCED_IN[method], clientVersion) <= 0;
}
var PROTOCOL_VERSION, SUPPORTED_PROTOCOL_VERSIONS, ACTION_INTRODUCED_IN, NOTIFICATION_INTRODUCED_IN;
var init_registry = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/version/registry.js"() {
    init_actions12();
    PROTOCOL_VERSION = "1.0.0";
    SUPPORTED_PROTOCOL_VERSIONS = Object.freeze([
      "1.0.0",
      "0.9.0"
    ]);
    ACTION_INTRODUCED_IN = {
      [ActionType.RootAgentsChanged]: "0.1.0",
      [ActionType.RootActiveSessionsChanged]: "0.1.0",
      [ActionType.SessionReady]: "0.1.0",
      [ActionType.SessionCreationFailed]: "0.1.0",
      [ActionType.SessionChatAdded]: "0.4.0",
      [ActionType.SessionChatRemoved]: "0.4.0",
      [ActionType.SessionChatUpdated]: "0.4.0",
      [ActionType.SessionChatsReordered]: "0.9.0",
      [ActionType.SessionDefaultChatChanged]: "0.4.0",
      [ActionType.SessionTitleChanged]: "0.1.0",
      [ActionType.SessionServerToolsChanged]: "0.1.0",
      [ActionType.SessionActiveClientSet]: "0.5.0",
      [ActionType.SessionActiveClientRemoved]: "0.5.0",
      [ActionType.SessionWorkingDirectorySet]: "0.7.0",
      [ActionType.SessionWorkingDirectoryRemoved]: "0.7.0",
      [ActionType.SessionWorkingDirectoryReplaced]: "0.8.0",
      [ActionType.SessionInputNeededSet]: "0.5.1",
      [ActionType.SessionInputNeededRemoved]: "0.5.1",
      [ActionType.SessionCustomizationsChanged]: "0.1.0",
      [ActionType.SessionCustomizationToggled]: "0.1.0",
      [ActionType.SessionCustomizationUpdated]: "0.1.0",
      [ActionType.SessionCustomizationRemoved]: "0.2.0",
      [ActionType.SessionMcpServerStateChanged]: "0.3.0",
      [ActionType.SessionMcpServerStartRequested]: "0.5.2",
      [ActionType.SessionMcpServerStopRequested]: "0.5.2",
      [ActionType.SessionMcpServerBackgroundRequested]: "0.9.0",
      [ActionType.SessionIsReadChanged]: "0.1.0",
      [ActionType.SessionIsArchivedChanged]: "0.1.0",
      [ActionType.SessionActivityChanged]: "0.1.0",
      [ActionType.SessionChangesetsChanged]: "0.2.0",
      [ActionType.SessionConfigChanged]: "0.1.0",
      [ActionType.SessionMetaChanged]: "0.1.0",
      [ActionType.ChatTurnStarted]: "0.4.0",
      [ActionType.ChatDelta]: "0.4.0",
      [ActionType.ChatResponsePart]: "0.4.0",
      [ActionType.ChatToolCallStart]: "0.4.0",
      [ActionType.ChatToolCallDelta]: "0.4.0",
      [ActionType.ChatToolCallReady]: "0.4.0",
      [ActionType.ChatToolCallConfirmed]: "0.4.0",
      [ActionType.ChatToolCallComplete]: "0.4.0",
      [ActionType.ChatToolCallResultConfirmed]: "0.4.0",
      [ActionType.ChatToolCallContentChanged]: "0.4.0",
      [ActionType.ChatToolCallAuthRequired]: "0.6.0",
      [ActionType.ChatToolCallAuthResolved]: "0.6.0",
      [ActionType.ChatTurnComplete]: "0.4.0",
      [ActionType.ChatTurnCancelled]: "0.4.0",
      [ActionType.ChatError]: "0.4.0",
      [ActionType.ChatTurnResume]: "0.9.0",
      [ActionType.ChatActivityChanged]: "0.5.0",
      [ActionType.ChatBackgroundWorkSet]: "0.9.0",
      [ActionType.ChatBackgroundWorkRemoved]: "0.9.0",
      [ActionType.ChatMovableChanged]: "0.9.0",
      [ActionType.ChatChangesetsChanged]: "0.9.0",
      [ActionType.ChatCanvasesChanged]: "0.10.0",
      [ActionType.CanvasStateChanged]: "0.10.0",
      [ActionType.ChatWorkingDirectorySet]: "0.7.0",
      [ActionType.ChatWorkingDirectoryRemoved]: "0.7.0",
      [ActionType.ChatUsage]: "0.4.0",
      [ActionType.ChatReasoning]: "0.4.0",
      [ActionType.ChatPendingMessageSet]: "0.4.0",
      [ActionType.ChatPendingMessageRemoved]: "0.4.0",
      [ActionType.ChatQueuedMessagesReordered]: "0.4.0",
      [ActionType.ChatDraftChanged]: "0.5.0",
      [ActionType.ChatIsReadChanged]: "0.9.0",
      [ActionType.ChatIsArchivedChanged]: "0.9.0",
      [ActionType.ChatInputRequested]: "0.4.0",
      [ActionType.ChatInputAnswerChanged]: "0.4.0",
      [ActionType.ChatInputCompleted]: "0.4.0",
      [ActionType.ChatTruncated]: "0.4.0",
      [ActionType.ChatTurnsLoaded]: "0.5.1",
      [ActionType.ChangesetStatusChanged]: "0.2.0",
      [ActionType.ChangesetFileSet]: "0.2.0",
      [ActionType.ChangesetFileRemoved]: "0.2.0",
      [ActionType.ChangesetFilesReviewChanged]: "0.6.0",
      [ActionType.ChangesetContentChanged]: "0.4.0",
      [ActionType.ChangesetOperationsChanged]: "0.2.0",
      [ActionType.ChangesetOperationStatusChanged]: "0.3.0",
      [ActionType.ChangesetCleared]: "0.2.0",
      [ActionType.AnnotationsSet]: "0.4.0",
      [ActionType.AnnotationsUpdated]: "0.4.0",
      [ActionType.AnnotationsRemoved]: "0.4.0",
      [ActionType.AnnotationsEntrySet]: "0.4.0",
      [ActionType.AnnotationsEntryRemoved]: "0.4.0",
      [ActionType.RootTerminalsChanged]: "0.1.0",
      [ActionType.RootConfigChanged]: "0.1.0",
      [ActionType.TerminalData]: "0.1.0",
      [ActionType.TerminalInput]: "0.1.0",
      [ActionType.TerminalResized]: "0.1.0",
      [ActionType.TerminalClaimed]: "0.1.0",
      [ActionType.TerminalTitleChanged]: "0.1.0",
      [ActionType.TerminalCwdChanged]: "0.1.0",
      [ActionType.TerminalExited]: "0.1.0",
      [ActionType.TerminalCleared]: "0.1.0",
      [ActionType.TerminalCommandDetectionAvailable]: "0.1.0",
      [ActionType.TerminalCommandExecuted]: "0.1.0",
      [ActionType.TerminalCommandFinished]: "0.1.0",
      [ActionType.ResourceWatchChanged]: "0.2.0",
      [ActionType.AutomationCreateRequested]: "0.8.0",
      [ActionType.AutomationUpdateRequested]: "0.8.0",
      [ActionType.AutomationSet]: "0.8.0",
      [ActionType.AutomationRemoved]: "0.8.0",
      [ActionType.AutomationRunLifecycleChanged]: "0.8.0",
      [ActionType.AutomationRunSessionSet]: "0.8.0",
      [ActionType.AutomationRunSessionRemoved]: "0.8.0",
      [ActionType.AutomationRunPrimarySessionChanged]: "0.8.0",
      [ActionType.AutomationRunCancelRequested]: "0.8.0"
    };
    NOTIFICATION_INTRODUCED_IN = {
      "root/sessionAdded": "0.1.0",
      "root/sessionRemoved": "0.1.0",
      "root/sessionSummaryChanged": "0.1.0",
      "root/progress": "0.5.0",
      "auth/required": "0.1.0",
      "otlp/exportLogs": "0.2.0",
      "otlp/exportTraces": "0.2.0",
      "otlp/exportMetrics": "0.2.0"
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/reducer-helpers.js
function softAssertNever(value, log) {
  const msg = `Unhandled action type: ${JSON.stringify(value)}`;
  (log ?? console.warn)(msg);
}
function isClientDispatchable(action) {
  return IS_CLIENT_DISPATCHABLE[action.type];
}
var init_reducer_helpers = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/reducer-helpers.js"() {
    init_action_origin_generated();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/reducer.js
function rootReducer(state, action, log) {
  switch (action.type) {
    case ActionType.RootAgentsChanged:
      return { ...state, agents: action.agents };
    case ActionType.RootActiveSessionsChanged:
      return { ...state, activeSessions: action.activeSessions };
    case ActionType.RootTerminalsChanged:
      return { ...state, terminals: action.terminals };
    case ActionType.RootConfigChanged:
      if (!state.config) {
        return state;
      }
      return {
        ...state,
        config: {
          ...state.config,
          values: action.replace ? { ...action.config } : { ...state.config.values, ...action.config }
        }
      };
    default:
      softAssertNever(action, log);
      return state;
  }
}
var init_reducer = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-root/reducer.js"() {
    init_actions();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/reducer.js
function withStatusFlag(status, flag, set) {
  return set ? status | flag : status & ~flag;
}
function awaitsUser(request) {
  return request.kind !== SessionInputRequestKind.ToolClientExecution;
}
function withInputNeededStatus(status, inputNeeded) {
  if (inputNeeded.some(awaitsUser)) {
    return status & ~STATUS_ACTIVITY_MASK | SessionStatus.InputNeeded;
  }
  return status & ~(SessionStatus.InputNeeded & ~SessionStatus.InProgress);
}
function updateMcpServerCustomization(state, id, update) {
  const list = state.customizations;
  if (!list) {
    return state;
  }
  const topIdx = list.findIndex((c) => c.id === id);
  if (topIdx >= 0) {
    const entry = list[topIdx];
    if (entry.type !== CustomizationType.McpServer) {
      return state;
    }
    const updated2 = list.slice();
    updated2[topIdx] = update(entry);
    return { ...state, customizations: updated2 };
  }
  let changed = false;
  const updated = list.map((container) => {
    if (container.type === CustomizationType.McpServer) {
      return container;
    }
    const children = container.children;
    if (!children) {
      return container;
    }
    const childIdx = children.findIndex((c) => c.id === id);
    if (childIdx < 0) {
      return container;
    }
    const child = children[childIdx];
    if (child.type !== CustomizationType.McpServer) {
      return container;
    }
    changed = true;
    const newChildren = children.slice();
    newChildren[childIdx] = update(child);
    return { ...container, children: newChildren };
  });
  if (!changed) {
    return state;
  }
  return { ...state, customizations: updated };
}
function applyCustomizationEnablement(customization, enablement) {
  switch (customization.type) {
    case CustomizationType.Plugin:
    case CustomizationType.McpServer: {
      if (enablement.length > 0) {
        return { ...customization, enablement: [...enablement] };
      }
      const { enablement: _enablement, ...withoutEnablement } = customization;
      return withoutEnablement;
    }
    default:
      return { ...customization, enabled: enablement[0]?.enabled ?? true };
  }
}
function sessionReducer(state, action, log) {
  switch (action.type) {
    // ── Lifecycle ──────────────────────────────────────────────────────────
    case ActionType.SessionReady:
      return { ...state, lifecycle: SessionLifecycle.Ready };
    case ActionType.SessionCreationFailed:
      return {
        ...state,
        lifecycle: SessionLifecycle.Failed,
        creationError: action.error
      };
    case ActionType.SessionChatAdded: {
      const list = state.chats;
      const idx = list.findIndex((c) => c.resource === action.summary.resource);
      if (idx < 0) {
        return { ...state, chats: [...list, action.summary] };
      }
      const updated = list.slice();
      updated[idx] = action.summary;
      return { ...state, chats: updated };
    }
    case ActionType.SessionChatRemoved: {
      const list = state.chats;
      const idx = list.findIndex((c) => c.resource === action.chat);
      if (idx < 0) {
        return state;
      }
      const updated = list.slice();
      updated.splice(idx, 1);
      const next = { ...state, chats: updated };
      if (state.defaultChat === action.chat) {
        delete next.defaultChat;
      }
      return next;
    }
    case ActionType.SessionChatUpdated: {
      const list = state.chats;
      const idx = list.findIndex((c) => c.resource === action.chat);
      if (idx < 0) {
        return state;
      }
      const { resource: _ignored, ...changes } = action.changes;
      const updated = list.slice();
      updated[idx] = { ...list[idx], ...changes };
      return { ...state, chats: updated };
    }
    case ActionType.SessionChatsReordered: {
      const list = state.chats;
      if (action.chats.length !== list.length || new Set(action.chats).size !== list.length) {
        return state;
      }
      const summaries = new Map(list.map((summary) => [summary.resource, summary]));
      const reordered = [];
      for (const resource of action.chats) {
        const summary = summaries.get(resource);
        if (!summary) {
          return state;
        }
        reordered.push(summary);
      }
      if (reordered.every((summary, index) => summary === list[index])) {
        return state;
      }
      return { ...state, chats: reordered };
    }
    case ActionType.SessionDefaultChatChanged:
      return { ...state, defaultChat: action.defaultChat };
    // ── Metadata ──────────────────────────────────────────────────────────
    case ActionType.SessionTitleChanged:
      return { ...state, title: action.title };
    case ActionType.SessionIsReadChanged:
      return {
        ...state,
        status: withStatusFlag(state.status, SessionStatus.IsRead, action.isRead)
      };
    case ActionType.SessionIsArchivedChanged:
      return {
        ...state,
        status: withStatusFlag(state.status, SessionStatus.IsArchived, action.isArchived)
      };
    case ActionType.SessionActivityChanged:
      return { ...state, activity: action.activity };
    case ActionType.SessionChangesetsChanged: {
      const { changesets: _omit, ...stateWithoutChangesets } = state;
      return action.changesets ? { ...stateWithoutChangesets, changesets: action.changesets } : stateWithoutChangesets;
    }
    case ActionType.SessionConfigChanged:
      if (!state.config) {
        return state;
      }
      return {
        ...state,
        config: {
          ...state.config,
          values: action.replace ? { ...action.config } : { ...state.config.values, ...action.config }
        }
      };
    case ActionType.SessionMetaChanged:
      return { ...state, _meta: action._meta };
    case ActionType.SessionServerToolsChanged:
      return { ...state, serverTools: action.tools };
    case ActionType.SessionActiveClientSet: {
      const list = state.activeClients;
      const idx = list.findIndex((c) => c.clientId === action.activeClient.clientId);
      if (idx < 0) {
        return { ...state, activeClients: [...list, action.activeClient] };
      }
      const updated = list.slice();
      updated[idx] = action.activeClient;
      return { ...state, activeClients: updated };
    }
    case ActionType.SessionActiveClientRemoved: {
      const list = state.activeClients;
      const idx = list.findIndex((c) => c.clientId === action.clientId);
      if (idx < 0) {
        return state;
      }
      const updated = list.slice();
      updated.splice(idx, 1);
      return { ...state, activeClients: updated };
    }
    // ── Working Directories ─────────────────────────────────────────────
    case ActionType.SessionWorkingDirectorySet: {
      const list = state.workingDirectories ?? [];
      if (list.includes(action.directory)) {
        return state;
      }
      return { ...state, workingDirectories: [...list, action.directory] };
    }
    case ActionType.SessionWorkingDirectoryRemoved: {
      const list = state.workingDirectories;
      if (!list) {
        return state;
      }
      const idx = list.indexOf(action.directory);
      if (idx < 0) {
        return state;
      }
      const updated = list.slice();
      updated.splice(idx, 1);
      return { ...state, workingDirectories: updated };
    }
    case ActionType.SessionWorkingDirectoryReplaced: {
      const list = state.workingDirectories;
      if (!list) {
        return state;
      }
      const idx = list.indexOf(action.directory);
      if (idx < 0) {
        return state;
      }
      const replacementIdx = list.indexOf(action.replacement);
      if (replacementIdx >= 0 && replacementIdx < idx) {
        return {
          ...state,
          workingDirectories: list.filter((_, index) => index !== idx)
        };
      }
      return {
        ...state,
        workingDirectories: list.map((directory, index) => index === idx ? action.replacement : directory).filter((directory, index) => index === idx || directory !== action.replacement)
      };
    }
    // ── Input Needed ────────────────────────────────────────────────────
    case ActionType.SessionInputNeededSet: {
      const list = state.inputNeeded ?? [];
      const idx = list.findIndex((r) => r.id === action.request.id);
      const inputNeeded = idx < 0 ? [...list, action.request] : list.slice();
      if (idx >= 0) {
        inputNeeded[idx] = action.request;
      }
      return { ...state, inputNeeded, status: withInputNeededStatus(state.status, inputNeeded) };
    }
    case ActionType.SessionInputNeededRemoved: {
      const list = state.inputNeeded;
      if (!list) {
        return state;
      }
      const idx = list.findIndex((r) => r.id === action.id);
      if (idx < 0) {
        return state;
      }
      const remaining = list.slice();
      remaining.splice(idx, 1);
      const next = { ...state, status: withInputNeededStatus(state.status, remaining) };
      if (remaining.length > 0) {
        next.inputNeeded = remaining;
      } else {
        delete next.inputNeeded;
      }
      return next;
    }
    // ── Customizations ──────────────────────────────────────────────────
    case ActionType.SessionCustomizationsChanged:
      return { ...state, customizations: action.customizations };
    case ActionType.SessionCustomizationToggled: {
      const list = state.customizations;
      if (!list) {
        return state;
      }
      const topIdx = list.findIndex((c) => c.id === action.id);
      if (topIdx >= 0) {
        const updated = list.slice();
        updated[topIdx] = applyCustomizationEnablement(list[topIdx], action.enablement);
        return { ...state, customizations: updated };
      }
      for (let i = 0; i < list.length; i++) {
        const container = list[i];
        if (container.type === CustomizationType.McpServer) {
          continue;
        }
        const children = container.children;
        if (!children) {
          continue;
        }
        const childIdx = children.findIndex((c) => c.id === action.id);
        if (childIdx < 0) {
          continue;
        }
        const newChildren = children.slice();
        newChildren[childIdx] = applyCustomizationEnablement(children[childIdx], action.enablement);
        const updated = list.slice();
        updated[i] = { ...container, children: newChildren };
        return { ...state, customizations: updated };
      }
      return state;
    }
    case ActionType.SessionCustomizationUpdated: {
      const list = state.customizations ?? [];
      const idx = list.findIndex((c) => c.id === action.customization.id);
      if (idx < 0) {
        return { ...state, customizations: [...list, action.customization] };
      }
      const updated = [...list];
      updated[idx] = action.customization;
      return { ...state, customizations: updated };
    }
    case ActionType.SessionCustomizationRemoved: {
      const list = state.customizations;
      if (!list) {
        return state;
      }
      const topIdx = list.findIndex((c) => c.id === action.id);
      if (topIdx >= 0) {
        const updated2 = list.slice();
        updated2.splice(topIdx, 1);
        return { ...state, customizations: updated2 };
      }
      let changed = false;
      const updated = list.map((container) => {
        if (container.type === CustomizationType.McpServer) {
          return container;
        }
        const children = container.children;
        if (!children) {
          return container;
        }
        const childIdx = children.findIndex((c) => c.id === action.id);
        if (childIdx < 0) {
          return container;
        }
        changed = true;
        const newChildren = children.slice();
        newChildren.splice(childIdx, 1);
        return { ...container, children: newChildren };
      });
      if (!changed) {
        return state;
      }
      return { ...state, customizations: updated };
    }
    case ActionType.SessionMcpServerStateChanged: {
      return updateMcpServerCustomization(state, action.id, (entry) => ({
        ...entry,
        state: action.state,
        channel: action.channel
      }));
    }
    case ActionType.SessionMcpServerStartRequested: {
      return updateMcpServerCustomization(state, action.id, (entry) => ({
        ...entry,
        state: { kind: McpServerStatus.Starting },
        channel: void 0
      }));
    }
    case ActionType.SessionMcpServerBackgroundRequested: {
      return updateMcpServerCustomization(state, action.id, (entry) => entry.state.kind === McpServerStatus.Starting && entry.state.blocking ? { ...entry, state: { ...entry.state, blocking: false } } : entry);
    }
    case ActionType.SessionMcpServerStopRequested: {
      return updateMcpServerCustomization(state, action.id, (entry) => ({
        ...entry,
        state: { kind: McpServerStatus.Stopped },
        channel: void 0
      }));
    }
    default:
      softAssertNever(action, log);
      return state;
  }
}
var STATUS_ACTIVITY_MASK;
var init_reducer2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-session/reducer.js"() {
    init_actions();
    init_state3();
    init_reducer_helpers();
    STATUS_ACTIVITY_MASK = (1 << 5) - 1;
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/common/timestamps.js
function addMillisecondsToTimestamp(timestamp, duration) {
  return new Date(Date.parse(timestamp) + duration).toISOString();
}
var init_timestamps = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/common/timestamps.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/reducer.js
function tcBase(tc) {
  return {
    toolCallId: tc.toolCallId,
    toolName: tc.toolName,
    displayName: tc.displayName,
    intention: tc.intention,
    contributor: tc.contributor,
    _meta: tc._meta
  };
}
function tcBaseWithMeta(tc, meta) {
  return {
    ...tcBase(tc),
    _meta: meta ?? tc._meta
  };
}
function refineToolCallContributor(current, next, log) {
  if (!next) {
    return current;
  }
  if (current?.kind === ToolCallContributorKind.Client) {
    if (next.kind === ToolCallContributorKind.Client && next.clientId === current.clientId) {
      return next;
    }
    log?.(`Ignoring contributor change for client tool call from '${current.clientId}'`);
    return current;
  }
  if (next.kind === ToolCallContributorKind.Client) {
    log?.(`Ignoring late client contributor '${next.clientId}' because client execution ownership must be established at tool call start`);
    return current;
  }
  return next;
}
function resolveSelectedOption(options, id) {
  if (!id || !options) {
    return void 0;
  }
  return options.find((o) => o.id === id);
}
function hasBlockingToolCall(state) {
  if (!state.activeTurn) {
    return false;
  }
  return state.activeTurn.responseParts.some((part) => part.kind === ResponsePartKind.ToolCall && (part.toolCall.status === ToolCallStatus.PendingConfirmation || part.toolCall.status === ToolCallStatus.PendingResultConfirmation || part.toolCall.status === ToolCallStatus.AuthRequired));
}
function hasOpenInputRequest(state) {
  return state.activeTurn?.responseParts.some((part) => part.kind === ResponsePartKind.InputRequest && part.response === void 0) ?? false;
}
function findOpenInputRequestPart(responseParts, requestId) {
  const index = responseParts.findIndex((part2) => part2.kind === ResponsePartKind.InputRequest && part2.response === void 0 && part2.request.id === requestId);
  if (index < 0) {
    return void 0;
  }
  const part = responseParts[index];
  return part.kind === ResponsePartKind.InputRequest ? { index, part } : void 0;
}
function hasResumableError(turn) {
  const part = turn.responseParts[turn.responseParts.length - 1];
  return part?.kind === ResponsePartKind.Error && part.resumable === true;
}
function isErrorResponsePart(part) {
  return part.kind === ResponsePartKind.Error;
}
function withStatusFlag2(status, flag, set) {
  return set ? status | flag : status & ~flag;
}
function summaryStatus(state, terminalStatus) {
  let activity;
  if (terminalStatus) {
    activity = terminalStatus;
  } else if (hasOpenInputRequest(state) || hasBlockingToolCall(state)) {
    activity = SessionStatus.InputNeeded;
  } else if (state.activeTurn) {
    activity = SessionStatus.InProgress;
  } else {
    activity = SessionStatus.Idle;
  }
  return state.status & ~STATUS_ACTIVITY_MASK2 | activity;
}
function refreshSummaryStatus(state) {
  const status = summaryStatus(state);
  if (status === state.status) {
    return state;
  }
  return { ...state, status };
}
function endTurn(state, turnId, turnState, duration, terminalStatus, errorPart) {
  if (!state.activeTurn || state.activeTurn.id !== turnId) {
    return state;
  }
  const active = state.activeTurn;
  const responseParts = active.responseParts.map((part) => {
    if (part.kind !== ResponsePartKind.ToolCall) {
      return part;
    }
    const tc = part.toolCall;
    if (tc.status === ToolCallStatus.Completed || tc.status === ToolCallStatus.Cancelled) {
      return part;
    }
    return {
      kind: ResponsePartKind.ToolCall,
      toolCall: {
        status: ToolCallStatus.Cancelled,
        ...tcBase(tc),
        invocationMessage: tc.status === ToolCallStatus.Streaming ? tc.invocationMessage ?? "" : tc.invocationMessage,
        toolInput: tc.status === ToolCallStatus.Streaming ? void 0 : tc.toolInput,
        reason: ToolCallCancellationReason.Skipped
      }
    };
  });
  if (errorPart) {
    responseParts.push(errorPart);
  }
  const turn = {
    id: active.id,
    startedAt: active.startedAt,
    // Defensive clamp: the duration is producer-supplied and opaque to this
    // reducer, but a negative value would be nonsensical to display.
    duration: Math.max(0, duration),
    message: active.message,
    responseParts,
    usage: active.usage,
    state: turnState
  };
  const next = {
    ...state,
    turns: [...state.turns, turn],
    activeTurn: void 0,
    modifiedAt: addMillisecondsToTimestamp(active.startedAt, turn.duration ?? 0)
  };
  return {
    ...next,
    status: summaryStatus(next, terminalStatus)
  };
}
function upsertInputRequestPart(state, request) {
  const activeTurn = state.activeTurn;
  if (!activeTurn) {
    return state;
  }
  const existing = findOpenInputRequestPart(activeTurn.responseParts, request.id);
  const responseParts = [...activeTurn.responseParts];
  const part = {
    kind: ResponsePartKind.InputRequest,
    request
  };
  if (existing) {
    part.request = {
      ...request,
      answers: request.answers ?? existing.part.request.answers
    };
    responseParts[existing.index] = part;
  } else {
    responseParts.push(part);
  }
  const next = {
    ...state,
    activeTurn: {
      ...activeTurn,
      responseParts
    }
  };
  return { ...next, status: withStatusFlag2(summaryStatus(next), SessionStatus.IsRead, false) };
}
function updateToolCallInParts(state, turnId, toolCallId, updater) {
  const activeTurn = state.activeTurn;
  if (!activeTurn || activeTurn.id !== turnId) {
    return state;
  }
  let found = false;
  const responseParts = activeTurn.responseParts.map((part) => {
    if (part.kind === ResponsePartKind.ToolCall && part.toolCall.toolCallId === toolCallId) {
      const updated = updater(part.toolCall);
      if (updated === part.toolCall) {
        return part;
      }
      found = true;
      return { ...part, toolCall: updated };
    }
    return part;
  });
  if (!found) {
    return state;
  }
  return {
    ...state,
    activeTurn: { ...activeTurn, responseParts }
  };
}
function updateResponsePart(state, turnId, partId, updater) {
  const activeTurn = state.activeTurn;
  if (!activeTurn || activeTurn.id !== turnId) {
    return state;
  }
  let found = false;
  const responseParts = activeTurn.responseParts.map((part) => {
    if (!found) {
      const id = part.kind === ResponsePartKind.ToolCall ? part.toolCall.toolCallId : "id" in part ? part.id : void 0;
      if (id === partId) {
        found = true;
        return updater(part);
      }
    }
    return part;
  });
  if (!found) {
    return state;
  }
  return {
    ...state,
    activeTurn: { ...activeTurn, responseParts }
  };
}
function chatReducer(state, action, log) {
  switch (action.type) {
    // ── Turn Lifecycle ────────────────────────────────────────────────────
    case ActionType.ChatTurnStarted: {
      let next = {
        ...state,
        activeTurn: {
          id: action.turnId,
          startedAt: action.startedAt,
          message: action.message,
          responseParts: [],
          usage: void 0
        }
      };
      next = {
        ...next,
        status: withStatusFlag2(summaryStatus(next), SessionStatus.IsRead, false),
        modifiedAt: action.startedAt
      };
      if (action.queuedMessageId) {
        if (next.steeringMessage?.id === action.queuedMessageId) {
          next = { ...next, steeringMessage: void 0 };
        }
        if (next.queuedMessages) {
          const filtered = next.queuedMessages.filter((m) => m.id !== action.queuedMessageId);
          next = { ...next, queuedMessages: filtered.length > 0 ? filtered : void 0 };
        }
      }
      return next;
    }
    case ActionType.ChatDelta:
      return updateResponsePart(state, action.turnId, action.partId, (part) => {
        if (part.kind === ResponsePartKind.Markdown) {
          return { ...part, content: part.content + action.content };
        }
        return part;
      });
    case ActionType.ChatResponsePart:
      if (!state.activeTurn || state.activeTurn.id !== action.turnId) {
        return state;
      }
      if (isErrorResponsePart(action.part)) {
        return state;
      }
      return {
        ...state,
        activeTurn: {
          ...state.activeTurn,
          responseParts: [...state.activeTurn.responseParts, action.part]
        }
      };
    case ActionType.ChatTurnComplete:
      return endTurn(state, action.turnId, TurnState.Complete, action.duration);
    case ActionType.ChatTurnCancelled:
      return endTurn(state, action.turnId, TurnState.Cancelled, action.duration);
    case ActionType.ChatError:
      return endTurn(state, action.turnId, TurnState.Error, action.duration, SessionStatus.Error, action.part);
    case ActionType.ChatTurnResume: {
      if (state.activeTurn) {
        return state;
      }
      const turnIndex = state.turns.length - 1;
      const turn = state.turns[turnIndex];
      if (!turn || turn.id !== action.turnId || turn.state !== TurnState.Error || !hasResumableError(turn)) {
        return state;
      }
      const turns = state.turns.slice();
      turns.splice(turnIndex, 1);
      const next = {
        ...state,
        turns,
        activeTurn: {
          id: turn.id,
          startedAt: turn.startedAt ?? state.modifiedAt,
          message: turn.message,
          responseParts: turn.responseParts,
          usage: turn.usage
        }
      };
      return {
        ...next,
        status: withStatusFlag2(summaryStatus(next), SessionStatus.IsRead, false)
      };
    }
    case ActionType.ChatActivityChanged:
      return { ...state, activity: action.activity };
    case ActionType.ChatBackgroundWorkSet: {
      const list = state.backgroundWork ?? [];
      const idx = list.findIndex((work) => work.id === action.work.id);
      const next = list.slice();
      if (idx < 0) {
        next.push(action.work);
      } else {
        next[idx] = action.work;
      }
      return { ...state, backgroundWork: next };
    }
    case ActionType.ChatBackgroundWorkRemoved: {
      const list = state.backgroundWork ?? [];
      const idx = list.findIndex((work) => work.id === action.id);
      if (idx < 0) {
        return state;
      }
      const next = list.slice();
      next.splice(idx, 1);
      return { ...state, backgroundWork: next };
    }
    case ActionType.ChatMovableChanged:
      return { ...state, movable: action.movable };
    case ActionType.ChatChangesetsChanged: {
      const { changesets: _omit, ...stateWithoutChangesets } = state;
      return action.changesets ? { ...stateWithoutChangesets, changesets: action.changesets } : stateWithoutChangesets;
    }
    case ActionType.ChatCanvasesChanged: {
      const { canvases: _omit, ...stateWithoutCanvases } = state;
      return action.canvases ? { ...stateWithoutCanvases, canvases: action.canvases } : stateWithoutCanvases;
    }
    // ── Working Directories ───────────────────────────────────────────────
    case ActionType.ChatWorkingDirectorySet: {
      const list = state.workingDirectories ?? [];
      if (list.includes(action.directory)) {
        return state;
      }
      return { ...state, workingDirectories: [...list, action.directory] };
    }
    case ActionType.ChatWorkingDirectoryRemoved: {
      const list = state.workingDirectories;
      if (!list) {
        return state;
      }
      const idx = list.indexOf(action.directory);
      if (idx < 0) {
        return state;
      }
      const updated = list.slice();
      updated.splice(idx, 1);
      return { ...state, workingDirectories: updated };
    }
    // ── Tool Call State Machine ───────────────────────────────────────────
    case ActionType.ChatToolCallStart:
      if (!state.activeTurn || state.activeTurn.id !== action.turnId) {
        return state;
      }
      return {
        ...state,
        activeTurn: {
          ...state.activeTurn,
          responseParts: [
            ...state.activeTurn.responseParts,
            {
              kind: ResponsePartKind.ToolCall,
              toolCall: {
                toolCallId: action.toolCallId,
                toolName: action.toolName,
                displayName: action.displayName,
                intention: action.intention,
                contributor: action.contributor,
                _meta: action._meta,
                status: ToolCallStatus.Streaming
              }
            }
          ]
        }
      };
    case ActionType.ChatToolCallDelta:
      return updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.Streaming) {
          return tc;
        }
        return {
          ...tc,
          ...action._meta !== void 0 ? { _meta: action._meta } : {},
          ...action.content !== void 0 ? { partialInput: (tc.partialInput ?? "") + action.content } : {},
          invocationMessage: action.invocationMessage ?? tc.invocationMessage
        };
      });
    case ActionType.ChatToolCallReady:
      return refreshSummaryStatus(updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.Streaming && tc.status !== ToolCallStatus.Running && tc.status !== ToolCallStatus.PendingConfirmation) {
          return tc;
        }
        const base = {
          ...tcBaseWithMeta(tc, action._meta),
          contributor: refineToolCallContributor(tc.contributor, action.contributor, log),
          intention: action.intention ?? tc.intention
        };
        const toolInput = action.toolInput ?? (tc.status === ToolCallStatus.Streaming ? void 0 : tc.toolInput);
        if (action.confirmed) {
          return {
            status: ToolCallStatus.Running,
            ...base,
            invocationMessage: action.invocationMessage,
            toolInput,
            confirmed: action.confirmed
          };
        }
        const pending = tc.status === ToolCallStatus.PendingConfirmation ? tc : void 0;
        const options = action.options ?? pending?.options;
        return {
          status: ToolCallStatus.PendingConfirmation,
          ...base,
          invocationMessage: action.invocationMessage,
          toolInput,
          confirmationTitle: action.confirmationTitle ?? pending?.confirmationTitle,
          riskAssessment: action.riskAssessment ?? pending?.riskAssessment,
          edits: action.edits ?? pending?.edits,
          editable: action.editable ?? pending?.editable,
          ...options ? { options } : {}
        };
      }));
    case ActionType.ChatToolCallConfirmed:
      return refreshSummaryStatus(updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.PendingConfirmation) {
          return tc;
        }
        const base = tcBaseWithMeta(tc, action._meta);
        const selectedOption = resolveSelectedOption(tc.options, action.selectedOptionId);
        if (action.approved) {
          const toolInput = action.editedToolInput !== void 0 && typeof tc.toolInput === "string" ? action.editedToolInput : tc.toolInput;
          return {
            status: ToolCallStatus.Running,
            ...base,
            invocationMessage: tc.invocationMessage,
            toolInput,
            confirmed: action.confirmed,
            ...selectedOption ? { selectedOption } : {}
          };
        }
        return {
          status: ToolCallStatus.Cancelled,
          ...base,
          invocationMessage: tc.invocationMessage,
          toolInput: tc.toolInput,
          reason: action.reason,
          reasonMessage: action.reasonMessage,
          userSuggestion: action.userSuggestion,
          ...selectedOption ? { selectedOption } : {}
        };
      }));
    case ActionType.ChatToolCallComplete:
      return refreshSummaryStatus(updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.Running && tc.status !== ToolCallStatus.PendingConfirmation && tc.status !== ToolCallStatus.AuthRequired) {
          return tc;
        }
        if (tc.status === ToolCallStatus.AuthRequired && action.result.success) {
          return tc;
        }
        const base = tcBaseWithMeta(tc, action._meta);
        const confirmed = tc.status === ToolCallStatus.Running || tc.status === ToolCallStatus.AuthRequired ? tc.confirmed : ToolCallConfirmationReason.NotNeeded;
        const selectedOption = tc.status === ToolCallStatus.Running || tc.status === ToolCallStatus.AuthRequired ? tc.selectedOption : void 0;
        const preAuthContent = tc.status === ToolCallStatus.AuthRequired ? tc.content : void 0;
        if (action.requiresResultConfirmation && tc.status !== ToolCallStatus.AuthRequired) {
          return {
            status: ToolCallStatus.PendingResultConfirmation,
            ...base,
            invocationMessage: tc.invocationMessage,
            toolInput: tc.toolInput,
            confirmed,
            ...selectedOption ? { selectedOption } : {},
            ...preAuthContent ? { content: preAuthContent } : {},
            ...action.result
          };
        }
        return {
          status: ToolCallStatus.Completed,
          ...base,
          invocationMessage: tc.invocationMessage,
          toolInput: tc.toolInput,
          confirmed,
          ...selectedOption ? { selectedOption } : {},
          ...preAuthContent ? { content: preAuthContent } : {},
          ...action.result
        };
      }));
    case ActionType.ChatToolCallResultConfirmed:
      return refreshSummaryStatus(updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.PendingResultConfirmation) {
          return tc;
        }
        const base = tcBaseWithMeta(tc, action._meta);
        if (action.approved) {
          return {
            status: ToolCallStatus.Completed,
            ...base,
            invocationMessage: tc.invocationMessage,
            toolInput: tc.toolInput,
            confirmed: tc.confirmed,
            ...tc.selectedOption ? { selectedOption: tc.selectedOption } : {},
            success: tc.success,
            pastTenseMessage: tc.pastTenseMessage,
            content: tc.content,
            structuredContent: tc.structuredContent,
            error: tc.error
          };
        }
        return {
          status: ToolCallStatus.Cancelled,
          ...base,
          invocationMessage: tc.invocationMessage,
          toolInput: tc.toolInput,
          reason: ToolCallCancellationReason.ResultDenied,
          ...tc.selectedOption ? { selectedOption: tc.selectedOption } : {}
        };
      }));
    case ActionType.ChatToolCallContentChanged:
      return updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.Running) {
          return tc;
        }
        return {
          ...tc,
          ...action._meta !== void 0 ? { _meta: action._meta } : {},
          content: action.content
        };
      });
    case ActionType.ChatToolCallAuthRequired:
      return refreshSummaryStatus(updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.Running) {
          return tc;
        }
        if (!tc.contributor || tc.contributor.kind !== ToolCallContributorKind.MCP) {
          return tc;
        }
        const base = tcBaseWithMeta(tc, action._meta);
        return {
          status: ToolCallStatus.AuthRequired,
          ...base,
          contributor: tc.contributor,
          invocationMessage: tc.invocationMessage,
          toolInput: tc.toolInput,
          confirmed: tc.confirmed,
          ...tc.selectedOption ? { selectedOption: tc.selectedOption } : {},
          ...tc.content ? { content: tc.content } : {},
          auth: action.auth
        };
      }));
    case ActionType.ChatToolCallAuthResolved:
      return refreshSummaryStatus(updateToolCallInParts(state, action.turnId, action.toolCallId, (tc) => {
        if (tc.status !== ToolCallStatus.AuthRequired) {
          return tc;
        }
        const base = tcBaseWithMeta(tc, action._meta);
        return {
          status: ToolCallStatus.Running,
          ...base,
          invocationMessage: tc.invocationMessage,
          toolInput: tc.toolInput,
          confirmed: tc.confirmed,
          ...tc.selectedOption ? { selectedOption: tc.selectedOption } : {},
          ...tc.content ? { content: tc.content } : {}
        };
      }));
    case ActionType.ChatUsage:
      if (!state.activeTurn || state.activeTurn.id !== action.turnId) {
        return state;
      }
      return {
        ...state,
        activeTurn: { ...state.activeTurn, usage: action.usage }
      };
    case ActionType.ChatReasoning:
      return updateResponsePart(state, action.turnId, action.partId, (part) => {
        if (part.kind === ResponsePartKind.Reasoning) {
          return { ...part, content: part.content + action.content };
        }
        return part;
      });
    // ── Truncation ────────────────────────────────────────────────────────
    case ActionType.ChatTruncated: {
      let turns;
      if (action.turnId === void 0) {
        turns = [];
      } else {
        const idx = state.turns.findIndex((t) => t.id === action.turnId);
        if (idx < 0) {
          return state;
        }
        turns = state.turns.slice(0, idx + 1);
      }
      const next = {
        ...state,
        turns,
        activeTurn: void 0
      };
      if (action.turnId === void 0) {
        delete next.turnsNextCursor;
      }
      return {
        ...next,
        status: summaryStatus(next)
      };
    }
    case ActionType.ChatTurnsLoaded: {
      const existingIds = new Set(state.turns.map((turn) => turn.id));
      const olderTurns = action.turns.filter((turn) => !existingIds.has(turn.id));
      return {
        ...state,
        turns: [...olderTurns, ...state.turns],
        turnsNextCursor: action.turnsNextCursor
      };
    }
    // ── Session Input Requests ─────────────────────────────────────────────
    case ActionType.ChatInputRequested:
      return upsertInputRequestPart(state, action.request);
    case ActionType.ChatInputAnswerChanged: {
      const activeTurn = state.activeTurn;
      const existing = activeTurn ? findOpenInputRequestPart(activeTurn.responseParts, action.requestId) : void 0;
      if (!activeTurn || !existing) {
        return state;
      }
      const { index, part } = existing;
      const request = part.request;
      const answers = { ...request.answers ?? {} };
      if (action.answer === void 0) {
        delete answers[action.questionId];
      } else {
        answers[action.questionId] = action.answer;
      }
      const responseParts = [...activeTurn.responseParts];
      responseParts[index] = {
        ...part,
        request: {
          ...request,
          answers: Object.keys(answers).length > 0 ? answers : void 0
        }
      };
      return {
        ...state,
        activeTurn: {
          ...activeTurn,
          responseParts
        }
      };
    }
    case ActionType.ChatInputCompleted: {
      const activeTurn = state.activeTurn;
      const existing = activeTurn ? findOpenInputRequestPart(activeTurn.responseParts, action.requestId) : void 0;
      if (!activeTurn || !existing) {
        return state;
      }
      const { index, part } = existing;
      const finalAnswers = { ...part.request.answers ?? {}, ...action.answers ?? {} };
      const responseParts = [...activeTurn.responseParts];
      responseParts[index] = {
        ...part,
        request: {
          ...part.request,
          answers: Object.keys(finalAnswers).length > 0 ? finalAnswers : void 0
        },
        response: action.response
      };
      const next = {
        ...state,
        activeTurn: {
          ...activeTurn,
          responseParts
        }
      };
      return {
        ...next,
        status: summaryStatus(next)
      };
    }
    // ── Pending Messages ──────────────────────────────────────────────────
    case ActionType.ChatPendingMessageSet: {
      const entry = { id: action.id, message: action.message };
      if (action.kind === PendingMessageKind.Steering) {
        return { ...state, steeringMessage: entry };
      }
      const existing = state.queuedMessages ?? [];
      const idx = existing.findIndex((m) => m.id === action.id);
      if (idx >= 0) {
        const updated = [...existing];
        updated[idx] = entry;
        return { ...state, queuedMessages: updated };
      }
      return { ...state, queuedMessages: [...existing, entry] };
    }
    case ActionType.ChatPendingMessageRemoved: {
      if (action.kind === PendingMessageKind.Steering) {
        if (!state.steeringMessage || state.steeringMessage.id !== action.id) {
          return state;
        }
        return { ...state, steeringMessage: void 0 };
      }
      const existing = state.queuedMessages;
      if (!existing) {
        return state;
      }
      const filtered = existing.filter((m) => m.id !== action.id);
      return filtered.length === existing.length ? state : { ...state, queuedMessages: filtered.length > 0 ? filtered : void 0 };
    }
    case ActionType.ChatQueuedMessagesReordered: {
      const existing = state.queuedMessages;
      if (!existing) {
        return state;
      }
      const byId = new Map(existing.map((m) => [m.id, m]));
      const ordered = /* @__PURE__ */ new Set();
      const reordered = action.order.filter((id) => {
        if (byId.has(id) && !ordered.has(id)) {
          ordered.add(id);
          return true;
        }
        return false;
      }).map((id) => byId.get(id));
      for (const m of existing) {
        if (!ordered.has(m.id)) {
          reordered.push(m);
        }
      }
      return { ...state, queuedMessages: reordered };
    }
    // ── Draft ─────────────────────────────────────────────────────────────
    case ActionType.ChatDraftChanged:
      return { ...state, draft: action.draft };
    case ActionType.ChatIsReadChanged:
      return { ...state, status: withStatusFlag2(state.status, SessionStatus.IsRead, action.isRead) };
    case ActionType.ChatIsArchivedChanged:
      return { ...state, status: withStatusFlag2(state.status, SessionStatus.IsArchived, action.isArchived) };
    default:
      softAssertNever(action, log);
      return state;
  }
}
var STATUS_ACTIVITY_MASK2;
var init_reducer3 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-chat/reducer.js"() {
    init_actions();
    init_state4();
    init_state3();
    init_reducer_helpers();
    init_timestamps();
    STATUS_ACTIVITY_MASK2 = (1 << 5) - 1;
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-canvas/reducer.js
function canvasReducer(state, action, log) {
  if (action.type === ActionType.CanvasStateChanged) {
    return action.canvas;
  }
  (log ?? console.warn)(`Unhandled action type: ${JSON.stringify(action)}`);
  return state;
}
var init_reducer4 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-canvas/reducer.js"() {
    init_actions();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/reducer.js
function terminalReducer(state, action, log) {
  switch (action.type) {
    case ActionType.TerminalData: {
      const content = [...state.content];
      const tail = content.length > 0 ? content[content.length - 1] : void 0;
      if (tail && tail.type === "command" && !tail.isComplete) {
        content[content.length - 1] = { ...tail, output: tail.output + action.data };
      } else if (tail && tail.type === "unclassified") {
        content[content.length - 1] = { ...tail, value: tail.value + action.data };
      } else {
        content.push({ type: "unclassified", value: action.data });
      }
      return { ...state, content };
    }
    case ActionType.TerminalInput:
      return state;
    case ActionType.TerminalResized:
      return { ...state, cols: action.cols, rows: action.rows };
    case ActionType.TerminalClaimed:
      return { ...state, claim: action.claim };
    case ActionType.TerminalTitleChanged:
      return { ...state, title: action.title };
    case ActionType.TerminalCwdChanged:
      return { ...state, cwd: action.cwd };
    case ActionType.TerminalExited:
      return {
        ...state,
        lifecycle: {
          status: TerminalLifecycleStatus.Exited,
          exitCode: action.exitCode
        }
      };
    case ActionType.TerminalCleared:
      return { ...state, content: [] };
    case ActionType.TerminalCommandDetectionAvailable:
      return { ...state, supportsCommandDetection: true };
    case ActionType.TerminalCommandExecuted: {
      const part = {
        type: "command",
        commandId: action.commandId,
        commandLine: action.commandLine,
        output: "",
        timestamp: action.timestamp,
        isComplete: false
      };
      return {
        ...state,
        content: [...state.content, part],
        supportsCommandDetection: true
      };
    }
    case ActionType.TerminalCommandFinished: {
      const content = state.content.map((p) => {
        if (p.type === "command" && p.commandId === action.commandId) {
          return {
            ...p,
            isComplete: true,
            exitCode: action.exitCode,
            durationMs: action.durationMs
          };
        }
        return p;
      });
      return { ...state, content };
    }
    default:
      softAssertNever(action, log);
      return state;
  }
}
var init_reducer5 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-terminal/reducer.js"() {
    init_actions();
    init_state6();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/reducer.js
function changesetReducer(state, action, log) {
  switch (action.type) {
    case ActionType.ChangesetStatusChanged: {
      if (action.status === ChangesetStatus.Error) {
        return { ...state, status: action.status, error: action.error };
      }
      const { error: _ignored, ...rest } = state;
      return { ...rest, status: action.status };
    }
    case ActionType.ChangesetFileSet: {
      const idx = state.files.findIndex((f) => f.id === action.file.id);
      if (idx < 0) {
        return { ...state, files: [...state.files, action.file] };
      }
      const next = [...state.files];
      next[idx] = action.file;
      return { ...state, files: next };
    }
    case ActionType.ChangesetFileRemoved: {
      const idx = state.files.findIndex((f) => f.id === action.fileId);
      if (idx < 0) {
        return state;
      }
      const next = [...state.files];
      next.splice(idx, 1);
      return { ...state, files: next };
    }
    case ActionType.ChangesetFilesReviewChanged: {
      let changed = false;
      const ids = new Set(action.files);
      const next = state.files.map((f) => {
        if (!ids.has(f.id) || f.reviewed === action.reviewed) {
          return f;
        }
        changed = true;
        return { ...f, reviewed: action.reviewed };
      });
      return changed ? { ...state, files: next } : state;
    }
    case ActionType.ChangesetContentChanged: {
      return action.operations === void 0 ? { ...state, files: action.files } : { ...state, files: action.files, operations: action.operations };
    }
    case ActionType.ChangesetOperationsChanged: {
      if (action.operations === void 0) {
        const { operations: _ignored, ...rest } = state;
        return rest;
      }
      return { ...state, operations: action.operations };
    }
    case ActionType.ChangesetOperationStatusChanged: {
      if (state.operations === void 0) {
        return state;
      }
      const idx = state.operations.findIndex((o) => o.id === action.operationId);
      if (idx < 0) {
        return state;
      }
      const current = state.operations[idx];
      let nextOp;
      if (action.status === ChangesetOperationStatus.Error) {
        nextOp = { ...current, status: action.status, error: action.error };
      } else {
        const { error: _ignored, ...rest } = current;
        nextOp = { ...rest, status: action.status };
      }
      const next = [...state.operations];
      next[idx] = nextOp;
      return { ...state, operations: next };
    }
    case ActionType.ChangesetCleared:
      if (state.files.length === 0) {
        return state;
      }
      return { ...state, files: [] };
    default:
      softAssertNever(action, log);
      return state;
  }
}
var init_reducer6 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-changeset/reducer.js"() {
    init_actions();
    init_state7();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-annotations/reducer.js
function annotationsReducer(state, action, log) {
  switch (action.type) {
    case ActionType.AnnotationsSet: {
      const idx = state.annotations.findIndex((t) => t.id === action.annotation.id);
      if (idx < 0) {
        return { ...state, annotations: [...state.annotations, action.annotation] };
      }
      const next = [...state.annotations];
      next[idx] = action.annotation;
      return { ...state, annotations: next };
    }
    case ActionType.AnnotationsUpdated: {
      const idx = state.annotations.findIndex((t) => t.id === action.annotationId);
      if (idx < 0) {
        return state;
      }
      const annotation = state.annotations[idx];
      const updated = { ...annotation };
      if (action.origin !== void 0) {
        updated.origin = action.origin;
      }
      if (action.resource !== void 0) {
        updated.resource = action.resource;
      }
      if (action.range !== void 0) {
        updated.range = action.range;
      }
      if (action.resolved !== void 0) {
        updated.resolved = action.resolved;
      }
      const next = [...state.annotations];
      next[idx] = updated;
      return { ...state, annotations: next };
    }
    case ActionType.AnnotationsRemoved: {
      const idx = state.annotations.findIndex((t) => t.id === action.annotationId);
      if (idx < 0) {
        return state;
      }
      const next = [...state.annotations];
      next.splice(idx, 1);
      return { ...state, annotations: next };
    }
    case ActionType.AnnotationsEntrySet: {
      const tIdx = state.annotations.findIndex((t) => t.id === action.annotationId);
      if (tIdx < 0) {
        return state;
      }
      const annotation = state.annotations[tIdx];
      const cIdx = annotation.entries.findIndex((c) => c.id === action.entry.id);
      let nextEntries;
      if (cIdx < 0) {
        nextEntries = [...annotation.entries, action.entry];
      } else {
        nextEntries = [...annotation.entries];
        nextEntries[cIdx] = action.entry;
      }
      const nextAnnotations = [...state.annotations];
      nextAnnotations[tIdx] = { ...annotation, entries: nextEntries };
      return { ...state, annotations: nextAnnotations };
    }
    case ActionType.AnnotationsEntryRemoved: {
      const tIdx = state.annotations.findIndex((t) => t.id === action.annotationId);
      if (tIdx < 0) {
        return state;
      }
      const annotation = state.annotations[tIdx];
      const cIdx = annotation.entries.findIndex((c) => c.id === action.entryId);
      if (cIdx < 0) {
        return state;
      }
      const nextEntries = [...annotation.entries];
      nextEntries.splice(cIdx, 1);
      const nextAnnotations = [...state.annotations];
      nextAnnotations[tIdx] = { ...annotation, entries: nextEntries };
      return { ...state, annotations: nextAnnotations };
    }
    default:
      softAssertNever(action, log);
      return state;
  }
}
var init_reducer7 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-annotations/reducer.js"() {
    init_actions();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/reducer.js
function resourceWatchReducer(state, action, log) {
  if (action.type === ActionType.ResourceWatchChanged) {
    return state;
  }
  (log ?? console.warn)(`Unhandled action type: ${JSON.stringify(action)}`);
  return state;
}
var init_reducer8 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-resource-watch/reducer.js"() {
    init_actions();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/reducer.js
function automationReducer(state, action, log) {
  switch (action.type) {
    case ActionType.AutomationCreateRequested:
    case ActionType.AutomationUpdateRequested:
      return state;
    case ActionType.AutomationSet: {
      const idx = state.entries.findIndex((automation) => automation.resource === action.automation.resource);
      if (idx < 0) {
        return {
          ...state,
          entries: [...state.entries, action.automation]
        };
      }
      const entries = state.entries.slice();
      entries[idx] = action.automation;
      return { ...state, entries };
    }
    case ActionType.AutomationRemoved: {
      const idx = state.entries.findIndex((automation) => automation.resource === action.resource);
      if (idx < 0) {
        return state;
      }
      const entries = state.entries.slice();
      entries.splice(idx, 1);
      return { ...state, entries };
    }
    default:
      softAssertNever(action, log);
      return state;
  }
}
var init_reducer9 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation/reducer.js"() {
    init_actions();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation-run/reducer.js
function automationRunReducer(state, action, log) {
  switch (action.type) {
    case ActionType.AutomationRunLifecycleChanged:
      return { ...state, lifecycle: action.lifecycle };
    case ActionType.AutomationRunSessionSet:
      if (state.sessions.includes(action.session)) {
        return state;
      }
      return { ...state, sessions: [...state.sessions, action.session] };
    case ActionType.AutomationRunSessionRemoved: {
      const index = state.sessions.indexOf(action.session);
      if (index < 0) {
        return state;
      }
      const sessions = state.sessions.slice();
      sessions.splice(index, 1);
      const next = { ...state, sessions };
      if (state.primarySession === action.session) {
        delete next.primarySession;
      }
      return next;
    }
    case ActionType.AutomationRunPrimarySessionChanged: {
      const next = { ...state };
      if (action.primarySession === void 0) {
        delete next.primarySession;
      } else {
        next.primarySession = action.primarySession;
      }
      return next;
    }
    case ActionType.AutomationRunCancelRequested:
      return state;
    default:
      softAssertNever(action, log);
      return state;
  }
}
var init_reducer10 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/channels-automation-run/reducer.js"() {
    init_actions();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/reducers.js
var init_reducers = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/reducers.js"() {
    init_reducer();
    init_reducer2();
    init_reducer3();
    init_reducer4();
    init_reducer5();
    init_reducer6();
    init_reducer7();
    init_reducer8();
    init_reducer9();
    init_reducer10();
    init_reducer_helpers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/types/index.js
var types_exports = {};
__export(types_exports, {
  ACTION_INTRODUCED_IN: () => ACTION_INTRODUCED_IN,
  ActionType: () => ActionType,
  AhpErrorCodes: () => AhpErrorCodes,
  AuthRequiredReason: () => AuthRequiredReason,
  AutomationDisableConditionKind: () => AutomationDisableConditionKind,
  AutomationMisfirePolicy: () => AutomationMisfirePolicy,
  AutomationOperation: () => AutomationOperation,
  AutomationRunOriginKind: () => AutomationRunOriginKind,
  AutomationRunStatus: () => AutomationRunStatus,
  AutomationTriggerKind: () => AutomationTriggerKind,
  BackgroundWorkKind: () => BackgroundWorkKind,
  ChangesetOperationScope: () => ChangesetOperationScope,
  ChangesetOperationStatus: () => ChangesetOperationStatus,
  ChangesetOperationTargetKind: () => ChangesetOperationTargetKind,
  ChangesetStatus: () => ChangesetStatus,
  ChatInputAnswerState: () => ChatInputAnswerState,
  ChatInputAnswerValueKind: () => ChatInputAnswerValueKind,
  ChatInputQuestionKind: () => ChatInputQuestionKind,
  ChatInputResponseKind: () => ChatInputResponseKind,
  ChatInteractivity: () => ChatInteractivity,
  ChatMoveDestinationKind: () => ChatMoveDestinationKind,
  ChatOriginKind: () => ChatOriginKind,
  ChatSourceKind: () => ChatSourceKind,
  CompletionItemKind: () => CompletionItemKind,
  ConfirmationOptionKind: () => ConfirmationOptionKind,
  ContentEncoding: () => ContentEncoding,
  CustomizationEnablementKind: () => CustomizationEnablementKind,
  CustomizationLoadStatus: () => CustomizationLoadStatus,
  CustomizationType: () => CustomizationType,
  IS_CLIENT_DISPATCHABLE: () => IS_CLIENT_DISPATCHABLE,
  JsonRpcErrorCodes: () => JsonRpcErrorCodes,
  McpAuthRequiredReason: () => McpAuthRequiredReason,
  McpServerStatus: () => McpServerStatus,
  MessageAttachmentKind: () => MessageAttachmentKind,
  MessageKind: () => MessageKind,
  NOTIFICATION_INTRODUCED_IN: () => NOTIFICATION_INTRODUCED_IN,
  PROTOCOL_VERSION: () => PROTOCOL_VERSION,
  PendingMessageKind: () => PendingMessageKind,
  PolicyState: () => PolicyState,
  ReconnectResultType: () => ReconnectResultType,
  ResourceChangeType: () => ResourceChangeType,
  ResourceType: () => ResourceType,
  ResourceWriteMode: () => ResourceWriteMode,
  ResponsePartKind: () => ResponsePartKind,
  SUPPORTED_PROTOCOL_VERSIONS: () => SUPPORTED_PROTOCOL_VERSIONS,
  SessionInputRequestKind: () => SessionInputRequestKind,
  SessionLifecycle: () => SessionLifecycle,
  SessionOriginKind: () => SessionOriginKind,
  SessionStatus: () => SessionStatus,
  TerminalClaimKind: () => TerminalClaimKind,
  TerminalLifecycleStatus: () => TerminalLifecycleStatus,
  ToolCallCancellationReason: () => ToolCallCancellationReason,
  ToolCallConfirmationReason: () => ToolCallConfirmationReason,
  ToolCallContributorKind: () => ToolCallContributorKind,
  ToolCallRiskAssessmentKind: () => ToolCallRiskAssessmentKind,
  ToolCallRiskAssessmentStatus: () => ToolCallRiskAssessmentStatus,
  ToolCallStatus: () => ToolCallStatus,
  ToolResultContentType: () => ToolResultContentType,
  TurnState: () => TurnState,
  annotationsReducer: () => annotationsReducer,
  automationReducer: () => automationReducer,
  automationRunReducer: () => automationRunReducer,
  canvasReducer: () => canvasReducer,
  changesetReducer: () => changesetReducer,
  chatReducer: () => chatReducer,
  compareProtocolVersions: () => compareProtocolVersions,
  isActionKnownToVersion: () => isActionKnownToVersion,
  isClientDispatchable: () => isClientDispatchable,
  isNotificationKnownToVersion: () => isNotificationKnownToVersion,
  negotiateProtocolVersion: () => negotiateProtocolVersion,
  resourceWatchReducer: () => resourceWatchReducer,
  rootReducer: () => rootReducer,
  sessionReducer: () => sessionReducer,
  terminalReducer: () => terminalReducer
});
var init_types = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/types/index.js"() {
    init_state13();
    init_actions12();
    init_action_origin_generated();
    init_commands9();
    init_notifications4();
    init_messages2();
    init_errors2();
    init_registry();
    init_reducers();
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/async-queue.js
var AsyncBroadcastQueue;
var init_async_queue = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/async-queue.js"() {
    AsyncBroadcastQueue = class {
      buffer = [];
      /** Absolute logical position of `buffer[0]` (entries below have been dropped). */
      base = 0;
      cursors = /* @__PURE__ */ new Set();
      closed = false;
      bufferLimit;
      constructor(bufferLimit = 4096) {
        this.bufferLimit = bufferLimit;
      }
      /** Whether the queue has been closed. New readers see immediate end-of-stream. */
      get isClosed() {
        return this.closed;
      }
      /** Whether at least one reader is attached. */
      get hasReaders() {
        return this.cursors.size > 0;
      }
      /** Publish a value to every attached reader. */
      publish(value) {
        if (this.closed)
          return;
        this.buffer.push(value);
        if (this.buffer.length > this.bufferLimit) {
          const drop = this.buffer.length - this.bufferLimit;
          this.buffer.splice(0, drop);
          this.base += drop;
          for (const cursor of this.cursors) {
            if (cursor.position < this.base)
              cursor.position = this.base;
          }
        }
        const lastPos = this.base + this.buffer.length - 1;
        for (const cursor of this.cursors) {
          if (cursor.waiter && cursor.position <= lastPos) {
            const idx = cursor.position - this.base;
            const item = this.buffer[idx];
            cursor.position += 1;
            const w = cursor.waiter;
            cursor.waiter = null;
            w.resolve({ value: item, done: false });
          }
        }
        this.trim();
      }
      /**
       * Close the queue. New readers see immediate end-of-stream. Existing
       * readers can still drain values that were published before close;
       * once their cursor reaches the end of the buffer they see end-of-stream.
       */
      close() {
        if (this.closed)
          return;
        this.closed = true;
        for (const cursor of this.cursors) {
          if (cursor.waiter && cursor.position - this.base >= this.buffer.length) {
            const w = cursor.waiter;
            cursor.waiter = null;
            w.resolve({ value: void 0, done: true });
          }
        }
      }
      /** Create a new independent reader. */
      reader() {
        const cursor = {
          position: this.base + this.buffer.length,
          waiter: null,
          detached: this.closed
        };
        if (!this.closed)
          this.cursors.add(cursor);
        const queue = this;
        const detach = () => {
          if (!cursor.detached) {
            cursor.detached = true;
            queue.cursors.delete(cursor);
            queue.trim();
          }
        };
        const iter = {
          [Symbol.asyncIterator]() {
            return this;
          },
          next() {
            if (cursor.detached) {
              return Promise.resolve({ value: void 0, done: true });
            }
            const idx = cursor.position - queue.base;
            if (idx >= 0 && idx < queue.buffer.length) {
              const item = queue.buffer[idx];
              cursor.position += 1;
              queue.trim();
              return Promise.resolve({ value: item, done: false });
            }
            if (queue.closed) {
              return Promise.resolve({ value: void 0, done: true });
            }
            return new Promise((resolve9) => {
              cursor.waiter = { resolve: resolve9 };
            });
          },
          return() {
            detach();
            return Promise.resolve({ value: void 0, done: true });
          }
        };
        return iter;
      }
      [Symbol.asyncIterator]() {
        return this.reader();
      }
      /** Drop buffer entries that every cursor has already consumed. */
      trim() {
        if (this.cursors.size === 0) {
          const dropped = this.buffer.length;
          if (dropped > 0) {
            this.buffer = [];
            this.base += dropped;
          }
          return;
        }
        let minPos = Infinity;
        for (const cursor of this.cursors) {
          if (cursor.position < minPos)
            minPos = cursor.position;
        }
        const drop = minPos - this.base;
        if (drop > 0) {
          this.buffer.splice(0, drop);
          this.base += drop;
        }
      }
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/error.js
var AhpClientError, RpcError, RpcTimeoutError, TransportError, ClientClosedError;
var init_error = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/error.js"() {
    AhpClientError = class extends Error {
      constructor(message, options) {
        super(message, options);
        this.name = "AhpClientError";
      }
    };
    RpcError = class extends AhpClientError {
      /** JSON-RPC numeric error code. See `JsonRpcErrorCodes` and `AhpErrorCodes`. */
      code;
      /** Optional structured payload included in the response. */
      data;
      constructor(code, message, data) {
        super(`RPC error ${code}: ${message}`);
        this.name = "RpcError";
        this.code = code;
        this.data = data;
      }
    };
    RpcTimeoutError = class extends AhpClientError {
      /** The JSON-RPC method name that timed out. */
      method;
      /** The configured timeout in milliseconds that was exceeded. */
      timeoutMs;
      constructor(method, timeoutMs) {
        super(`Request "${method}" timed out after ${timeoutMs}ms`);
        this.name = "RpcTimeoutError";
        this.method = method;
        this.timeoutMs = timeoutMs;
      }
    };
    TransportError = class extends AhpClientError {
      /** What kind of transport failure this represents. */
      kind;
      constructor(kind, message, options) {
        super(message, options);
        this.name = "TransportError";
        this.kind = kind;
      }
    };
    ClientClosedError = class extends AhpClientError {
      constructor(message = "client shut down") {
        super(message);
        this.name = "ClientClosedError";
      }
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/transport.js
function encodeMessage(message) {
  return JSON.stringify(message);
}
function decodeMessage(text) {
  try {
    return JSON.parse(text);
  } catch (cause) {
    throw new TransportError("protocol", `invalid JSON: ${cause.message}`, { cause });
  }
}
var InMemoryHalf, InMemoryTransport;
var init_transport = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/transport.js"() {
    init_error();
    InMemoryHalf = class {
      inbox = [];
      waiter = null;
      closed = false;
      /** @internal */
      peer;
      send(message) {
        if (this.closed) {
          throw new TransportError("closed", "transport closed");
        }
        const text = typeof message === "string" ? message : encodeMessage(message);
        this.peer.deliver({ kind: "text", text });
      }
      recv() {
        if (this.inbox.length > 0) {
          return Promise.resolve(this.inbox.shift() ?? null);
        }
        if (this.closed) {
          return Promise.resolve(null);
        }
        return new Promise((resolve9) => {
          this.waiter = resolve9;
        });
      }
      close() {
        if (this.closed)
          return;
        this.closed = true;
        this.deliver(null);
        this.peer.deliver(null);
      }
      /** @internal */
      deliver(frame) {
        if (this.waiter) {
          const w = this.waiter;
          this.waiter = null;
          w(frame);
        } else {
          this.inbox.push(frame);
        }
      }
    };
    InMemoryTransport = {
      /** Returns a connected `[a, b]` pair. */
      pair() {
        const a = new InMemoryHalf();
        const b = new InMemoryHalf();
        a.peer = b;
        b.peer = a;
        return [a, b];
      }
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/client.js
function noop() {
}
function createResourceRequestHandler(handlers) {
  return async (method, params) => {
    const handler = handlers[method];
    if (!handler) {
      throw new RpcError(JsonRpcErrorCodes.MethodNotFound, `no handler for server method "${method}"`);
    }
    return handler(params);
  };
}
var DEFAULT_REQUEST_TIMEOUT_MS, DEFAULT_SUBSCRIPTION_BUFFER, Subscription, AhpClient;
var init_client = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/client.js"() {
    init_errors();
    init_async_queue();
    init_error();
    init_transport();
    DEFAULT_REQUEST_TIMEOUT_MS = 3e4;
    DEFAULT_SUBSCRIPTION_BUFFER = 4096;
    Subscription = class {
      /** Channel URI this subscription is bound to. */
      uri;
      /** @internal */
      inner;
      /** @internal */
      constructor(uri, inner) {
        this.uri = uri;
        this.inner = inner;
      }
      next() {
        return this.inner.next();
      }
      return() {
        return this.inner.return ? this.inner.return() : Promise.resolve({ value: void 0, done: true });
      }
      [Symbol.asyncIterator]() {
        return this;
      }
      /** Terminate this consumer's iterator. Does not unsubscribe server-side. */
      async close() {
        await this.return();
      }
    };
    AhpClient = class {
      transport;
      requestTimeoutMs;
      subscriptionBuffer;
      pending = /* @__PURE__ */ new Map();
      subscriptions = /* @__PURE__ */ new Map();
      allEvents = new AsyncBroadcastQueue();
      stateQueue = new AsyncBroadcastQueue();
      nextRequestId = 1;
      nextClientSeq = 1;
      state = { status: "idle" };
      receiveLoop = null;
      serverRequestHandler = null;
      constructor(transport, config = {}) {
        this.transport = transport;
        const timeout = config.requestTimeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
        this.requestTimeoutMs = timeout > 0 ? timeout : 0;
        const buffer = config.subscriptionBuffer ?? DEFAULT_SUBSCRIPTION_BUFFER;
        this.subscriptionBuffer = buffer >= 1 ? Math.floor(buffer) : 1;
      }
      /** Current connection state. */
      get connectionState() {
        return this.state;
      }
      /** AsyncIterable stream of connection-state transitions. */
      stateChanges() {
        return this.stateQueue.reader();
      }
      /**
       * Top-level fan-in stream of every inbound event from this client.
       *
       * Each call returns a fresh independent iterator. Events are also
       * delivered to the matching per-URI {@link Subscription}.
       */
      events() {
        return this.allEvents.reader();
      }
      /**
       * Install a handler for server-initiated requests
       * ({@link ServerCommandMap}). If no handler is installed, the client
       * responds with a JSON-RPC `MethodNotFound` error so the server does
       * not leak pending requests.
       */
      setServerRequestHandler(handler) {
        this.serverRequestHandler = handler;
      }
      /**
       * Install typed per-method handlers for inbound server-initiated resource
       * requests ({@link ServerCommandMap}). Sugar over
       * {@link AhpClient.setServerRequestHandler} +
       * {@link createResourceRequestHandler}: a method left undefined is reported
       * to the peer as JSON-RPC `MethodNotFound`. Pass `null` to clear the
       * installed handler.
       */
      setResourceRequestHandlers(handlers) {
        this.setServerRequestHandler(handlers ? createResourceRequestHandler(handlers) : null);
      }
      /**
       * Start the inbound receive loop. Idempotent — calling more than once
       * is a no-op.
       */
      connect() {
        if (this.receiveLoop)
          return;
        this.setState({ status: "connected" });
        this.receiveLoop = this.driveTransport();
      }
      /**
       * Gracefully shut down the client. Closes the transport, rejects every
       * pending request with {@link ClientClosedError}, and terminates all
       * subscription and event streams.
       */
      async shutdown() {
        if (this.state.status === "closing" || this.state.status === "closed")
          return;
        this.setState({ status: "closing" });
        this.tearDown({ type: "shutdown" });
        try {
          await this.transport.close();
        } catch {
        }
        if (this.receiveLoop) {
          try {
            await this.receiveLoop;
          } catch {
          }
        }
      }
      // ─── Typed protocol helpers ────────────────────────────────────────────────
      /**
       * Send the `initialize` handshake. MUST be the first request after
       * {@link AhpClient.connect}.
       */
      async initialize(args) {
        const params = {
          channel: "ahp-root://",
          clientId: args.clientId,
          protocolVersions: [...args.protocolVersions],
          ...args.initialSubscriptions && args.initialSubscriptions.length > 0 ? { initialSubscriptions: [...args.initialSubscriptions] } : {},
          ...args.locale !== void 0 ? { locale: args.locale } : {}
        };
        return this.request("initialize", params);
      }
      /** Re-establish a dropped connection. */
      async reconnect(args) {
        const params = {
          channel: "ahp-root://",
          clientId: args.clientId,
          lastSeenServerSeq: args.lastSeenServerSeq,
          subscriptions: [...args.subscriptions]
        };
        return this.request("reconnect", params);
      }
      /**
       * Subscribe to a URI and obtain a {@link Subscription} that streams
       * subsequent events. The returned subscription is registered locally
       * before the `subscribe` request is sent, so no events delivered during
       * the round-trip are missed.
       */
      async subscribe(uri, options = {}) {
        const subscription = this.attachSubscription(uri);
        try {
          const params = {
            channel: uri,
            ...options.delivery ? { delivery: options.delivery } : {},
            ...options.view ? { view: options.view } : {}
          };
          const result = await this.request("subscribe", params);
          return { result, subscription };
        } catch (err) {
          await subscription.close();
          throw err;
        }
      }
      /**
       * Attach a new local {@link Subscription} without sending a `subscribe`
       * request — use this when the URI was included in `initialSubscriptions`
       * during {@link AhpClient.initialize}, or to add an additional consumer
       * for a URI that is already subscribed.
       *
       * Throws {@link ClientClosedError} after the client has been shut down.
       */
      attachSubscription(uri) {
        this.assertOpen();
        let queue = this.subscriptions.get(uri);
        if (!queue) {
          queue = new AsyncBroadcastQueue(this.subscriptionBuffer);
          this.subscriptions.set(uri, queue);
        }
        return new Subscription(uri, queue.reader());
      }
      /**
       * Send an `unsubscribe` notification and drop the local fan-out for
       * this URI. Any active {@link Subscription} iterators terminate.
       *
       * No-op after the client has been shut down.
       */
      async unsubscribe(uri) {
        if (this.isClosed())
          return;
        const queue = this.subscriptions.get(uri);
        if (queue) {
          this.subscriptions.delete(uri);
          queue.close();
        }
        const params = { channel: uri };
        this.notify("unsubscribe", params);
        return Promise.resolve();
      }
      /**
       * Fire a write-ahead `dispatchAction` notification.
       *
       * If `clientSeq` is omitted, the client uses its internal monotonic
       * counter. If supplied, the counter advances to `max(current,
       * clientSeq + 1)` so subsequent auto-assigned sequences remain
       * monotonic.
       *
       * Throws {@link ClientClosedError} after the client has been shut down.
       */
      dispatch(channel, action, clientSeq) {
        this.assertOpen();
        const seq = clientSeq ?? this.nextClientSeq;
        if (clientSeq !== void 0) {
          if (seq + 1 > this.nextClientSeq)
            this.nextClientSeq = seq + 1;
        } else {
          this.nextClientSeq = seq + 1;
        }
        const params = { channel, clientSeq: seq, action };
        this.notify("dispatchAction", params);
        return { clientSeq: seq };
      }
      /**
       * Protocol-level liveness ping. Useful in browsers, which cannot send
       * WebSocket ping frames directly.
       *
       * `ping` is a connection-level command; its channel is always
       * `ahp-root://`.
       */
      async ping() {
        const params = { channel: "ahp-root://" };
        await this.request("ping", params);
      }
      // ─── Resource commands ─────────────────────────────────────────────────────
      //
      // Typed convenience wrappers over the symmetrical `resource*` family. Each
      // targets the root channel (`ahp-root://`), so callers omit `channel`. The
      // reverse direction — a server calling these on the client — is handled via
      // {@link AhpClient.setResourceRequestHandlers}.
      /** Read the content of a resource by URI (`resourceRead`). */
      async resourceRead(params) {
        return this.request("resourceRead", { ...params, channel: "ahp-root://" });
      }
      /** Write content to a file on the receiver's filesystem (`resourceWrite`). */
      async resourceWrite(params) {
        return this.request("resourceWrite", { ...params, channel: "ahp-root://" });
      }
      /** List directory entries at a file URI (`resourceList`). */
      async resourceList(params) {
        return this.request("resourceList", { ...params, channel: "ahp-root://" });
      }
      /** Copy a resource from one URI to another (`resourceCopy`). */
      async resourceCopy(params) {
        return this.request("resourceCopy", { ...params, channel: "ahp-root://" });
      }
      /** Delete a resource at a URI (`resourceDelete`). */
      async resourceDelete(params) {
        return this.request("resourceDelete", { ...params, channel: "ahp-root://" });
      }
      /** Move (rename) a resource from one URI to another (`resourceMove`). */
      async resourceMove(params) {
        return this.request("resourceMove", { ...params, channel: "ahp-root://" });
      }
      /** Resolve a resource — `stat` + `realpath` (`resourceResolve`). */
      async resourceResolve(params) {
        return this.request("resourceResolve", { ...params, channel: "ahp-root://" });
      }
      /** Create a directory with `mkdir -p` semantics (`resourceMkdir`). */
      async resourceMkdir(params) {
        return this.request("resourceMkdir", { ...params, channel: "ahp-root://" });
      }
      /** Request permission to access a resource (`resourceRequest`). */
      async resourceRequest(params) {
        return this.request("resourceRequest", { ...params, channel: "ahp-root://" });
      }
      /**
       * Create a resource watcher (`createResourceWatch`). Returns the
       * `ahp-resource-watch:/<id>` channel URI; {@link AhpClient.subscribe} to it
       * to receive change events, and {@link AhpClient.unsubscribe} to release the
       * watcher.
       */
      async createResourceWatch(params) {
        return this.request("createResourceWatch", {
          ...params,
          channel: "ahp-root://"
        });
      }
      // ─── Completions commands ──────────────────────────────────────────────────
      /**
       * Request inline completion items for a partially-typed input
       * (`completions`), e.g. to power `@`-mention pickers. Unlike the `resource*`
       * wrappers, the caller-supplied `channel` (the chat URI the completion is
       * scoped to) is preserved. Debounce calls to avoid flooding the server on
       * every keystroke.
       */
      async completions(params) {
        return this.request("completions", params);
      }
      /**
       * Query the server for allowed values of a dynamic session config property
       * (`sessionConfigCompletions`). Targets the root channel, so callers omit
       * `channel`.
       */
      async sessionConfigCompletions(params) {
        return this.request("sessionConfigCompletions", {
          ...params,
          channel: "ahp-root://"
        });
      }
      // ─── Lower-level JSON-RPC ──────────────────────────────────────────────────
      /** Send a JSON-RPC request and await its result. */
      async request(method, params) {
        this.assertOpen();
        const id = this.nextRequestId++;
        const msg = {
          jsonrpc: "2.0",
          id,
          method,
          params
        };
        return new Promise((resolve9, reject) => {
          const pending = {
            resolve: (value) => resolve9(value),
            reject,
            method,
            timer: null
          };
          this.pending.set(id, pending);
          if (this.requestTimeoutMs > 0) {
            pending.timer = setTimeout(() => {
              if (this.pending.delete(id)) {
                reject(new RpcTimeoutError(method, this.requestTimeoutMs));
              }
            }, this.requestTimeoutMs);
          }
          this.sendMessage(msg).catch((err) => {
            if (this.pending.delete(id)) {
              if (pending.timer)
                clearTimeout(pending.timer);
              reject(err);
            }
          });
        });
      }
      /**
       * Send a JSON-RPC notification (fire-and-forget).
       *
       * Throws {@link ClientClosedError} after the client has been shut down.
       * Transport-level send failures surface synchronously via
       * {@link AhpClient.connectionState} (the receive loop also tears down
       * on the next inbound failure).
       */
      notify(method, params) {
        this.assertOpen();
        const msg = {
          jsonrpc: "2.0",
          method,
          params
        };
        this.sendMessage(msg).catch(noop);
      }
      // ─── Internals ─────────────────────────────────────────────────────────────
      isClosed() {
        return this.state.status === "closing" || this.state.status === "closed";
      }
      assertOpen() {
        if (this.isClosed())
          throw new ClientClosedError();
      }
      async sendMessage(msg) {
        try {
          await this.transport.send(msg);
        } catch (err) {
          const te = err instanceof TransportError ? err : new TransportError("io", `transport send failed: ${err.message}`, { cause: err });
          this.tearDown({ type: "transport", error: te });
          throw te;
        }
      }
      setState(next) {
        this.state = next;
        this.stateQueue.publish(next);
      }
      tearDown(reason) {
        if (this.state.status === "closed")
          return;
        this.setState({ status: "closed", reason });
        const failure = reason.type === "shutdown" ? new ClientClosedError() : reason.error;
        for (const [id, pending] of this.pending) {
          if (pending.timer)
            clearTimeout(pending.timer);
          try {
            pending.reject(failure);
          } catch {
          }
          this.pending.delete(id);
        }
        for (const queue of this.subscriptions.values())
          queue.close();
        this.subscriptions.clear();
        this.allEvents.close();
        this.stateQueue.close();
      }
      async driveTransport() {
        try {
          while (this.state.status === "connected") {
            const frame = await this.transport.recv();
            if (frame === null) {
              this.tearDown({ type: "transport", error: new TransportError("closed", "transport closed") });
              return;
            }
            this.handleFrame(frame);
          }
        } catch (err) {
          const te = err instanceof TransportError ? err : new TransportError("io", `transport recv failed: ${err.message}`, { cause: err });
          this.tearDown({ type: "transport", error: te });
        }
      }
      handleFrame(frame) {
        let message;
        try {
          switch (frame.kind) {
            case "parsed":
              message = frame.message;
              break;
            case "text":
              message = decodeMessage(frame.text);
              break;
            case "binary": {
              const text = new TextDecoder("utf-8").decode(frame.data);
              message = decodeMessage(text);
              break;
            }
          }
        } catch (err) {
          console.warn(`AhpClient: malformed inbound frame: ${err.message}`);
          return;
        }
        this.dispatchInbound(message);
      }
      dispatchInbound(message) {
        if ("id" in message && "result" in message) {
          const success = message;
          const pending = this.pending.get(success.id);
          if (pending) {
            this.pending.delete(success.id);
            if (pending.timer)
              clearTimeout(pending.timer);
            pending.resolve(success.result);
          }
          return;
        }
        if ("id" in message && "error" in message) {
          const failure = message;
          const pending = this.pending.get(failure.id);
          if (pending) {
            this.pending.delete(failure.id);
            if (pending.timer)
              clearTimeout(pending.timer);
            pending.reject(new RpcError(failure.error.code, failure.error.message, failure.error.data));
          }
          return;
        }
        if ("id" in message && "method" in message) {
          void this.handleServerRequest(message);
          return;
        }
        if ("method" in message) {
          this.handleNotification(message);
          return;
        }
      }
      async handleServerRequest(req) {
        if (this.serverRequestHandler) {
          try {
            const handler = this.serverRequestHandler;
            const result = await handler(req.method, req.params);
            const response2 = {
              jsonrpc: "2.0",
              id: req.id,
              result
            };
            this.sendMessage(response2).catch(noop);
          } catch (err) {
            const code = err instanceof RpcError ? err.code : JsonRpcErrorCodes.InternalError;
            const message = err instanceof Error ? err.message : String(err);
            const data = err instanceof RpcError ? err.data : void 0;
            const response2 = {
              jsonrpc: "2.0",
              id: req.id,
              error: data !== void 0 ? { code, message, data } : { code, message }
            };
            this.sendMessage(response2).catch(noop);
          }
          return;
        }
        const response = {
          jsonrpc: "2.0",
          id: req.id,
          error: {
            code: JsonRpcErrorCodes.MethodNotFound,
            message: `no handler for server method "${req.method}"`
          }
        };
        this.sendMessage(response).catch(noop);
      }
      handleNotification(n) {
        const params = n.params ?? {};
        const channel = params.channel;
        switch (n.method) {
          case "action": {
            const env = n.params;
            this.fanOut(env.channel, { type: "action", params: env });
            break;
          }
          case "root/sessionAdded": {
            const p = n.params;
            this.fanOut(p.channel, { type: "sessionAdded", params: p });
            break;
          }
          case "root/sessionRemoved": {
            const p = n.params;
            this.fanOut(p.channel, { type: "sessionRemoved", params: p });
            break;
          }
          case "root/sessionSummaryChanged": {
            const p = n.params;
            this.fanOut(p.channel, { type: "sessionSummaryChanged", params: p });
            break;
          }
          case "auth/required": {
            const p = n.params;
            this.fanOut(p.channel, { type: "authRequired", params: p });
            break;
          }
          default:
            break;
        }
      }
      fanOut(channel, event) {
        const queue = this.subscriptions.get(channel);
        if (queue)
          queue.publish(event);
        this.allEvents.publish({ channel, event });
      }
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/canvas-state.js
function isCanvasState(state) {
  if (typeof state !== "object" || state === null || !("instanceId" in state) || typeof state.instanceId !== "string" || !("extensionId" in state) || typeof state.extensionId !== "string" || !("canvasId" in state) || typeof state.canvasId !== "string") {
    return false;
  }
  return (state.extensionName === void 0 || typeof state.extensionName === "string") && (state.title === void 0 || typeof state.title === "string") && (state.status === void 0 || typeof state.status === "string") && (state.url === void 0 || typeof state.url === "string");
}
var init_canvas_state = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/canvas-state.js"() {
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/state-mirror.js
var ROOT_URI, AUTOMATIONS_URI, INITIAL_ROOT, INITIAL_AUTOMATION_CATALOG, AhpStateMirror;
var init_state_mirror = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/state-mirror.js"() {
    init_actions();
    init_reducer6();
    init_reducer4();
    init_reducer();
    init_reducer2();
    init_reducer5();
    init_reducer9();
    init_reducer10();
    init_canvas_state();
    ROOT_URI = "ahp-root://";
    AUTOMATIONS_URI = "ahp-automations://";
    INITIAL_ROOT = { agents: [] };
    INITIAL_AUTOMATION_CATALOG = { entries: [] };
    AhpStateMirror = class {
      rootState = INITIAL_ROOT;
      sessionsMap = /* @__PURE__ */ new Map();
      canvasesMap = /* @__PURE__ */ new Map();
      terminalsMap = /* @__PURE__ */ new Map();
      changesetsMap = /* @__PURE__ */ new Map();
      automationCatalogState = INITIAL_AUTOMATION_CATALOG;
      automationsMap = /* @__PURE__ */ new Map();
      automationRunsMap = /* @__PURE__ */ new Map();
      /** Current root state. */
      get root() {
        return this.rootState;
      }
      /** All known sessions keyed by URI. */
      get sessions() {
        return this.sessionsMap;
      }
      /** All known live canvases keyed by their channel URI. */
      get canvases() {
        return this.canvasesMap;
      }
      /** All known terminals keyed by URI. */
      get terminals() {
        return this.terminalsMap;
      }
      /** All known changesets keyed by URI. */
      get changesets() {
        return this.changesetsMap;
      }
      /** Current automation catalogue state. */
      get automationCatalog() {
        return this.automationCatalogState;
      }
      /** All catalogued automations keyed by their stable resource URI. */
      get automations() {
        return this.automationsMap;
      }
      get automationRuns() {
        return this.automationRunsMap;
      }
      /** Look up a session by URI. */
      getSession(uri) {
        return this.sessionsMap.get(uri);
      }
      getCanvas(uri) {
        return this.canvasesMap.get(uri);
      }
      /** Look up a terminal by URI. */
      getTerminal(uri) {
        return this.terminalsMap.get(uri);
      }
      /** Look up a catalogued automation by URI. */
      getAutomation(uri) {
        return this.automationsMap.get(uri);
      }
      /**
       * Apply a server snapshot, replacing the state for the resource the
       * snapshot covers.
       */
      applySnapshot(snapshot) {
        const resource = snapshot.resource;
        if (resource === ROOT_URI) {
          this.rootState = snapshot.state;
          return;
        }
        if (resource.startsWith("ahp-session:")) {
          this.sessionsMap.set(resource, snapshot.state);
          return;
        }
        if (resource.startsWith("ahp-canvas:")) {
          if (!isCanvasState(snapshot.state)) {
            throw new Error("Invalid canvas snapshot state");
          }
          this.canvasesMap.set(resource, snapshot.state);
          return;
        }
        if (resource.startsWith("ahp-terminal:")) {
          this.terminalsMap.set(resource, snapshot.state);
          return;
        }
        if (resource.startsWith("ahp-changeset:")) {
          this.changesetsMap.set(resource, snapshot.state);
          return;
        }
        if (resource === AUTOMATIONS_URI) {
          this.setAutomationCatalog(snapshot.state);
          return;
        }
        if (resource.startsWith("ahp-automation-run:")) {
          this.automationRunsMap.set(resource, snapshot.state);
          return;
        }
      }
      /**
       * Apply a server-pushed {@link ActionEnvelope}, routing through the
       * matching reducer. Unknown channels are ignored.
       *
       * The channel-based routing here discriminates which reducer applies;
       * the action is cast to the appropriate per-channel subset (the
       * `RootAction` / `SessionAction` / `TerminalAction` / `ChangesetAction`
       * unions generated from `@clientDispatchable` annotations) because
       * TypeScript cannot infer that narrowing from the channel string alone.
       */
      apply(envelope) {
        const { channel, action } = envelope;
        if (channel === ROOT_URI) {
          this.rootState = rootReducer(this.rootState, action);
          return;
        }
        if (channel.startsWith("ahp-session:")) {
          const current = this.sessionsMap.get(channel);
          if (!current)
            return;
          this.sessionsMap.set(channel, sessionReducer(current, action));
          return;
        }
        if (channel.startsWith("ahp-canvas:")) {
          const current = this.canvasesMap.get(channel);
          if (current === void 0 || action.type !== ActionType.CanvasStateChanged)
            return;
          this.canvasesMap.set(channel, canvasReducer(current, action));
          return;
        }
        if (channel.startsWith("ahp-terminal:")) {
          const current = this.terminalsMap.get(channel);
          if (!current)
            return;
          this.terminalsMap.set(channel, terminalReducer(current, action));
          return;
        }
        if (channel.startsWith("ahp-changeset:")) {
          const current = this.changesetsMap.get(channel);
          if (!current)
            return;
          this.changesetsMap.set(channel, changesetReducer(current, action));
          return;
        }
        if (channel === AUTOMATIONS_URI) {
          this.setAutomationCatalog(automationReducer(this.automationCatalogState, action));
          return;
        }
        if (channel.startsWith("ahp-automation-run:")) {
          const current = this.automationRunsMap.get(channel);
          if (!current)
            return;
          this.automationRunsMap.set(channel, automationRunReducer(current, action));
          return;
        }
      }
      setAutomationCatalog(state) {
        this.automationCatalogState = state;
        this.automationsMap.clear();
        for (const automation of state.entries) {
          this.automationsMap.set(automation.resource, automation);
        }
      }
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/managed-subscriptions.js
function subscriptionOptionsKey(options) {
  return JSON.stringify({
    maxLatencyMs: options.delivery?.maxLatencyMs ?? null,
    turns: options.view?.turns ?? null
  });
}
function summarizeHolders(holders) {
  const counts = /* @__PURE__ */ new Map();
  for (const owner of holders.values()) {
    counts.set(owner, (counts.get(owner) ?? 0) + 1);
  }
  return [...counts.entries()].map(([owner, count]) => ({ owner, count })).sort((a, b) => b.count - a.count || a.owner.localeCompare(b.owner));
}
var ManagedSubscriptionState, ManagedSubscriptionManager;
var init_managed_subscriptions = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/managed-subscriptions.js"() {
    init_async_queue();
    init_error();
    ManagedSubscriptionState = class {
      uri;
      ready;
      statusValue = "pending";
      resultValue;
      errorValue;
      resolveReady;
      rejectReady;
      constructor(uri) {
        this.uri = uri;
        let resolveReady;
        let rejectReady;
        this.ready = new Promise((resolve9, reject) => {
          resolveReady = resolve9;
          rejectReady = reject;
        });
        void this.ready.catch(() => void 0);
        this.resolveReady = resolveReady;
        this.rejectReady = rejectReady;
      }
      get status() {
        return this.statusValue;
      }
      get result() {
        return this.resultValue;
      }
      get error() {
        return this.errorValue;
      }
      activate(result) {
        if (this.statusValue !== "pending")
          return;
        this.resultValue = result;
        this.statusValue = "active";
        this.resolveReady(result);
      }
      fail(error) {
        if (this.statusValue !== "pending")
          return;
        this.errorValue = error;
        this.statusValue = "failed";
        this.rejectReady(error);
      }
      close(message = "managed subscription closed") {
        if (this.statusValue === "failed" || this.statusValue === "closed")
          return;
        if (this.statusValue === "pending") {
          this.rejectReady(new ClientClosedError(message));
        }
        this.statusValue = "closed";
      }
    };
    ManagedSubscriptionManager = class {
      client;
      eventBuffer;
      entries = /* @__PURE__ */ new Map();
      nextHolderId = 1;
      closed = false;
      constructor(client, options = {}) {
        this.client = client;
        const buffer = options.eventBuffer ?? 4096;
        this.eventBuffer = buffer >= 1 ? Math.floor(buffer) : 1;
      }
      /**
       * Acquire a named lease for `uri`.
       *
       * The first acquire starts the wire request. Later acquires share its result
       * and event fan-out. All holders for a URI must use the same subscribe
       * options; conflicting options throw rather than silently changing the
       * already-active server subscription.
       */
      acquire(uri, owner, options = {}) {
        if (this.closed) {
          throw new ClientClosedError("managed subscription manager closed");
        }
        const optionsKey = subscriptionOptionsKey(options);
        let entry = this.entries.get(uri);
        if (entry && entry.optionsKey !== optionsKey) {
          throw new TypeError(`subscription options for "${uri}" differ from the active subscription`);
        }
        if (!entry) {
          entry = {
            uri,
            optionsKey,
            subscription: new ManagedSubscriptionState(uri),
            events: new AsyncBroadcastQueue(this.eventBuffer),
            holders: /* @__PURE__ */ new Map()
          };
          this.entries.set(uri, entry);
        }
        const lease = this.createLease(entry, owner);
        if (entry.holders.size === 1) {
          void this.start(entry, options);
        }
        return lease;
      }
      /** Current managed subscription without acquiring another lease. */
      get(uri) {
        return this.entries.get(uri)?.subscription;
      }
      /** Active subscription URIs, in deterministic lexical order. */
      currentSubscriptionUris() {
        return [...this.entries.keys()].sort();
      }
      /** Read-only lifecycle and ownership snapshot for diagnostics. */
      activeSubscriptions() {
        return [...this.entries.values()].sort((a, b) => a.uri.localeCompare(b.uri)).map((entry) => ({
          uri: entry.uri,
          status: entry.subscription.status,
          refCount: entry.holders.size,
          holders: summarizeHolders(entry.holders)
        }));
      }
      /** Release every managed subscription and reject future acquires. */
      async close() {
        if (this.closed)
          return;
        this.closed = true;
        const entries = [...this.entries.values()];
        this.entries.clear();
        await Promise.all(entries.map((entry) => this.disposeEntry(entry, "managed subscription manager closed")));
      }
      createLease(entry, owner) {
        const holderId = this.nextHolderId++;
        entry.holders.set(holderId, owner);
        const events = entry.events.reader();
        let released = false;
        return {
          subscription: entry.subscription,
          events,
          [Symbol.dispose]: () => {
            if (released)
              return;
            released = true;
            void events.return?.();
            entry.holders.delete(holderId);
            if (entry.holders.size === 0 && this.entries.get(entry.uri) === entry) {
              this.entries.delete(entry.uri);
              void this.disposeEntry(entry, "managed subscription released before ready");
            }
          }
        };
      }
      async start(entry, options) {
        try {
          const { result, subscription } = await this.client.subscribe(entry.uri, options);
          if (this.entries.get(entry.uri) !== entry || entry.holders.size === 0) {
            await subscription.close();
            return;
          }
          entry.source = subscription;
          entry.subscription.activate(result);
          void this.pump(entry, subscription);
        } catch (cause) {
          if (this.entries.get(entry.uri) !== entry)
            return;
          this.entries.delete(entry.uri);
          const error = cause instanceof Error ? cause : new Error(String(cause));
          entry.subscription.fail(error);
          entry.events.close();
          await this.client.unsubscribe(entry.uri);
        }
      }
      async pump(entry, source) {
        try {
          for await (const event of source) {
            entry.events.publish(event);
          }
        } finally {
          if (this.entries.get(entry.uri) === entry) {
            this.entries.delete(entry.uri);
            entry.subscription.close("managed subscription event stream closed");
            entry.events.close();
          }
        }
      }
      async disposeEntry(entry, message) {
        entry.subscription.close(message);
        entry.events.close();
        await this.client.unsubscribe(entry.uri);
        await entry.source?.close();
      }
    };
  }
});

// node_modules/@microsoft/agent-host-protocol/dist/client/index.js
var client_exports = {};
__export(client_exports, {
  AhpClient: () => AhpClient,
  AhpClientError: () => AhpClientError,
  AhpStateMirror: () => AhpStateMirror,
  ClientClosedError: () => ClientClosedError,
  InMemoryTransport: () => InMemoryTransport,
  ManagedSubscriptionManager: () => ManagedSubscriptionManager,
  RpcError: () => RpcError,
  RpcTimeoutError: () => RpcTimeoutError,
  Subscription: () => Subscription,
  TransportError: () => TransportError,
  createResourceRequestHandler: () => createResourceRequestHandler
});
var init_client2 = __esm({
  "node_modules/@microsoft/agent-host-protocol/dist/client/index.js"() {
    init_client();
    init_client();
    init_error();
    init_transport();
    init_state_mirror();
    init_managed_subscriptions();
  }
});

// node_modules/ws/lib/constants.js
var require_constants = __commonJS({
  "node_modules/ws/lib/constants.js"(exports2, module2) {
    "use strict";
    var BINARY_TYPES = ["nodebuffer", "arraybuffer", "fragments"];
    var hasBlob = typeof Blob !== "undefined";
    if (hasBlob) BINARY_TYPES.push("blob");
    module2.exports = {
      BINARY_TYPES,
      CLOSE_TIMEOUT: 3e4,
      EMPTY_BUFFER: Buffer.alloc(0),
      GUID: "258EAFA5-E914-47DA-95CA-C5AB0DC85B11",
      hasBlob,
      kForOnEventAttribute: Symbol("kIsForOnEventAttribute"),
      kListener: Symbol("kListener"),
      kStatusCode: Symbol("status-code"),
      kWebSocket: Symbol("websocket"),
      NOOP: () => {
      }
    };
  }
});

// node_modules/ws/lib/buffer-util.js
var require_buffer_util = __commonJS({
  "node_modules/ws/lib/buffer-util.js"(exports2, module2) {
    "use strict";
    var { EMPTY_BUFFER } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    function concat(list, totalLength) {
      if (list.length === 0) return EMPTY_BUFFER;
      if (list.length === 1) return list[0];
      const target = Buffer.allocUnsafe(totalLength);
      let offset = 0;
      for (let i = 0; i < list.length; i++) {
        const buf = list[i];
        target.set(buf, offset);
        offset += buf.length;
      }
      if (offset < totalLength) {
        return new FastBuffer(target.buffer, target.byteOffset, offset);
      }
      return target;
    }
    function _mask(source, mask, output, offset, length) {
      for (let i = 0; i < length; i++) {
        output[offset + i] = source[i] ^ mask[i & 3];
      }
    }
    function _unmask(buffer, mask) {
      for (let i = 0; i < buffer.length; i++) {
        buffer[i] ^= mask[i & 3];
      }
    }
    function toArrayBuffer(buf) {
      if (buf.length === buf.buffer.byteLength) {
        return buf.buffer;
      }
      return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.length);
    }
    function toBuffer(data) {
      toBuffer.readOnly = true;
      if (Buffer.isBuffer(data)) return data;
      let buf;
      if (data instanceof ArrayBuffer) {
        buf = new FastBuffer(data);
      } else if (ArrayBuffer.isView(data)) {
        buf = new FastBuffer(data.buffer, data.byteOffset, data.byteLength);
      } else {
        buf = Buffer.from(data);
        toBuffer.readOnly = false;
      }
      return buf;
    }
    module2.exports = {
      concat,
      mask: _mask,
      toArrayBuffer,
      toBuffer,
      unmask: _unmask
    };
    if (!process.env.WS_NO_BUFFER_UTIL) {
      try {
        const bufferUtil = require("bufferutil");
        module2.exports.mask = function(source, mask, output, offset, length) {
          if (length < 48) _mask(source, mask, output, offset, length);
          else bufferUtil.mask(source, mask, output, offset, length);
        };
        module2.exports.unmask = function(buffer, mask) {
          if (buffer.length < 32) _unmask(buffer, mask);
          else bufferUtil.unmask(buffer, mask);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/limiter.js
var require_limiter = __commonJS({
  "node_modules/ws/lib/limiter.js"(exports2, module2) {
    "use strict";
    var kDone = Symbol("kDone");
    var kRun = Symbol("kRun");
    var Limiter = class {
      /**
       * Creates a new `Limiter`.
       *
       * @param {Number} [concurrency=Infinity] The maximum number of jobs allowed
       *     to run concurrently
       */
      constructor(concurrency) {
        this[kDone] = () => {
          this.pending--;
          this[kRun]();
        };
        this.concurrency = concurrency || Infinity;
        this.jobs = [];
        this.pending = 0;
      }
      /**
       * Adds a job to the queue.
       *
       * @param {Function} job The job to run
       * @public
       */
      add(job) {
        this.jobs.push(job);
        this[kRun]();
      }
      /**
       * Removes a job from the queue and runs it if possible.
       *
       * @private
       */
      [kRun]() {
        if (this.pending === this.concurrency) return;
        if (this.jobs.length) {
          const job = this.jobs.shift();
          this.pending++;
          job(this[kDone]);
        }
      }
    };
    module2.exports = Limiter;
  }
});

// node_modules/ws/lib/permessage-deflate.js
var require_permessage_deflate = __commonJS({
  "node_modules/ws/lib/permessage-deflate.js"(exports2, module2) {
    "use strict";
    var zlib = require("zlib");
    var bufferUtil = require_buffer_util();
    var Limiter = require_limiter();
    var { kStatusCode } = require_constants();
    var FastBuffer = Buffer[Symbol.species];
    var TRAILER = Buffer.from([0, 0, 255, 255]);
    var kPerMessageDeflate = Symbol("permessage-deflate");
    var kTotalLength = Symbol("total-length");
    var kCallback = Symbol("callback");
    var kBuffers = Symbol("buffers");
    var kError = Symbol("error");
    var zlibLimiter;
    var PerMessageDeflate2 = class {
      /**
       * Creates a PerMessageDeflate instance.
       *
       * @param {Object} [options] Configuration options
       * @param {(Boolean|Number)} [options.clientMaxWindowBits] Advertise support
       *     for, or request, a custom client window size
       * @param {Boolean} [options.clientNoContextTakeover=false] Advertise/
       *     acknowledge disabling of client context takeover
       * @param {Number} [options.concurrencyLimit=10] The number of concurrent
       *     calls to zlib
       * @param {Boolean} [options.isServer=false] Create the instance in either
       *     server or client mode
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {(Boolean|Number)} [options.serverMaxWindowBits] Request/confirm the
       *     use of a custom server window size
       * @param {Boolean} [options.serverNoContextTakeover=false] Request/accept
       *     disabling of server context takeover
       * @param {Number} [options.threshold=1024] Size (in bytes) below which
       *     messages should not be compressed if context takeover is disabled
       * @param {Object} [options.zlibDeflateOptions] Options to pass to zlib on
       *     deflate
       * @param {Object} [options.zlibInflateOptions] Options to pass to zlib on
       *     inflate
       */
      constructor(options) {
        this._options = options || {};
        this._threshold = this._options.threshold !== void 0 ? this._options.threshold : 1024;
        this._maxPayload = this._options.maxPayload | 0;
        this._isServer = !!this._options.isServer;
        this._deflate = null;
        this._inflate = null;
        this.params = null;
        if (!zlibLimiter) {
          const concurrency = this._options.concurrencyLimit !== void 0 ? this._options.concurrencyLimit : 10;
          zlibLimiter = new Limiter(concurrency);
        }
      }
      /**
       * @type {String}
       */
      static get extensionName() {
        return "permessage-deflate";
      }
      /**
       * Create an extension negotiation offer.
       *
       * @return {Object} Extension parameters
       * @public
       */
      offer() {
        const params = {};
        if (this._options.serverNoContextTakeover) {
          params.server_no_context_takeover = true;
        }
        if (this._options.clientNoContextTakeover) {
          params.client_no_context_takeover = true;
        }
        if (this._options.serverMaxWindowBits) {
          params.server_max_window_bits = this._options.serverMaxWindowBits;
        }
        if (this._options.clientMaxWindowBits) {
          params.client_max_window_bits = this._options.clientMaxWindowBits;
        } else if (this._options.clientMaxWindowBits == null) {
          params.client_max_window_bits = true;
        }
        return params;
      }
      /**
       * Accept an extension negotiation offer/response.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Object} Accepted configuration
       * @public
       */
      accept(configurations) {
        configurations = this.normalizeParams(configurations);
        this.params = this._isServer ? this.acceptAsServer(configurations) : this.acceptAsClient(configurations);
        return this.params;
      }
      /**
       * Releases all resources used by the extension.
       *
       * @public
       */
      cleanup() {
        if (this._inflate) {
          this._inflate.close();
          this._inflate = null;
        }
        if (this._deflate) {
          const callback = this._deflate[kCallback];
          this._deflate.close();
          this._deflate = null;
          if (callback) {
            callback(
              new Error(
                "The deflate stream was closed while data was being processed"
              )
            );
          }
        }
      }
      /**
       *  Accept an extension negotiation offer.
       *
       * @param {Array} offers The extension negotiation offers
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsServer(offers) {
        const opts = this._options;
        const accepted = offers.find((params) => {
          if (opts.serverNoContextTakeover === false && params.server_no_context_takeover || params.server_max_window_bits && (opts.serverMaxWindowBits === false || typeof opts.serverMaxWindowBits === "number" && opts.serverMaxWindowBits > params.server_max_window_bits) || typeof opts.clientMaxWindowBits === "number" && (typeof params.client_max_window_bits === "number" ? opts.clientMaxWindowBits > params.client_max_window_bits : !params.client_max_window_bits)) {
            return false;
          }
          return true;
        });
        if (!accepted) {
          throw new Error("None of the extension offers can be accepted");
        }
        if (opts.serverNoContextTakeover) {
          accepted.server_no_context_takeover = true;
        }
        if (opts.clientNoContextTakeover) {
          accepted.client_no_context_takeover = true;
        }
        if (typeof opts.serverMaxWindowBits === "number") {
          accepted.server_max_window_bits = opts.serverMaxWindowBits;
        }
        if (typeof opts.clientMaxWindowBits === "number") {
          accepted.client_max_window_bits = opts.clientMaxWindowBits;
        } else if (accepted.client_max_window_bits === true || opts.clientMaxWindowBits === false) {
          delete accepted.client_max_window_bits;
        }
        return accepted;
      }
      /**
       * Accept the extension negotiation response.
       *
       * @param {Array} response The extension negotiation response
       * @return {Object} Accepted configuration
       * @private
       */
      acceptAsClient(response) {
        const params = response[0];
        if (this._options.clientNoContextTakeover === false && params.client_no_context_takeover) {
          throw new Error('Unexpected parameter "client_no_context_takeover"');
        }
        if (!params.client_max_window_bits) {
          if (typeof this._options.clientMaxWindowBits === "number") {
            params.client_max_window_bits = this._options.clientMaxWindowBits;
          }
        } else if (this._options.clientMaxWindowBits === false || typeof this._options.clientMaxWindowBits === "number" && params.client_max_window_bits > this._options.clientMaxWindowBits) {
          throw new Error(
            'Unexpected or invalid parameter "client_max_window_bits"'
          );
        }
        return params;
      }
      /**
       * Normalize parameters.
       *
       * @param {Array} configurations The extension negotiation offers/reponse
       * @return {Array} The offers/response with normalized parameters
       * @private
       */
      normalizeParams(configurations) {
        configurations.forEach((params) => {
          Object.keys(params).forEach((key) => {
            let value = params[key];
            if (value.length > 1) {
              throw new Error(`Parameter "${key}" must have only a single value`);
            }
            value = value[0];
            if (key === "client_max_window_bits") {
              if (value !== true) {
                const num = +value;
                if (!Number.isInteger(num) || num < 8 || num > 15) {
                  throw new TypeError(
                    `Invalid value for parameter "${key}": ${value}`
                  );
                }
                value = num;
              } else if (!this._isServer) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else if (key === "server_max_window_bits") {
              const num = +value;
              if (!Number.isInteger(num) || num < 8 || num > 15) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
              value = num;
            } else if (key === "client_no_context_takeover" || key === "server_no_context_takeover") {
              if (value !== true) {
                throw new TypeError(
                  `Invalid value for parameter "${key}": ${value}`
                );
              }
            } else {
              throw new Error(`Unknown parameter "${key}"`);
            }
            params[key] = value;
          });
        });
        return configurations;
      }
      /**
       * Decompress data. Concurrency limited.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      decompress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._decompress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Compress data. Concurrency limited.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @public
       */
      compress(data, fin, callback) {
        zlibLimiter.add((done) => {
          this._compress(data, fin, (err, result) => {
            done();
            callback(err, result);
          });
        });
      }
      /**
       * Decompress data.
       *
       * @param {Buffer} data Compressed data
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _decompress(data, fin, callback) {
        const endpoint = this._isServer ? "client" : "server";
        if (!this._inflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._inflate = zlib.createInflateRaw({
            ...this._options.zlibInflateOptions,
            windowBits
          });
          this._inflate[kPerMessageDeflate] = this;
          this._inflate[kTotalLength] = 0;
          this._inflate[kBuffers] = [];
          this._inflate.on("error", inflateOnError);
          this._inflate.on("data", inflateOnData);
        }
        this._inflate[kCallback] = callback;
        this._inflate.write(data);
        if (fin) this._inflate.write(TRAILER);
        this._inflate.flush(() => {
          const err = this._inflate[kError];
          if (err) {
            this._inflate.close();
            this._inflate = null;
            callback(err);
            return;
          }
          const data2 = bufferUtil.concat(
            this._inflate[kBuffers],
            this._inflate[kTotalLength]
          );
          if (this._inflate._readableState.endEmitted) {
            this._inflate.close();
            this._inflate = null;
          } else {
            this._inflate[kTotalLength] = 0;
            this._inflate[kBuffers] = [];
            if (fin && this.params[`${endpoint}_no_context_takeover`]) {
              this._inflate.reset();
            }
          }
          callback(null, data2);
        });
      }
      /**
       * Compress data.
       *
       * @param {(Buffer|String)} data Data to compress
       * @param {Boolean} fin Specifies whether or not this is the last fragment
       * @param {Function} callback Callback
       * @private
       */
      _compress(data, fin, callback) {
        const endpoint = this._isServer ? "server" : "client";
        if (!this._deflate) {
          const key = `${endpoint}_max_window_bits`;
          const windowBits = typeof this.params[key] !== "number" ? zlib.Z_DEFAULT_WINDOWBITS : this.params[key];
          this._deflate = zlib.createDeflateRaw({
            ...this._options.zlibDeflateOptions,
            windowBits
          });
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          this._deflate.on("data", deflateOnData);
        }
        this._deflate[kCallback] = callback;
        this._deflate.write(data);
        this._deflate.flush(zlib.Z_SYNC_FLUSH, () => {
          if (!this._deflate) {
            return;
          }
          let data2 = bufferUtil.concat(
            this._deflate[kBuffers],
            this._deflate[kTotalLength]
          );
          if (fin) {
            data2 = new FastBuffer(data2.buffer, data2.byteOffset, data2.length - 4);
          }
          this._deflate[kCallback] = null;
          this._deflate[kTotalLength] = 0;
          this._deflate[kBuffers] = [];
          if (fin && this.params[`${endpoint}_no_context_takeover`]) {
            this._deflate.reset();
          }
          callback(null, data2);
        });
      }
    };
    module2.exports = PerMessageDeflate2;
    function deflateOnData(chunk) {
      this[kBuffers].push(chunk);
      this[kTotalLength] += chunk.length;
    }
    function inflateOnData(chunk) {
      this[kTotalLength] += chunk.length;
      if (this[kPerMessageDeflate]._maxPayload < 1 || this[kTotalLength] <= this[kPerMessageDeflate]._maxPayload) {
        this[kBuffers].push(chunk);
        return;
      }
      this[kError] = new RangeError("Max payload size exceeded");
      this[kError].code = "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH";
      this[kError][kStatusCode] = 1009;
      this.removeListener("data", inflateOnData);
      this.reset();
    }
    function inflateOnError(err) {
      this[kPerMessageDeflate]._inflate = null;
      if (this[kError]) {
        this[kCallback](this[kError]);
        return;
      }
      err[kStatusCode] = 1007;
      this[kCallback](err);
    }
  }
});

// node_modules/ws/lib/validation.js
var require_validation = __commonJS({
  "node_modules/ws/lib/validation.js"(exports2, module2) {
    "use strict";
    var { isUtf8 } = require("buffer");
    var { hasBlob } = require_constants();
    var tokenChars = [
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 0 - 15
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      0,
      // 16 - 31
      0,
      1,
      0,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      1,
      1,
      0,
      1,
      1,
      0,
      // 32 - 47
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      0,
      0,
      0,
      // 48 - 63
      0,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 64 - 79
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      0,
      0,
      1,
      1,
      // 80 - 95
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      // 96 - 111
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      1,
      0,
      1,
      0,
      1,
      0
      // 112 - 127
    ];
    function isValidStatusCode(code) {
      return code >= 1e3 && code <= 1014 && code !== 1004 && code !== 1005 && code !== 1006 || code >= 3e3 && code <= 4999;
    }
    function _isValidUTF8(buf) {
      const len = buf.length;
      let i = 0;
      while (i < len) {
        if ((buf[i] & 128) === 0) {
          i++;
        } else if ((buf[i] & 224) === 192) {
          if (i + 1 === len || (buf[i + 1] & 192) !== 128 || (buf[i] & 254) === 192) {
            return false;
          }
          i += 2;
        } else if ((buf[i] & 240) === 224) {
          if (i + 2 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || buf[i] === 224 && (buf[i + 1] & 224) === 128 || // Overlong
          buf[i] === 237 && (buf[i + 1] & 224) === 160) {
            return false;
          }
          i += 3;
        } else if ((buf[i] & 248) === 240) {
          if (i + 3 >= len || (buf[i + 1] & 192) !== 128 || (buf[i + 2] & 192) !== 128 || (buf[i + 3] & 192) !== 128 || buf[i] === 240 && (buf[i + 1] & 240) === 128 || // Overlong
          buf[i] === 244 && buf[i + 1] > 143 || buf[i] > 244) {
            return false;
          }
          i += 4;
        } else {
          return false;
        }
      }
      return true;
    }
    function isBlob(value) {
      return hasBlob && typeof value === "object" && typeof value.arrayBuffer === "function" && typeof value.type === "string" && typeof value.stream === "function" && (value[Symbol.toStringTag] === "Blob" || value[Symbol.toStringTag] === "File");
    }
    module2.exports = {
      isBlob,
      isValidStatusCode,
      isValidUTF8: _isValidUTF8,
      tokenChars
    };
    if (isUtf8) {
      module2.exports.isValidUTF8 = function(buf) {
        return buf.length < 24 ? _isValidUTF8(buf) : isUtf8(buf);
      };
    } else if (!process.env.WS_NO_UTF_8_VALIDATE) {
      try {
        const isValidUTF8 = require("utf-8-validate");
        module2.exports.isValidUTF8 = function(buf) {
          return buf.length < 32 ? _isValidUTF8(buf) : isValidUTF8(buf);
        };
      } catch (e) {
      }
    }
  }
});

// node_modules/ws/lib/receiver.js
var require_receiver = __commonJS({
  "node_modules/ws/lib/receiver.js"(exports2, module2) {
    "use strict";
    var { Writable } = require("stream");
    var PerMessageDeflate2 = require_permessage_deflate();
    var {
      BINARY_TYPES,
      EMPTY_BUFFER,
      kStatusCode,
      kWebSocket
    } = require_constants();
    var { concat, toArrayBuffer, unmask } = require_buffer_util();
    var { isValidStatusCode, isValidUTF8 } = require_validation();
    var FastBuffer = Buffer[Symbol.species];
    var GET_INFO = 0;
    var GET_PAYLOAD_LENGTH_16 = 1;
    var GET_PAYLOAD_LENGTH_64 = 2;
    var GET_MASK = 3;
    var GET_DATA = 4;
    var INFLATING = 5;
    var DEFER_EVENT = 6;
    var Receiver2 = class extends Writable {
      /**
       * Creates a Receiver instance.
       *
       * @param {Object} [options] Options object
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {String} [options.binaryType=nodebuffer] The type for binary data
       * @param {Object} [options.extensions] An object containing the negotiated
       *     extensions
       * @param {Boolean} [options.isServer=false] Specifies whether to operate in
       *     client or server mode
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message length
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       */
      constructor(options = {}) {
        super();
        this._allowSynchronousEvents = options.allowSynchronousEvents !== void 0 ? options.allowSynchronousEvents : true;
        this._binaryType = options.binaryType || BINARY_TYPES[0];
        this._extensions = options.extensions || {};
        this._isServer = !!options.isServer;
        this._maxBufferedChunks = options.maxBufferedChunks | 0;
        this._maxFragments = options.maxFragments | 0;
        this._maxPayload = options.maxPayload | 0;
        this._skipUTF8Validation = !!options.skipUTF8Validation;
        this[kWebSocket] = void 0;
        this._bufferedBytes = 0;
        this._buffers = [];
        this._compressed = false;
        this._payloadLength = 0;
        this._mask = void 0;
        this._fragmented = 0;
        this._masked = false;
        this._fin = false;
        this._opcode = 0;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._numFragments = 0;
        this._fragments = [];
        this._errored = false;
        this._loop = false;
        this._state = GET_INFO;
      }
      /**
       * Implements `Writable.prototype._write()`.
       *
       * @param {Buffer} chunk The chunk of data to write
       * @param {String} encoding The character encoding of `chunk`
       * @param {Function} cb Callback
       * @private
       */
      _write(chunk, encoding, cb) {
        if (this._opcode === 8 && this._state == GET_INFO) return cb();
        if (this._maxBufferedChunks > 0 && this._buffers.length >= this._maxBufferedChunks) {
          cb(
            this.createError(
              RangeError,
              "Too many buffered chunks",
              false,
              1008,
              "WS_ERR_TOO_MANY_BUFFERED_PARTS"
            )
          );
          return;
        }
        this._bufferedBytes += chunk.length;
        this._buffers.push(chunk);
        this.startLoop(cb);
      }
      /**
       * Consumes `n` bytes from the buffered data.
       *
       * @param {Number} n The number of bytes to consume
       * @return {Buffer} The consumed bytes
       * @private
       */
      consume(n) {
        this._bufferedBytes -= n;
        if (n === this._buffers[0].length) return this._buffers.shift();
        if (n < this._buffers[0].length) {
          const buf = this._buffers[0];
          this._buffers[0] = new FastBuffer(
            buf.buffer,
            buf.byteOffset + n,
            buf.length - n
          );
          return new FastBuffer(buf.buffer, buf.byteOffset, n);
        }
        const dst = Buffer.allocUnsafe(n);
        do {
          const buf = this._buffers[0];
          const offset = dst.length - n;
          if (n >= buf.length) {
            dst.set(this._buffers.shift(), offset);
          } else {
            dst.set(new Uint8Array(buf.buffer, buf.byteOffset, n), offset);
            this._buffers[0] = new FastBuffer(
              buf.buffer,
              buf.byteOffset + n,
              buf.length - n
            );
          }
          n -= buf.length;
        } while (n > 0);
        return dst;
      }
      /**
       * Starts the parsing loop.
       *
       * @param {Function} cb Callback
       * @private
       */
      startLoop(cb) {
        this._loop = true;
        do {
          switch (this._state) {
            case GET_INFO:
              this.getInfo(cb);
              break;
            case GET_PAYLOAD_LENGTH_16:
              this.getPayloadLength16(cb);
              break;
            case GET_PAYLOAD_LENGTH_64:
              this.getPayloadLength64(cb);
              break;
            case GET_MASK:
              this.getMask();
              break;
            case GET_DATA:
              this.getData(cb);
              break;
            case INFLATING:
            case DEFER_EVENT:
              this._loop = false;
              return;
          }
        } while (this._loop);
        if (!this._errored) cb();
      }
      /**
       * Reads the first two bytes of a frame.
       *
       * @param {Function} cb Callback
       * @private
       */
      getInfo(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        const buf = this.consume(2);
        if ((buf[0] & 48) !== 0) {
          const error = this.createError(
            RangeError,
            "RSV2 and RSV3 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_2_3"
          );
          cb(error);
          return;
        }
        const compressed = (buf[0] & 64) === 64;
        if (compressed && !this._extensions[PerMessageDeflate2.extensionName]) {
          const error = this.createError(
            RangeError,
            "RSV1 must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_RSV_1"
          );
          cb(error);
          return;
        }
        this._fin = (buf[0] & 128) === 128;
        this._opcode = buf[0] & 15;
        this._payloadLength = buf[1] & 127;
        if (this._opcode === 0) {
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (!this._fragmented) {
            const error = this.createError(
              RangeError,
              "invalid opcode 0",
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._opcode = this._fragmented;
        } else if (this._opcode === 1 || this._opcode === 2) {
          if (this._fragmented) {
            const error = this.createError(
              RangeError,
              `invalid opcode ${this._opcode}`,
              true,
              1002,
              "WS_ERR_INVALID_OPCODE"
            );
            cb(error);
            return;
          }
          this._compressed = compressed;
        } else if (this._opcode > 7 && this._opcode < 11) {
          if (!this._fin) {
            const error = this.createError(
              RangeError,
              "FIN must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_FIN"
            );
            cb(error);
            return;
          }
          if (compressed) {
            const error = this.createError(
              RangeError,
              "RSV1 must be clear",
              true,
              1002,
              "WS_ERR_UNEXPECTED_RSV_1"
            );
            cb(error);
            return;
          }
          if (this._payloadLength > 125 || this._opcode === 8 && this._payloadLength === 1) {
            const error = this.createError(
              RangeError,
              `invalid payload length ${this._payloadLength}`,
              true,
              1002,
              "WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH"
            );
            cb(error);
            return;
          }
        } else {
          const error = this.createError(
            RangeError,
            `invalid opcode ${this._opcode}`,
            true,
            1002,
            "WS_ERR_INVALID_OPCODE"
          );
          cb(error);
          return;
        }
        if (!this._fin && !this._fragmented) this._fragmented = this._opcode;
        this._masked = (buf[1] & 128) === 128;
        if (this._isServer) {
          if (!this._masked) {
            const error = this.createError(
              RangeError,
              "MASK must be set",
              true,
              1002,
              "WS_ERR_EXPECTED_MASK"
            );
            cb(error);
            return;
          }
        } else if (this._masked) {
          const error = this.createError(
            RangeError,
            "MASK must be clear",
            true,
            1002,
            "WS_ERR_UNEXPECTED_MASK"
          );
          cb(error);
          return;
        }
        if (this._payloadLength === 126) this._state = GET_PAYLOAD_LENGTH_16;
        else if (this._payloadLength === 127) this._state = GET_PAYLOAD_LENGTH_64;
        else this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+16).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength16(cb) {
        if (this._bufferedBytes < 2) {
          this._loop = false;
          return;
        }
        this._payloadLength = this.consume(2).readUInt16BE(0);
        this.haveLength(cb);
      }
      /**
       * Gets extended payload length (7+64).
       *
       * @param {Function} cb Callback
       * @private
       */
      getPayloadLength64(cb) {
        if (this._bufferedBytes < 8) {
          this._loop = false;
          return;
        }
        const buf = this.consume(8);
        const num = buf.readUInt32BE(0);
        if (num > Math.pow(2, 53 - 32) - 1) {
          const error = this.createError(
            RangeError,
            "Unsupported WebSocket frame: payload length > 2^53 - 1",
            false,
            1009,
            "WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH"
          );
          cb(error);
          return;
        }
        this._payloadLength = num * Math.pow(2, 32) + buf.readUInt32BE(4);
        this.haveLength(cb);
      }
      /**
       * Payload length has been read.
       *
       * @param {Function} cb Callback
       * @private
       */
      haveLength(cb) {
        if (this._payloadLength && this._opcode < 8) {
          this._totalPayloadLength += this._payloadLength;
          if (this._totalPayloadLength > this._maxPayload && this._maxPayload > 0) {
            const error = this.createError(
              RangeError,
              "Max payload size exceeded",
              false,
              1009,
              "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
            );
            cb(error);
            return;
          }
        }
        if (this._masked) this._state = GET_MASK;
        else this._state = GET_DATA;
      }
      /**
       * Reads mask bytes.
       *
       * @private
       */
      getMask() {
        if (this._bufferedBytes < 4) {
          this._loop = false;
          return;
        }
        this._mask = this.consume(4);
        this._state = GET_DATA;
      }
      /**
       * Reads data bytes.
       *
       * @param {Function} cb Callback
       * @private
       */
      getData(cb) {
        let data = EMPTY_BUFFER;
        if (this._payloadLength) {
          if (this._bufferedBytes < this._payloadLength) {
            this._loop = false;
            return;
          }
          data = this.consume(this._payloadLength);
          if (this._masked && (this._mask[0] | this._mask[1] | this._mask[2] | this._mask[3]) !== 0) {
            unmask(data, this._mask);
          }
        }
        if (this._opcode > 7) {
          this.controlMessage(data, cb);
          return;
        }
        if (this._maxFragments > 0 && ++this._numFragments > this._maxFragments) {
          const error = this.createError(
            RangeError,
            "Too many message fragments",
            false,
            1008,
            "WS_ERR_TOO_MANY_BUFFERED_PARTS"
          );
          cb(error);
          return;
        }
        if (this._compressed) {
          this._state = INFLATING;
          this.decompress(data, cb);
          return;
        }
        if (data.length) {
          this._messageLength = this._totalPayloadLength;
          this._fragments.push(data);
        }
        this.dataMessage(cb);
      }
      /**
       * Decompresses data.
       *
       * @param {Buffer} data Compressed data
       * @param {Function} cb Callback
       * @private
       */
      decompress(data, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        perMessageDeflate.decompress(data, this._fin, (err, buf) => {
          if (err) return cb(err);
          if (buf.length) {
            this._messageLength += buf.length;
            if (this._messageLength > this._maxPayload && this._maxPayload > 0) {
              const error = this.createError(
                RangeError,
                "Max payload size exceeded",
                false,
                1009,
                "WS_ERR_UNSUPPORTED_MESSAGE_LENGTH"
              );
              cb(error);
              return;
            }
            this._fragments.push(buf);
          }
          this.dataMessage(cb);
          if (this._state === GET_INFO) this.startLoop(cb);
        });
      }
      /**
       * Handles a data message.
       *
       * @param {Function} cb Callback
       * @private
       */
      dataMessage(cb) {
        if (!this._fin) {
          this._state = GET_INFO;
          return;
        }
        const messageLength = this._messageLength;
        const fragments = this._fragments;
        this._totalPayloadLength = 0;
        this._messageLength = 0;
        this._fragmented = 0;
        this._numFragments = 0;
        this._fragments = [];
        if (this._opcode === 2) {
          let data;
          if (this._binaryType === "nodebuffer") {
            data = concat(fragments, messageLength);
          } else if (this._binaryType === "arraybuffer") {
            data = toArrayBuffer(concat(fragments, messageLength));
          } else if (this._binaryType === "blob") {
            data = new Blob(fragments);
          } else {
            data = fragments;
          }
          if (this._allowSynchronousEvents) {
            this.emit("message", data, true);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", data, true);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        } else {
          const buf = concat(fragments, messageLength);
          if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
            const error = this.createError(
              Error,
              "invalid UTF-8 sequence",
              true,
              1007,
              "WS_ERR_INVALID_UTF8"
            );
            cb(error);
            return;
          }
          if (this._state === INFLATING || this._allowSynchronousEvents) {
            this.emit("message", buf, false);
            this._state = GET_INFO;
          } else {
            this._state = DEFER_EVENT;
            setImmediate(() => {
              this.emit("message", buf, false);
              this._state = GET_INFO;
              this.startLoop(cb);
            });
          }
        }
      }
      /**
       * Handles a control message.
       *
       * @param {Buffer} data Data to handle
       * @return {(Error|RangeError|undefined)} A possible error
       * @private
       */
      controlMessage(data, cb) {
        if (this._opcode === 8) {
          if (data.length === 0) {
            this._loop = false;
            this.emit("conclude", 1005, EMPTY_BUFFER);
            this.end();
          } else {
            const code = data.readUInt16BE(0);
            if (!isValidStatusCode(code)) {
              const error = this.createError(
                RangeError,
                `invalid status code ${code}`,
                true,
                1002,
                "WS_ERR_INVALID_CLOSE_CODE"
              );
              cb(error);
              return;
            }
            const buf = new FastBuffer(
              data.buffer,
              data.byteOffset + 2,
              data.length - 2
            );
            if (!this._skipUTF8Validation && !isValidUTF8(buf)) {
              const error = this.createError(
                Error,
                "invalid UTF-8 sequence",
                true,
                1007,
                "WS_ERR_INVALID_UTF8"
              );
              cb(error);
              return;
            }
            this._loop = false;
            this.emit("conclude", code, buf);
            this.end();
          }
          this._state = GET_INFO;
          return;
        }
        if (this._allowSynchronousEvents) {
          this.emit(this._opcode === 9 ? "ping" : "pong", data);
          this._state = GET_INFO;
        } else {
          this._state = DEFER_EVENT;
          setImmediate(() => {
            this.emit(this._opcode === 9 ? "ping" : "pong", data);
            this._state = GET_INFO;
            this.startLoop(cb);
          });
        }
      }
      /**
       * Builds an error object.
       *
       * @param {function(new:Error|RangeError)} ErrorCtor The error constructor
       * @param {String} message The error message
       * @param {Boolean} prefix Specifies whether or not to add a default prefix to
       *     `message`
       * @param {Number} statusCode The status code
       * @param {String} errorCode The exposed error code
       * @return {(Error|RangeError)} The error
       * @private
       */
      createError(ErrorCtor, message, prefix, statusCode, errorCode) {
        this._loop = false;
        this._errored = true;
        const err = new ErrorCtor(
          prefix ? `Invalid WebSocket frame: ${message}` : message
        );
        Error.captureStackTrace(err, this.createError);
        err.code = errorCode;
        err[kStatusCode] = statusCode;
        return err;
      }
    };
    module2.exports = Receiver2;
  }
});

// node_modules/ws/lib/sender.js
var require_sender = __commonJS({
  "node_modules/ws/lib/sender.js"(exports2, module2) {
    "use strict";
    var { Duplex } = require("stream");
    var { randomFillSync } = require("crypto");
    var {
      types: { isUint8Array }
    } = require("util");
    var PerMessageDeflate2 = require_permessage_deflate();
    var { EMPTY_BUFFER, kWebSocket, NOOP } = require_constants();
    var { isBlob, isValidStatusCode } = require_validation();
    var { mask: applyMask, toBuffer } = require_buffer_util();
    var kByteLength = Symbol("kByteLength");
    var maskBuffer = Buffer.alloc(4);
    var RANDOM_POOL_SIZE = 8 * 1024;
    var randomPool;
    var randomPoolPointer = RANDOM_POOL_SIZE;
    var DEFAULT = 0;
    var DEFLATING = 1;
    var GET_BLOB_DATA = 2;
    var Sender2 = class _Sender {
      /**
       * Creates a Sender instance.
       *
       * @param {Duplex} socket The connection socket
       * @param {Object} [extensions] An object containing the negotiated extensions
       * @param {Function} [generateMask] The function used to generate the masking
       *     key
       */
      constructor(socket, extensions, generateMask) {
        this._extensions = extensions || {};
        if (generateMask) {
          this._generateMask = generateMask;
          this._maskBuffer = Buffer.alloc(4);
        }
        this._socket = socket;
        this._firstFragment = true;
        this._compress = false;
        this._bufferedBytes = 0;
        this._queue = [];
        this._state = DEFAULT;
        this.onerror = NOOP;
        this[kWebSocket] = void 0;
      }
      /**
       * Frames a piece of data according to the HyBi WebSocket protocol.
       *
       * @param {(Buffer|String)} data The data to frame
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @return {(Buffer|String)[]} The framed data
       * @public
       */
      static frame(data, options) {
        let mask;
        let merge = false;
        let offset = 2;
        let skipMasking = false;
        if (options.mask) {
          mask = options.maskBuffer || maskBuffer;
          if (options.generateMask) {
            options.generateMask(mask);
          } else {
            if (randomPoolPointer === RANDOM_POOL_SIZE) {
              if (randomPool === void 0) {
                randomPool = Buffer.alloc(RANDOM_POOL_SIZE);
              }
              randomFillSync(randomPool, 0, RANDOM_POOL_SIZE);
              randomPoolPointer = 0;
            }
            mask[0] = randomPool[randomPoolPointer++];
            mask[1] = randomPool[randomPoolPointer++];
            mask[2] = randomPool[randomPoolPointer++];
            mask[3] = randomPool[randomPoolPointer++];
          }
          skipMasking = (mask[0] | mask[1] | mask[2] | mask[3]) === 0;
          offset = 6;
        }
        let dataLength;
        if (typeof data === "string") {
          if ((!options.mask || skipMasking) && options[kByteLength] !== void 0) {
            dataLength = options[kByteLength];
          } else {
            data = Buffer.from(data);
            dataLength = data.length;
          }
        } else {
          dataLength = data.length;
          merge = options.mask && options.readOnly && !skipMasking;
        }
        let payloadLength = dataLength;
        if (dataLength >= 65536) {
          offset += 8;
          payloadLength = 127;
        } else if (dataLength > 125) {
          offset += 2;
          payloadLength = 126;
        }
        const target = Buffer.allocUnsafe(merge ? dataLength + offset : offset);
        target[0] = options.fin ? options.opcode | 128 : options.opcode;
        if (options.rsv1) target[0] |= 64;
        target[1] = payloadLength;
        if (payloadLength === 126) {
          target.writeUInt16BE(dataLength, 2);
        } else if (payloadLength === 127) {
          target[2] = target[3] = 0;
          target.writeUIntBE(dataLength, 4, 6);
        }
        if (!options.mask) return [target, data];
        target[1] |= 128;
        target[offset - 4] = mask[0];
        target[offset - 3] = mask[1];
        target[offset - 2] = mask[2];
        target[offset - 1] = mask[3];
        if (skipMasking) return [target, data];
        if (merge) {
          applyMask(data, mask, target, offset, dataLength);
          return [target];
        }
        applyMask(data, mask, data, 0, dataLength);
        return [target, data];
      }
      /**
       * Sends a close message to the other peer.
       *
       * @param {Number} [code] The status code component of the body
       * @param {(String|Buffer)} [data] The message component of the body
       * @param {Boolean} [mask=false] Specifies whether or not to mask the message
       * @param {Function} [cb] Callback
       * @public
       */
      close(code, data, mask, cb) {
        let buf;
        if (code === void 0) {
          buf = EMPTY_BUFFER;
        } else if (typeof code !== "number" || !isValidStatusCode(code)) {
          throw new TypeError("First argument must be a valid error code number");
        } else if (data === void 0 || !data.length) {
          buf = Buffer.allocUnsafe(2);
          buf.writeUInt16BE(code, 0);
        } else {
          const length = Buffer.byteLength(data);
          if (length > 123) {
            throw new RangeError("The message must not be greater than 123 bytes");
          }
          buf = Buffer.allocUnsafe(2 + length);
          buf.writeUInt16BE(code, 0);
          if (typeof data === "string") {
            buf.write(data, 2);
          } else if (isUint8Array(data)) {
            buf.set(data, 2);
          } else {
            throw new TypeError("Second argument must be a string or a Uint8Array");
          }
        }
        const options = {
          [kByteLength]: buf.length,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 8,
          readOnly: false,
          rsv1: false
        };
        if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, buf, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(buf, options), cb);
        }
      }
      /**
       * Sends a ping message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      ping(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 9,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a pong message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Boolean} [mask=false] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback
       * @public
       */
      pong(data, mask, cb) {
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (byteLength > 125) {
          throw new RangeError("The data size must not be greater than 125 bytes");
        }
        const options = {
          [kByteLength]: byteLength,
          fin: true,
          generateMask: this._generateMask,
          mask,
          maskBuffer: this._maskBuffer,
          opcode: 10,
          readOnly,
          rsv1: false
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, false, options, cb]);
          } else {
            this.getBlobData(data, false, options, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, false, options, cb]);
        } else {
          this.sendFrame(_Sender.frame(data, options), cb);
        }
      }
      /**
       * Sends a data message to the other peer.
       *
       * @param {*} data The message to send
       * @param {Object} options Options object
       * @param {Boolean} [options.binary=false] Specifies whether `data` is binary
       *     or text
       * @param {Boolean} [options.compress=false] Specifies whether or not to
       *     compress `data`
       * @param {Boolean} [options.fin=false] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Function} [cb] Callback
       * @public
       */
      send(data, options, cb) {
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        let opcode = options.binary ? 2 : 1;
        let rsv1 = options.compress;
        let byteLength;
        let readOnly;
        if (typeof data === "string") {
          byteLength = Buffer.byteLength(data);
          readOnly = false;
        } else if (isBlob(data)) {
          byteLength = data.size;
          readOnly = false;
        } else {
          data = toBuffer(data);
          byteLength = data.length;
          readOnly = toBuffer.readOnly;
        }
        if (this._firstFragment) {
          this._firstFragment = false;
          if (rsv1 && perMessageDeflate && perMessageDeflate.params[perMessageDeflate._isServer ? "server_no_context_takeover" : "client_no_context_takeover"]) {
            rsv1 = byteLength >= perMessageDeflate._threshold;
          }
          this._compress = rsv1;
        } else {
          rsv1 = false;
          opcode = 0;
        }
        if (options.fin) this._firstFragment = true;
        const opts = {
          [kByteLength]: byteLength,
          fin: options.fin,
          generateMask: this._generateMask,
          mask: options.mask,
          maskBuffer: this._maskBuffer,
          opcode,
          readOnly,
          rsv1
        };
        if (isBlob(data)) {
          if (this._state !== DEFAULT) {
            this.enqueue([this.getBlobData, data, this._compress, opts, cb]);
          } else {
            this.getBlobData(data, this._compress, opts, cb);
          }
        } else if (this._state !== DEFAULT) {
          this.enqueue([this.dispatch, data, this._compress, opts, cb]);
        } else {
          this.dispatch(data, this._compress, opts, cb);
        }
      }
      /**
       * Gets the contents of a blob as binary data.
       *
       * @param {Blob} blob The blob
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     the data
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      getBlobData(blob, compress, options, cb) {
        this._bufferedBytes += options[kByteLength];
        this._state = GET_BLOB_DATA;
        blob.arrayBuffer().then((arrayBuffer) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while the blob was being read"
            );
            process.nextTick(callCallbacks, this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          const data = toBuffer(arrayBuffer);
          if (!compress) {
            this._state = DEFAULT;
            this.sendFrame(_Sender.frame(data, options), cb);
            this.dequeue();
          } else {
            this.dispatch(data, compress, options, cb);
          }
        }).catch((err) => {
          process.nextTick(onError, this, err, cb);
        });
      }
      /**
       * Dispatches a message.
       *
       * @param {(Buffer|String)} data The message to send
       * @param {Boolean} [compress=false] Specifies whether or not to compress
       *     `data`
       * @param {Object} options Options object
       * @param {Boolean} [options.fin=false] Specifies whether or not to set the
       *     FIN bit
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Boolean} [options.mask=false] Specifies whether or not to mask
       *     `data`
       * @param {Buffer} [options.maskBuffer] The buffer used to store the masking
       *     key
       * @param {Number} options.opcode The opcode
       * @param {Boolean} [options.readOnly=false] Specifies whether `data` can be
       *     modified
       * @param {Boolean} [options.rsv1=false] Specifies whether or not to set the
       *     RSV1 bit
       * @param {Function} [cb] Callback
       * @private
       */
      dispatch(data, compress, options, cb) {
        if (!compress) {
          this.sendFrame(_Sender.frame(data, options), cb);
          return;
        }
        const perMessageDeflate = this._extensions[PerMessageDeflate2.extensionName];
        this._bufferedBytes += options[kByteLength];
        this._state = DEFLATING;
        perMessageDeflate.compress(data, options.fin, (_, buf) => {
          if (this._socket.destroyed) {
            const err = new Error(
              "The socket was closed while data was being compressed"
            );
            callCallbacks(this, err, cb);
            return;
          }
          this._bufferedBytes -= options[kByteLength];
          this._state = DEFAULT;
          options.readOnly = false;
          this.sendFrame(_Sender.frame(buf, options), cb);
          this.dequeue();
        });
      }
      /**
       * Executes queued send operations.
       *
       * @private
       */
      dequeue() {
        while (this._state === DEFAULT && this._queue.length) {
          const params = this._queue.shift();
          this._bufferedBytes -= params[3][kByteLength];
          Reflect.apply(params[0], this, params.slice(1));
        }
      }
      /**
       * Enqueues a send operation.
       *
       * @param {Array} params Send operation parameters.
       * @private
       */
      enqueue(params) {
        this._bufferedBytes += params[3][kByteLength];
        this._queue.push(params);
      }
      /**
       * Sends a frame.
       *
       * @param {(Buffer | String)[]} list The frame to send
       * @param {Function} [cb] Callback
       * @private
       */
      sendFrame(list, cb) {
        if (list.length === 2) {
          this._socket.cork();
          this._socket.write(list[0]);
          this._socket.write(list[1], cb);
          this._socket.uncork();
        } else {
          this._socket.write(list[0], cb);
        }
      }
    };
    module2.exports = Sender2;
    function callCallbacks(sender, err, cb) {
      if (typeof cb === "function") cb(err);
      for (let i = 0; i < sender._queue.length; i++) {
        const params = sender._queue[i];
        const callback = params[params.length - 1];
        if (typeof callback === "function") callback(err);
      }
    }
    function onError(sender, err, cb) {
      callCallbacks(sender, err, cb);
      sender.onerror(err);
    }
  }
});

// node_modules/ws/lib/event-target.js
var require_event_target = __commonJS({
  "node_modules/ws/lib/event-target.js"(exports2, module2) {
    "use strict";
    var { kForOnEventAttribute, kListener } = require_constants();
    var kCode = Symbol("kCode");
    var kData = Symbol("kData");
    var kError = Symbol("kError");
    var kMessage = Symbol("kMessage");
    var kReason = Symbol("kReason");
    var kTarget = Symbol("kTarget");
    var kType = Symbol("kType");
    var kWasClean = Symbol("kWasClean");
    var Event = class {
      /**
       * Create a new `Event`.
       *
       * @param {String} type The name of the event
       * @throws {TypeError} If the `type` argument is not specified
       */
      constructor(type) {
        this[kTarget] = null;
        this[kType] = type;
      }
      /**
       * @type {*}
       */
      get target() {
        return this[kTarget];
      }
      /**
       * @type {String}
       */
      get type() {
        return this[kType];
      }
    };
    Object.defineProperty(Event.prototype, "target", { enumerable: true });
    Object.defineProperty(Event.prototype, "type", { enumerable: true });
    var CloseEvent = class extends Event {
      /**
       * Create a new `CloseEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {Number} [options.code=0] The status code explaining why the
       *     connection was closed
       * @param {String} [options.reason=''] A human-readable string explaining why
       *     the connection was closed
       * @param {Boolean} [options.wasClean=false] Indicates whether or not the
       *     connection was cleanly closed
       */
      constructor(type, options = {}) {
        super(type);
        this[kCode] = options.code === void 0 ? 0 : options.code;
        this[kReason] = options.reason === void 0 ? "" : options.reason;
        this[kWasClean] = options.wasClean === void 0 ? false : options.wasClean;
      }
      /**
       * @type {Number}
       */
      get code() {
        return this[kCode];
      }
      /**
       * @type {String}
       */
      get reason() {
        return this[kReason];
      }
      /**
       * @type {Boolean}
       */
      get wasClean() {
        return this[kWasClean];
      }
    };
    Object.defineProperty(CloseEvent.prototype, "code", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "reason", { enumerable: true });
    Object.defineProperty(CloseEvent.prototype, "wasClean", { enumerable: true });
    var ErrorEvent = class extends Event {
      /**
       * Create a new `ErrorEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.error=null] The error that generated this event
       * @param {String} [options.message=''] The error message
       */
      constructor(type, options = {}) {
        super(type);
        this[kError] = options.error === void 0 ? null : options.error;
        this[kMessage] = options.message === void 0 ? "" : options.message;
      }
      /**
       * @type {*}
       */
      get error() {
        return this[kError];
      }
      /**
       * @type {String}
       */
      get message() {
        return this[kMessage];
      }
    };
    Object.defineProperty(ErrorEvent.prototype, "error", { enumerable: true });
    Object.defineProperty(ErrorEvent.prototype, "message", { enumerable: true });
    var MessageEvent = class extends Event {
      /**
       * Create a new `MessageEvent`.
       *
       * @param {String} type The name of the event
       * @param {Object} [options] A dictionary object that allows for setting
       *     attributes via object members of the same name
       * @param {*} [options.data=null] The message content
       */
      constructor(type, options = {}) {
        super(type);
        this[kData] = options.data === void 0 ? null : options.data;
      }
      /**
       * @type {*}
       */
      get data() {
        return this[kData];
      }
    };
    Object.defineProperty(MessageEvent.prototype, "data", { enumerable: true });
    var EventTarget = {
      /**
       * Register an event listener.
       *
       * @param {String} type A string representing the event type to listen for
       * @param {(Function|Object)} handler The listener to add
       * @param {Object} [options] An options object specifies characteristics about
       *     the event listener
       * @param {Boolean} [options.once=false] A `Boolean` indicating that the
       *     listener should be invoked at most once after being added. If `true`,
       *     the listener would be automatically removed when invoked.
       * @public
       */
      addEventListener(type, handler, options = {}) {
        for (const listener of this.listeners(type)) {
          if (!options[kForOnEventAttribute] && listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            return;
          }
        }
        let wrapper;
        if (type === "message") {
          wrapper = function onMessage(data, isBinary) {
            const event = new MessageEvent("message", {
              data: isBinary ? data : data.toString()
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "close") {
          wrapper = function onClose(code, message) {
            const event = new CloseEvent("close", {
              code,
              reason: message.toString(),
              wasClean: this._closeFrameReceived && this._closeFrameSent
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "error") {
          wrapper = function onError(error) {
            const event = new ErrorEvent("error", {
              error,
              message: error.message
            });
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else if (type === "open") {
          wrapper = function onOpen() {
            const event = new Event("open");
            event[kTarget] = this;
            callListener(handler, this, event);
          };
        } else {
          return;
        }
        wrapper[kForOnEventAttribute] = !!options[kForOnEventAttribute];
        wrapper[kListener] = handler;
        if (options.once) {
          this.once(type, wrapper);
        } else {
          this.on(type, wrapper);
        }
      },
      /**
       * Remove an event listener.
       *
       * @param {String} type A string representing the event type to remove
       * @param {(Function|Object)} handler The listener to remove
       * @public
       */
      removeEventListener(type, handler) {
        for (const listener of this.listeners(type)) {
          if (listener[kListener] === handler && !listener[kForOnEventAttribute]) {
            this.removeListener(type, listener);
            break;
          }
        }
      }
    };
    module2.exports = {
      CloseEvent,
      ErrorEvent,
      Event,
      EventTarget,
      MessageEvent
    };
    function callListener(listener, thisArg, event) {
      if (typeof listener === "object" && listener.handleEvent) {
        listener.handleEvent.call(listener, event);
      } else {
        listener.call(thisArg, event);
      }
    }
  }
});

// node_modules/ws/lib/extension.js
var require_extension = __commonJS({
  "node_modules/ws/lib/extension.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function push(dest, name2, elem) {
      if (dest[name2] === void 0) dest[name2] = [elem];
      else dest[name2].push(elem);
    }
    function parse(header) {
      const offers = /* @__PURE__ */ Object.create(null);
      let params = /* @__PURE__ */ Object.create(null);
      let mustUnescape = false;
      let isEscaping = false;
      let inQuotes = false;
      let extensionName;
      let paramName;
      let start = -1;
      let code = -1;
      let end = -1;
      let i = 0;
      for (; i < header.length; i++) {
        code = header.charCodeAt(i);
        if (extensionName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (i !== 0 && (code === 32 || code === 9)) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            const name2 = header.slice(start, end);
            if (code === 44) {
              push(offers, name2, params);
              params = /* @__PURE__ */ Object.create(null);
            } else {
              extensionName = name2;
            }
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else if (paramName === void 0) {
          if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (code === 32 || code === 9) {
            if (end === -1 && start !== -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            push(params, header.slice(start, end), true);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            start = end = -1;
          } else if (code === 61 && start !== -1 && end === -1) {
            paramName = header.slice(start, i);
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        } else {
          if (isEscaping) {
            if (tokenChars[code] !== 1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (start === -1) start = i;
            else if (!mustUnescape) mustUnescape = true;
            isEscaping = false;
          } else if (inQuotes) {
            if (tokenChars[code] === 1) {
              if (start === -1) start = i;
            } else if (code === 34 && start !== -1) {
              inQuotes = false;
              end = i;
            } else if (code === 92) {
              isEscaping = true;
            } else {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
          } else if (code === 34 && header.charCodeAt(i - 1) === 61) {
            inQuotes = true;
          } else if (end === -1 && tokenChars[code] === 1) {
            if (start === -1) start = i;
          } else if (start !== -1 && (code === 32 || code === 9)) {
            if (end === -1) end = i;
          } else if (code === 59 || code === 44) {
            if (start === -1) {
              throw new SyntaxError(`Unexpected character at index ${i}`);
            }
            if (end === -1) end = i;
            let value = header.slice(start, end);
            if (mustUnescape) {
              value = value.replace(/\\/g, "");
              mustUnescape = false;
            }
            push(params, paramName, value);
            if (code === 44) {
              push(offers, extensionName, params);
              params = /* @__PURE__ */ Object.create(null);
              extensionName = void 0;
            }
            paramName = void 0;
            start = end = -1;
          } else {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
        }
      }
      if (start === -1 || inQuotes || code === 32 || code === 9) {
        throw new SyntaxError("Unexpected end of input");
      }
      if (end === -1) end = i;
      const token = header.slice(start, end);
      if (extensionName === void 0) {
        push(offers, token, params);
      } else {
        if (paramName === void 0) {
          push(params, token, true);
        } else if (mustUnescape) {
          push(params, paramName, token.replace(/\\/g, ""));
        } else {
          push(params, paramName, token);
        }
        push(offers, extensionName, params);
      }
      return offers;
    }
    function format(extensions) {
      return Object.keys(extensions).map((extension2) => {
        let configurations = extensions[extension2];
        if (!Array.isArray(configurations)) configurations = [configurations];
        return configurations.map((params) => {
          return [extension2].concat(
            Object.keys(params).map((k) => {
              let values = params[k];
              if (!Array.isArray(values)) values = [values];
              return values.map((v) => v === true ? k : `${k}=${v}`).join("; ");
            })
          ).join("; ");
        }).join(", ");
      }).join(", ");
    }
    module2.exports = { format, parse };
  }
});

// node_modules/ws/lib/websocket.js
var require_websocket = __commonJS({
  "node_modules/ws/lib/websocket.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var https = require("https");
    var http = require("http");
    var net2 = require("net");
    var tls = require("tls");
    var { randomBytes, createHash: createHash11 } = require("crypto");
    var { Duplex, Readable } = require("stream");
    var { URL } = require("url");
    var PerMessageDeflate2 = require_permessage_deflate();
    var Receiver2 = require_receiver();
    var Sender2 = require_sender();
    var { isBlob } = require_validation();
    var {
      BINARY_TYPES,
      CLOSE_TIMEOUT,
      EMPTY_BUFFER,
      GUID,
      kForOnEventAttribute,
      kListener,
      kStatusCode,
      kWebSocket,
      NOOP
    } = require_constants();
    var {
      EventTarget: { addEventListener, removeEventListener }
    } = require_event_target();
    var { format, parse } = require_extension();
    var { toBuffer } = require_buffer_util();
    var kAborted = Symbol("kAborted");
    var protocolVersions = [8, 13];
    var readyStates = ["CONNECTING", "OPEN", "CLOSING", "CLOSED"];
    var subprotocolRegex = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
    var WebSocket2 = class _WebSocket extends EventEmitter {
      /**
       * Create a new `WebSocket`.
       *
       * @param {(String|URL)} address The URL to which to connect
       * @param {(String|String[])} [protocols] The subprotocols
       * @param {Object} [options] Connection options
       */
      constructor(address, protocols, options) {
        super();
        this._binaryType = BINARY_TYPES[0];
        this._closeCode = 1006;
        this._closeFrameReceived = false;
        this._closeFrameSent = false;
        this._closeMessage = EMPTY_BUFFER;
        this._closeTimer = null;
        this._errorEmitted = false;
        this._extensions = {};
        this._paused = false;
        this._protocol = "";
        this._readyState = _WebSocket.CONNECTING;
        this._receiver = null;
        this._sender = null;
        this._socket = null;
        if (address !== null) {
          this._bufferedAmount = 0;
          this._isServer = false;
          this._redirects = 0;
          if (protocols === void 0) {
            protocols = [];
          } else if (!Array.isArray(protocols)) {
            if (typeof protocols === "object" && protocols !== null) {
              options = protocols;
              protocols = [];
            } else {
              protocols = [protocols];
            }
          }
          initAsClient(this, address, protocols, options);
        } else {
          this._autoPong = options.autoPong;
          this._closeTimeout = options.closeTimeout;
          this._isServer = true;
        }
      }
      /**
       * For historical reasons, the custom "nodebuffer" type is used by the default
       * instead of "blob".
       *
       * @type {String}
       */
      get binaryType() {
        return this._binaryType;
      }
      set binaryType(type) {
        if (!BINARY_TYPES.includes(type)) return;
        this._binaryType = type;
        if (this._receiver) this._receiver._binaryType = type;
      }
      /**
       * @type {Number}
       */
      get bufferedAmount() {
        if (!this._socket) return this._bufferedAmount;
        return this._socket._writableState.length + this._sender._bufferedBytes;
      }
      /**
       * @type {String}
       */
      get extensions() {
        return Object.keys(this._extensions).join();
      }
      /**
       * @type {Boolean}
       */
      get isPaused() {
        return this._paused;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onclose() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onerror() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onopen() {
        return null;
      }
      /**
       * @type {Function}
       */
      /* istanbul ignore next */
      get onmessage() {
        return null;
      }
      /**
       * @type {String}
       */
      get protocol() {
        return this._protocol;
      }
      /**
       * @type {Number}
       */
      get readyState() {
        return this._readyState;
      }
      /**
       * @type {String}
       */
      get url() {
        return this._url;
      }
      /**
       * Set up the socket and the internal resources.
       *
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Object} options Options object
       * @param {Boolean} [options.allowSynchronousEvents=false] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Function} [options.generateMask] The function used to generate the
       *     masking key
       * @param {Number} [options.maxBufferedChunks=0] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=0] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=0] The maximum allowed message size
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @private
       */
      setSocket(socket, head, options) {
        const receiver = new Receiver2({
          allowSynchronousEvents: options.allowSynchronousEvents,
          binaryType: this.binaryType,
          extensions: this._extensions,
          isServer: this._isServer,
          maxBufferedChunks: options.maxBufferedChunks,
          maxFragments: options.maxFragments,
          maxPayload: options.maxPayload,
          skipUTF8Validation: options.skipUTF8Validation
        });
        const sender = new Sender2(socket, this._extensions, options.generateMask);
        this._receiver = receiver;
        this._sender = sender;
        this._socket = socket;
        receiver[kWebSocket] = this;
        sender[kWebSocket] = this;
        socket[kWebSocket] = this;
        receiver.on("conclude", receiverOnConclude);
        receiver.on("drain", receiverOnDrain);
        receiver.on("error", receiverOnError);
        receiver.on("message", receiverOnMessage);
        receiver.on("ping", receiverOnPing);
        receiver.on("pong", receiverOnPong);
        sender.onerror = senderOnError;
        if (socket.setTimeout) socket.setTimeout(0);
        if (socket.setNoDelay) socket.setNoDelay();
        if (head.length > 0) socket.unshift(head);
        socket.on("close", socketOnClose);
        socket.on("data", socketOnData);
        socket.on("end", socketOnEnd);
        socket.on("error", socketOnError);
        this._readyState = _WebSocket.OPEN;
        this.emit("open");
      }
      /**
       * Emit the `'close'` event.
       *
       * @private
       */
      emitClose() {
        if (!this._socket) {
          this._readyState = _WebSocket.CLOSED;
          this.emit("close", this._closeCode, this._closeMessage);
          return;
        }
        if (this._extensions[PerMessageDeflate2.extensionName]) {
          this._extensions[PerMessageDeflate2.extensionName].cleanup();
        }
        this._receiver.removeAllListeners();
        this._readyState = _WebSocket.CLOSED;
        this.emit("close", this._closeCode, this._closeMessage);
      }
      /**
       * Start a closing handshake.
       *
       *          +----------+   +-----------+   +----------+
       *     - - -|ws.close()|-->|close frame|-->|ws.close()|- - -
       *    |     +----------+   +-----------+   +----------+     |
       *          +----------+   +-----------+         |
       * CLOSING  |ws.close()|<--|close frame|<--+-----+       CLOSING
       *          +----------+   +-----------+   |
       *    |           |                        |   +---+        |
       *                +------------------------+-->|fin| - - - -
       *    |         +---+                      |   +---+
       *     - - - - -|fin|<---------------------+
       *              +---+
       *
       * @param {Number} [code] Status code explaining why the connection is closing
       * @param {(String|Buffer)} [data] The reason why the connection is
       *     closing
       * @public
       */
      close(code, data) {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this.readyState === _WebSocket.CLOSING) {
          if (this._closeFrameSent && (this._closeFrameReceived || this._receiver._writableState.errorEmitted)) {
            this._socket.end();
          }
          return;
        }
        this._readyState = _WebSocket.CLOSING;
        this._sender.close(code, data, !this._isServer, (err) => {
          if (err) return;
          this._closeFrameSent = true;
          if (this._closeFrameReceived || this._receiver._writableState.errorEmitted) {
            this._socket.end();
          }
        });
        setCloseTimer(this);
      }
      /**
       * Pause the socket.
       *
       * @public
       */
      pause() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = true;
        this._socket.pause();
      }
      /**
       * Send a ping.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the ping is sent
       * @public
       */
      ping(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.ping(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Send a pong.
       *
       * @param {*} [data] The data to send
       * @param {Boolean} [mask] Indicates whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when the pong is sent
       * @public
       */
      pong(data, mask, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof data === "function") {
          cb = data;
          data = mask = void 0;
        } else if (typeof mask === "function") {
          cb = mask;
          mask = void 0;
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        if (mask === void 0) mask = !this._isServer;
        this._sender.pong(data || EMPTY_BUFFER, mask, cb);
      }
      /**
       * Resume the socket.
       *
       * @public
       */
      resume() {
        if (this.readyState === _WebSocket.CONNECTING || this.readyState === _WebSocket.CLOSED) {
          return;
        }
        this._paused = false;
        if (!this._receiver._writableState.needDrain) this._socket.resume();
      }
      /**
       * Send a data message.
       *
       * @param {*} data The message to send
       * @param {Object} [options] Options object
       * @param {Boolean} [options.binary] Specifies whether `data` is binary or
       *     text
       * @param {Boolean} [options.compress] Specifies whether or not to compress
       *     `data`
       * @param {Boolean} [options.fin=true] Specifies whether the fragment is the
       *     last one
       * @param {Boolean} [options.mask] Specifies whether or not to mask `data`
       * @param {Function} [cb] Callback which is executed when data is written out
       * @public
       */
      send(data, options, cb) {
        if (this.readyState === _WebSocket.CONNECTING) {
          throw new Error("WebSocket is not open: readyState 0 (CONNECTING)");
        }
        if (typeof options === "function") {
          cb = options;
          options = {};
        }
        if (typeof data === "number") data = data.toString();
        if (this.readyState !== _WebSocket.OPEN) {
          sendAfterClose(this, data, cb);
          return;
        }
        const opts = {
          binary: typeof data !== "string",
          mask: !this._isServer,
          compress: true,
          fin: true,
          ...options
        };
        if (!this._extensions[PerMessageDeflate2.extensionName]) {
          opts.compress = false;
        }
        this._sender.send(data || EMPTY_BUFFER, opts, cb);
      }
      /**
       * Forcibly close the connection.
       *
       * @public
       */
      terminate() {
        if (this.readyState === _WebSocket.CLOSED) return;
        if (this.readyState === _WebSocket.CONNECTING) {
          const msg = "WebSocket was closed before the connection was established";
          abortHandshake(this, this._req, msg);
          return;
        }
        if (this._socket) {
          this._readyState = _WebSocket.CLOSING;
          this._socket.destroy();
        }
      }
    };
    Object.defineProperty(WebSocket2, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2.prototype, "CONNECTING", {
      enumerable: true,
      value: readyStates.indexOf("CONNECTING")
    });
    Object.defineProperty(WebSocket2, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2.prototype, "OPEN", {
      enumerable: true,
      value: readyStates.indexOf("OPEN")
    });
    Object.defineProperty(WebSocket2, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSING", {
      enumerable: true,
      value: readyStates.indexOf("CLOSING")
    });
    Object.defineProperty(WebSocket2, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    Object.defineProperty(WebSocket2.prototype, "CLOSED", {
      enumerable: true,
      value: readyStates.indexOf("CLOSED")
    });
    [
      "binaryType",
      "bufferedAmount",
      "extensions",
      "isPaused",
      "protocol",
      "readyState",
      "url"
    ].forEach((property) => {
      Object.defineProperty(WebSocket2.prototype, property, { enumerable: true });
    });
    ["open", "error", "close", "message"].forEach((method) => {
      Object.defineProperty(WebSocket2.prototype, `on${method}`, {
        enumerable: true,
        get() {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) return listener[kListener];
          }
          return null;
        },
        set(handler) {
          for (const listener of this.listeners(method)) {
            if (listener[kForOnEventAttribute]) {
              this.removeListener(method, listener);
              break;
            }
          }
          if (typeof handler !== "function") return;
          this.addEventListener(method, handler, {
            [kForOnEventAttribute]: true
          });
        }
      });
    });
    WebSocket2.prototype.addEventListener = addEventListener;
    WebSocket2.prototype.removeEventListener = removeEventListener;
    module2.exports = WebSocket2;
    function initAsClient(websocket, address, protocols, options) {
      const opts = {
        allowSynchronousEvents: true,
        autoPong: true,
        closeTimeout: CLOSE_TIMEOUT,
        protocolVersion: protocolVersions[1],
        maxBufferedChunks: 256 * 1024,
        maxFragments: 16 * 1024,
        maxPayload: 100 * 1024 * 1024,
        skipUTF8Validation: false,
        perMessageDeflate: true,
        followRedirects: false,
        maxRedirects: 10,
        ...options,
        socketPath: void 0,
        hostname: void 0,
        protocol: void 0,
        timeout: void 0,
        method: "GET",
        host: void 0,
        path: void 0,
        port: void 0
      };
      websocket._autoPong = opts.autoPong;
      websocket._closeTimeout = opts.closeTimeout;
      if (!protocolVersions.includes(opts.protocolVersion)) {
        throw new RangeError(
          `Unsupported protocol version: ${opts.protocolVersion} (supported versions: ${protocolVersions.join(", ")})`
        );
      }
      let parsedUrl;
      if (address instanceof URL) {
        parsedUrl = address;
      } else {
        try {
          parsedUrl = new URL(address);
        } catch {
          throw new SyntaxError(`Invalid URL: ${address}`);
        }
      }
      if (parsedUrl.protocol === "http:") {
        parsedUrl.protocol = "ws:";
      } else if (parsedUrl.protocol === "https:") {
        parsedUrl.protocol = "wss:";
      }
      websocket._url = parsedUrl.href;
      const isSecure = parsedUrl.protocol === "wss:";
      const isIpcUrl = parsedUrl.protocol === "ws+unix:";
      let invalidUrlMessage;
      if (parsedUrl.protocol !== "ws:" && !isSecure && !isIpcUrl) {
        invalidUrlMessage = `The URL's protocol must be one of "ws:", "wss:", "http:", "https:", or "ws+unix:"`;
      } else if (isIpcUrl && !parsedUrl.pathname) {
        invalidUrlMessage = "The URL's pathname is empty";
      } else if (parsedUrl.hash) {
        invalidUrlMessage = "The URL contains a fragment identifier";
      }
      if (invalidUrlMessage) {
        const err = new SyntaxError(invalidUrlMessage);
        if (websocket._redirects === 0) {
          throw err;
        } else {
          emitErrorAndClose(websocket, err);
          return;
        }
      }
      const defaultPort = isSecure ? 443 : 80;
      const key = randomBytes(16).toString("base64");
      const request = isSecure ? https.request : http.request;
      const protocolSet = /* @__PURE__ */ new Set();
      let perMessageDeflate;
      opts.createConnection = opts.createConnection || (isSecure ? tlsConnect : netConnect);
      opts.defaultPort = opts.defaultPort || defaultPort;
      opts.port = parsedUrl.port || defaultPort;
      opts.host = parsedUrl.hostname.startsWith("[") ? parsedUrl.hostname.slice(1, -1) : parsedUrl.hostname;
      opts.headers = {
        ...opts.headers,
        "Sec-WebSocket-Version": opts.protocolVersion,
        "Sec-WebSocket-Key": key,
        Connection: "Upgrade",
        Upgrade: "websocket"
      };
      opts.path = parsedUrl.pathname + parsedUrl.search;
      opts.timeout = opts.handshakeTimeout;
      if (opts.perMessageDeflate) {
        perMessageDeflate = new PerMessageDeflate2({
          ...opts.perMessageDeflate,
          isServer: false,
          maxPayload: opts.maxPayload
        });
        opts.headers["Sec-WebSocket-Extensions"] = format({
          [PerMessageDeflate2.extensionName]: perMessageDeflate.offer()
        });
      }
      if (protocols.length) {
        for (const protocol of protocols) {
          if (typeof protocol !== "string" || !subprotocolRegex.test(protocol) || protocolSet.has(protocol)) {
            throw new SyntaxError(
              "An invalid or duplicated subprotocol was specified"
            );
          }
          protocolSet.add(protocol);
        }
        opts.headers["Sec-WebSocket-Protocol"] = protocols.join(",");
      }
      if (opts.origin) {
        if (opts.protocolVersion < 13) {
          opts.headers["Sec-WebSocket-Origin"] = opts.origin;
        } else {
          opts.headers.Origin = opts.origin;
        }
      }
      if (parsedUrl.username || parsedUrl.password) {
        opts.auth = `${parsedUrl.username}:${parsedUrl.password}`;
      }
      if (isIpcUrl) {
        const parts = opts.path.split(":");
        opts.socketPath = parts[0];
        opts.path = parts[1];
      }
      let req;
      if (opts.followRedirects) {
        if (websocket._redirects === 0) {
          websocket._originalIpc = isIpcUrl;
          websocket._originalSecure = isSecure;
          websocket._originalHostOrSocketPath = isIpcUrl ? opts.socketPath : parsedUrl.host;
          const headers = options && options.headers;
          options = { ...options, headers: {} };
          if (headers) {
            for (const [key2, value] of Object.entries(headers)) {
              options.headers[key2.toLowerCase()] = value;
            }
          }
        } else if (websocket.listenerCount("redirect") === 0) {
          const isSameHost = isIpcUrl ? websocket._originalIpc ? opts.socketPath === websocket._originalHostOrSocketPath : false : websocket._originalIpc ? false : parsedUrl.host === websocket._originalHostOrSocketPath;
          if (!isSameHost || websocket._originalSecure && !isSecure) {
            delete opts.headers.authorization;
            delete opts.headers.cookie;
            if (!isSameHost) delete opts.headers.host;
            opts.auth = void 0;
          }
        }
        if (opts.auth && !options.headers.authorization) {
          options.headers.authorization = "Basic " + Buffer.from(opts.auth).toString("base64");
        }
        req = websocket._req = request(opts);
        if (websocket._redirects) {
          websocket.emit("redirect", websocket.url, req);
        }
      } else {
        req = websocket._req = request(opts);
      }
      if (opts.timeout) {
        req.on("timeout", () => {
          abortHandshake(websocket, req, "Opening handshake has timed out");
        });
      }
      req.on("error", (err) => {
        if (req === null || req[kAborted]) return;
        req = websocket._req = null;
        emitErrorAndClose(websocket, err);
      });
      req.on("response", (res) => {
        const location = res.headers.location;
        const statusCode = res.statusCode;
        if (location && opts.followRedirects && statusCode >= 300 && statusCode < 400) {
          if (++websocket._redirects > opts.maxRedirects) {
            abortHandshake(websocket, req, "Maximum redirects exceeded");
            return;
          }
          req.abort();
          let addr;
          try {
            addr = new URL(location, address);
          } catch (e) {
            const err = new SyntaxError(`Invalid URL: ${location}`);
            emitErrorAndClose(websocket, err);
            return;
          }
          initAsClient(websocket, addr, protocols, options);
        } else if (!websocket.emit("unexpected-response", req, res)) {
          abortHandshake(
            websocket,
            req,
            `Unexpected server response: ${res.statusCode}`
          );
        }
      });
      req.on("upgrade", (res, socket, head) => {
        websocket.emit("upgrade", res);
        if (websocket.readyState !== WebSocket2.CONNECTING) return;
        req = websocket._req = null;
        const upgrade = res.headers.upgrade;
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          abortHandshake(websocket, socket, "Invalid Upgrade header");
          return;
        }
        const digest3 = createHash11("sha1").update(key + GUID).digest("base64");
        if (res.headers["sec-websocket-accept"] !== digest3) {
          abortHandshake(websocket, socket, "Invalid Sec-WebSocket-Accept header");
          return;
        }
        const serverProt = res.headers["sec-websocket-protocol"];
        let protError;
        if (serverProt !== void 0) {
          if (!protocolSet.size) {
            protError = "Server sent a subprotocol but none was requested";
          } else if (!protocolSet.has(serverProt)) {
            protError = "Server sent an invalid subprotocol";
          }
        } else if (protocolSet.size) {
          protError = "Server sent no subprotocol";
        }
        if (protError) {
          abortHandshake(websocket, socket, protError);
          return;
        }
        if (serverProt) websocket._protocol = serverProt;
        const secWebSocketExtensions = res.headers["sec-websocket-extensions"];
        if (secWebSocketExtensions !== void 0) {
          if (!perMessageDeflate) {
            const message = "Server sent a Sec-WebSocket-Extensions header but no extension was requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          let extensions;
          try {
            extensions = parse(secWebSocketExtensions);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          const extensionNames = Object.keys(extensions);
          if (extensionNames.length !== 1 || extensionNames[0] !== PerMessageDeflate2.extensionName) {
            const message = "Server indicated an extension that was not requested";
            abortHandshake(websocket, socket, message);
            return;
          }
          try {
            perMessageDeflate.accept(extensions[PerMessageDeflate2.extensionName]);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Extensions header";
            abortHandshake(websocket, socket, message);
            return;
          }
          websocket._extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
        }
        websocket.setSocket(socket, head, {
          allowSynchronousEvents: opts.allowSynchronousEvents,
          generateMask: opts.generateMask,
          maxBufferedChunks: opts.maxBufferedChunks,
          maxFragments: opts.maxFragments,
          maxPayload: opts.maxPayload,
          skipUTF8Validation: opts.skipUTF8Validation
        });
      });
      if (opts.finishRequest) {
        opts.finishRequest(req, websocket);
      } else {
        req.end();
      }
    }
    function emitErrorAndClose(websocket, err) {
      websocket._readyState = WebSocket2.CLOSING;
      websocket._errorEmitted = true;
      websocket.emit("error", err);
      websocket.emitClose();
    }
    function netConnect(options) {
      options.path = options.socketPath;
      return net2.connect(options);
    }
    function tlsConnect(options) {
      options.path = void 0;
      if (!options.servername && options.servername !== "") {
        options.servername = net2.isIP(options.host) ? "" : options.host;
      }
      return tls.connect(options);
    }
    function abortHandshake(websocket, stream, message) {
      websocket._readyState = WebSocket2.CLOSING;
      const err = new Error(message);
      Error.captureStackTrace(err, abortHandshake);
      if (stream.setHeader) {
        stream[kAborted] = true;
        stream.abort();
        if (stream.socket && !stream.socket.destroyed) {
          stream.socket.destroy();
        }
        process.nextTick(emitErrorAndClose, websocket, err);
      } else {
        stream.destroy(err);
        stream.once("error", websocket.emit.bind(websocket, "error"));
        stream.once("close", websocket.emitClose.bind(websocket));
      }
    }
    function sendAfterClose(websocket, data, cb) {
      if (data) {
        const length = isBlob(data) ? data.size : toBuffer(data).length;
        if (websocket._socket) websocket._sender._bufferedBytes += length;
        else websocket._bufferedAmount += length;
      }
      if (cb) {
        const err = new Error(
          `WebSocket is not open: readyState ${websocket.readyState} (${readyStates[websocket.readyState]})`
        );
        process.nextTick(cb, err);
      }
    }
    function receiverOnConclude(code, reason) {
      const websocket = this[kWebSocket];
      websocket._closeFrameReceived = true;
      websocket._closeMessage = reason;
      websocket._closeCode = code;
      if (websocket._socket[kWebSocket] === void 0) return;
      websocket._socket.removeListener("data", socketOnData);
      process.nextTick(resume, websocket._socket);
      if (code === 1005) websocket.close();
      else websocket.close(code, reason);
    }
    function receiverOnDrain() {
      const websocket = this[kWebSocket];
      if (!websocket.isPaused) websocket._socket.resume();
    }
    function receiverOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket._socket[kWebSocket] !== void 0) {
        websocket._socket.removeListener("data", socketOnData);
        process.nextTick(resume, websocket._socket);
        websocket.close(err[kStatusCode]);
      }
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function receiverOnFinish() {
      this[kWebSocket].emitClose();
    }
    function receiverOnMessage(data, isBinary) {
      this[kWebSocket].emit("message", data, isBinary);
    }
    function receiverOnPing(data) {
      const websocket = this[kWebSocket];
      if (websocket._autoPong) websocket.pong(data, !this._isServer, NOOP);
      websocket.emit("ping", data);
    }
    function receiverOnPong(data) {
      this[kWebSocket].emit("pong", data);
    }
    function resume(stream) {
      stream.resume();
    }
    function senderOnError(err) {
      const websocket = this[kWebSocket];
      if (websocket.readyState === WebSocket2.CLOSED) return;
      if (websocket.readyState === WebSocket2.OPEN) {
        websocket._readyState = WebSocket2.CLOSING;
        setCloseTimer(websocket);
      }
      this._socket.end();
      if (!websocket._errorEmitted) {
        websocket._errorEmitted = true;
        websocket.emit("error", err);
      }
    }
    function setCloseTimer(websocket) {
      websocket._closeTimer = setTimeout(
        websocket._socket.destroy.bind(websocket._socket),
        websocket._closeTimeout
      );
    }
    function socketOnClose() {
      const websocket = this[kWebSocket];
      this.removeListener("close", socketOnClose);
      this.removeListener("data", socketOnData);
      this.removeListener("end", socketOnEnd);
      websocket._readyState = WebSocket2.CLOSING;
      if (!this._readableState.endEmitted && !websocket._closeFrameReceived && !websocket._receiver._writableState.errorEmitted && this._readableState.length !== 0) {
        const chunk = this.read(this._readableState.length);
        websocket._receiver.write(chunk);
      }
      websocket._receiver.end();
      this[kWebSocket] = void 0;
      clearTimeout(websocket._closeTimer);
      if (websocket._receiver._writableState.finished || websocket._receiver._writableState.errorEmitted) {
        websocket.emitClose();
      } else {
        websocket._receiver.on("error", receiverOnFinish);
        websocket._receiver.on("finish", receiverOnFinish);
      }
    }
    function socketOnData(chunk) {
      if (!this[kWebSocket]._receiver.write(chunk)) {
        this.pause();
      }
    }
    function socketOnEnd() {
      const websocket = this[kWebSocket];
      websocket._readyState = WebSocket2.CLOSING;
      websocket._receiver.end();
      this.end();
    }
    function socketOnError() {
      const websocket = this[kWebSocket];
      this.removeListener("error", socketOnError);
      this.on("error", NOOP);
      if (websocket) {
        websocket._readyState = WebSocket2.CLOSING;
        this.destroy();
      }
    }
  }
});

// node_modules/ws/lib/stream.js
var require_stream = __commonJS({
  "node_modules/ws/lib/stream.js"(exports2, module2) {
    "use strict";
    var WebSocket2 = require_websocket();
    var { Duplex } = require("stream");
    function emitClose(stream) {
      stream.emit("close");
    }
    function duplexOnEnd() {
      if (!this.destroyed && this._writableState.finished) {
        this.destroy();
      }
    }
    function duplexOnError(err) {
      this.removeListener("error", duplexOnError);
      this.destroy();
      if (this.listenerCount("error") === 0) {
        this.emit("error", err);
      }
    }
    function createWebSocketStream2(ws, options) {
      let terminateOnDestroy = true;
      const duplex = new Duplex({
        ...options,
        autoDestroy: false,
        emitClose: false,
        objectMode: false,
        writableObjectMode: false
      });
      ws.on("message", function message(msg, isBinary) {
        const data = !isBinary && duplex._readableState.objectMode ? msg.toString() : msg;
        if (!duplex.push(data)) ws.pause();
      });
      ws.once("error", function error(err) {
        if (duplex.destroyed) return;
        terminateOnDestroy = false;
        duplex.destroy(err);
      });
      ws.once("close", function close() {
        if (duplex.destroyed) return;
        duplex.push(null);
      });
      duplex._destroy = function(err, callback) {
        if (ws.readyState === ws.CLOSED) {
          callback(err);
          process.nextTick(emitClose, duplex);
          return;
        }
        let called = false;
        ws.once("error", function error(err2) {
          called = true;
          callback(err2);
        });
        ws.once("close", function close() {
          if (!called) callback(err);
          process.nextTick(emitClose, duplex);
        });
        if (terminateOnDestroy) ws.terminate();
      };
      duplex._final = function(callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open2() {
            duplex._final(callback);
          });
          return;
        }
        if (ws._socket === null) return;
        if (ws._socket._writableState.finished) {
          callback();
          if (duplex._readableState.endEmitted) duplex.destroy();
        } else {
          ws._socket.once("finish", function finish() {
            callback();
          });
          ws.close();
        }
      };
      duplex._read = function() {
        if (ws.isPaused) ws.resume();
      };
      duplex._write = function(chunk, encoding, callback) {
        if (ws.readyState === ws.CONNECTING) {
          ws.once("open", function open2() {
            duplex._write(chunk, encoding, callback);
          });
          return;
        }
        ws.send(chunk, callback);
      };
      duplex.on("end", duplexOnEnd);
      duplex.on("error", duplexOnError);
      return duplex;
    }
    module2.exports = createWebSocketStream2;
  }
});

// node_modules/ws/lib/subprotocol.js
var require_subprotocol = __commonJS({
  "node_modules/ws/lib/subprotocol.js"(exports2, module2) {
    "use strict";
    var { tokenChars } = require_validation();
    function parse(header) {
      const protocols = /* @__PURE__ */ new Set();
      let start = -1;
      let end = -1;
      let i = 0;
      for (i; i < header.length; i++) {
        const code = header.charCodeAt(i);
        if (end === -1 && tokenChars[code] === 1) {
          if (start === -1) start = i;
        } else if (i !== 0 && (code === 32 || code === 9)) {
          if (end === -1 && start !== -1) end = i;
        } else if (code === 44) {
          if (start === -1) {
            throw new SyntaxError(`Unexpected character at index ${i}`);
          }
          if (end === -1) end = i;
          const protocol2 = header.slice(start, end);
          if (protocols.has(protocol2)) {
            throw new SyntaxError(`The "${protocol2}" subprotocol is duplicated`);
          }
          protocols.add(protocol2);
          start = end = -1;
        } else {
          throw new SyntaxError(`Unexpected character at index ${i}`);
        }
      }
      if (start === -1 || end !== -1) {
        throw new SyntaxError("Unexpected end of input");
      }
      const protocol = header.slice(start, i);
      if (protocols.has(protocol)) {
        throw new SyntaxError(`The "${protocol}" subprotocol is duplicated`);
      }
      protocols.add(protocol);
      return protocols;
    }
    module2.exports = { parse };
  }
});

// node_modules/ws/lib/websocket-server.js
var require_websocket_server = __commonJS({
  "node_modules/ws/lib/websocket-server.js"(exports2, module2) {
    "use strict";
    var EventEmitter = require("events");
    var http = require("http");
    var { Duplex } = require("stream");
    var { createHash: createHash11 } = require("crypto");
    var extension2 = require_extension();
    var PerMessageDeflate2 = require_permessage_deflate();
    var subprotocol2 = require_subprotocol();
    var WebSocket2 = require_websocket();
    var { CLOSE_TIMEOUT, GUID, kWebSocket } = require_constants();
    var keyRegex = /^[+/0-9A-Za-z]{22}==$/;
    var RUNNING = 0;
    var CLOSING = 1;
    var CLOSED = 2;
    var WebSocketServer2 = class extends EventEmitter {
      /**
       * Create a `WebSocketServer` instance.
       *
       * @param {Object} options Configuration options
       * @param {Boolean} [options.allowSynchronousEvents=true] Specifies whether
       *     any of the `'message'`, `'ping'`, and `'pong'` events can be emitted
       *     multiple times in the same tick
       * @param {Boolean} [options.autoPong=true] Specifies whether or not to
       *     automatically send a pong in response to a ping
       * @param {Number} [options.backlog=511] The maximum length of the queue of
       *     pending connections
       * @param {Boolean} [options.clientTracking=true] Specifies whether or not to
       *     track clients
       * @param {Number} [options.closeTimeout=30000] Duration in milliseconds to
       *     wait for the closing handshake to finish after `websocket.close()` is
       *     called
       * @param {Function} [options.handleProtocols] A hook to handle protocols
       * @param {String} [options.host] The hostname where to bind the server
       * @param {Number} [options.maxBufferedChunks=262144] The maximum number of
       *     buffered data chunks
       * @param {Number} [options.maxFragments=16384] The maximum number of message
       *     fragments
       * @param {Number} [options.maxPayload=104857600] The maximum allowed message
       *     size
       * @param {Boolean} [options.noServer=false] Enable no server mode
       * @param {String} [options.path] Accept only connections matching this path
       * @param {(Boolean|Object)} [options.perMessageDeflate=false] Enable/disable
       *     permessage-deflate
       * @param {Number} [options.port] The port where to bind the server
       * @param {(http.Server|https.Server)} [options.server] A pre-created HTTP/S
       *     server to use
       * @param {Boolean} [options.skipUTF8Validation=false] Specifies whether or
       *     not to skip UTF-8 validation for text and close messages
       * @param {Function} [options.verifyClient] A hook to reject connections
       * @param {Function} [options.WebSocket=WebSocket] Specifies the `WebSocket`
       *     class to use. It must be the `WebSocket` class or class that extends it
       * @param {Function} [callback] A listener for the `listening` event
       */
      constructor(options, callback) {
        super();
        options = {
          allowSynchronousEvents: true,
          autoPong: true,
          maxBufferedChunks: 256 * 1024,
          maxFragments: 16 * 1024,
          maxPayload: 100 * 1024 * 1024,
          skipUTF8Validation: false,
          perMessageDeflate: false,
          handleProtocols: null,
          clientTracking: true,
          closeTimeout: CLOSE_TIMEOUT,
          verifyClient: null,
          noServer: false,
          backlog: null,
          // use default (511 as implemented in net.js)
          server: null,
          host: null,
          path: null,
          port: null,
          WebSocket: WebSocket2,
          ...options
        };
        if (options.port == null && !options.server && !options.noServer || options.port != null && (options.server || options.noServer) || options.server && options.noServer) {
          throw new TypeError(
            'One and only one of the "port", "server", or "noServer" options must be specified'
          );
        }
        if (options.port != null) {
          this._server = http.createServer((req, res) => {
            const body = http.STATUS_CODES[426];
            res.writeHead(426, {
              "Content-Length": body.length,
              "Content-Type": "text/plain"
            });
            res.end(body);
          });
          this._server.listen(
            options.port,
            options.host,
            options.backlog,
            callback
          );
        } else if (options.server) {
          this._server = options.server;
        }
        if (this._server) {
          const emitConnection = this.emit.bind(this, "connection");
          this._removeListeners = addListeners(this._server, {
            listening: this.emit.bind(this, "listening"),
            error: this.emit.bind(this, "error"),
            upgrade: (req, socket, head) => {
              this.handleUpgrade(req, socket, head, emitConnection);
            }
          });
        }
        if (options.perMessageDeflate === true) options.perMessageDeflate = {};
        if (options.clientTracking) {
          this.clients = /* @__PURE__ */ new Set();
          this._shouldEmitClose = false;
        }
        this.options = options;
        this._state = RUNNING;
      }
      /**
       * Returns the bound address, the address family name, and port of the server
       * as reported by the operating system if listening on an IP socket.
       * If the server is listening on a pipe or UNIX domain socket, the name is
       * returned as a string.
       *
       * @return {(Object|String|null)} The address of the server
       * @public
       */
      address() {
        if (this.options.noServer) {
          throw new Error('The server is operating in "noServer" mode');
        }
        if (!this._server) return null;
        return this._server.address();
      }
      /**
       * Stop the server from accepting new connections and emit the `'close'` event
       * when all existing connections are closed.
       *
       * @param {Function} [cb] A one-time listener for the `'close'` event
       * @public
       */
      close(cb) {
        if (this._state === CLOSED) {
          if (cb) {
            this.once("close", () => {
              cb(new Error("The server is not running"));
            });
          }
          process.nextTick(emitClose, this);
          return;
        }
        if (cb) this.once("close", cb);
        if (this._state === CLOSING) return;
        this._state = CLOSING;
        if (this.options.noServer || this.options.server) {
          if (this._server) {
            this._removeListeners();
            this._removeListeners = this._server = null;
          }
          if (this.clients) {
            if (!this.clients.size) {
              process.nextTick(emitClose, this);
            } else {
              this._shouldEmitClose = true;
            }
          } else {
            process.nextTick(emitClose, this);
          }
        } else {
          const server = this._server;
          this._removeListeners();
          this._removeListeners = this._server = null;
          server.close(() => {
            emitClose(this);
          });
        }
      }
      /**
       * See if a given request should be handled by this server instance.
       *
       * @param {http.IncomingMessage} req Request object to inspect
       * @return {Boolean} `true` if the request is valid, else `false`
       * @public
       */
      shouldHandle(req) {
        if (this.options.path) {
          const index = req.url.indexOf("?");
          const pathname = index !== -1 ? req.url.slice(0, index) : req.url;
          if (pathname !== this.options.path) return false;
        }
        return true;
      }
      /**
       * Handle a HTTP Upgrade request.
       *
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @public
       */
      handleUpgrade(req, socket, head, cb) {
        socket.on("error", socketOnError);
        const key = req.headers["sec-websocket-key"];
        const upgrade = req.headers.upgrade;
        const version = +req.headers["sec-websocket-version"];
        if (req.method !== "GET") {
          const message = "Invalid HTTP method";
          abortHandshakeOrEmitwsClientError(this, req, socket, 405, message);
          return;
        }
        if (upgrade === void 0 || upgrade.toLowerCase() !== "websocket") {
          const message = "Invalid Upgrade header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (key === void 0 || !keyRegex.test(key)) {
          const message = "Missing or invalid Sec-WebSocket-Key header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
          return;
        }
        if (version !== 13 && version !== 8) {
          const message = "Missing or invalid Sec-WebSocket-Version header";
          abortHandshakeOrEmitwsClientError(this, req, socket, 400, message, {
            "Sec-WebSocket-Version": "13, 8"
          });
          return;
        }
        if (!this.shouldHandle(req)) {
          abortHandshake(socket, 400);
          return;
        }
        const secWebSocketProtocol = req.headers["sec-websocket-protocol"];
        let protocols = /* @__PURE__ */ new Set();
        if (secWebSocketProtocol !== void 0) {
          try {
            protocols = subprotocol2.parse(secWebSocketProtocol);
          } catch (err) {
            const message = "Invalid Sec-WebSocket-Protocol header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        const secWebSocketExtensions = req.headers["sec-websocket-extensions"];
        const extensions = {};
        if (this.options.perMessageDeflate && secWebSocketExtensions !== void 0) {
          const perMessageDeflate = new PerMessageDeflate2({
            ...this.options.perMessageDeflate,
            isServer: true,
            maxPayload: this.options.maxPayload
          });
          try {
            const offers = extension2.parse(secWebSocketExtensions);
            if (offers[PerMessageDeflate2.extensionName]) {
              perMessageDeflate.accept(offers[PerMessageDeflate2.extensionName]);
              extensions[PerMessageDeflate2.extensionName] = perMessageDeflate;
            }
          } catch (err) {
            const message = "Invalid or unacceptable Sec-WebSocket-Extensions header";
            abortHandshakeOrEmitwsClientError(this, req, socket, 400, message);
            return;
          }
        }
        if (this.options.verifyClient) {
          const info = {
            origin: req.headers[`${version === 8 ? "sec-websocket-origin" : "origin"}`],
            secure: !!(req.socket.authorized || req.socket.encrypted),
            req
          };
          if (this.options.verifyClient.length === 2) {
            this.options.verifyClient(info, (verified, code, message, headers) => {
              if (!verified) {
                return abortHandshake(socket, code || 401, message, headers);
              }
              this.completeUpgrade(
                extensions,
                key,
                protocols,
                req,
                socket,
                head,
                cb
              );
            });
            return;
          }
          if (!this.options.verifyClient(info)) return abortHandshake(socket, 401);
        }
        this.completeUpgrade(extensions, key, protocols, req, socket, head, cb);
      }
      /**
       * Upgrade the connection to WebSocket.
       *
       * @param {Object} extensions The accepted extensions
       * @param {String} key The value of the `Sec-WebSocket-Key` header
       * @param {Set} protocols The subprotocols
       * @param {http.IncomingMessage} req The request object
       * @param {Duplex} socket The network socket between the server and client
       * @param {Buffer} head The first packet of the upgraded stream
       * @param {Function} cb Callback
       * @throws {Error} If called more than once with the same socket
       * @private
       */
      completeUpgrade(extensions, key, protocols, req, socket, head, cb) {
        if (!socket.readable || !socket.writable) return socket.destroy();
        if (socket[kWebSocket]) {
          throw new Error(
            "server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration"
          );
        }
        if (this._state > RUNNING) return abortHandshake(socket, 503);
        const digest3 = createHash11("sha1").update(key + GUID).digest("base64");
        const headers = [
          "HTTP/1.1 101 Switching Protocols",
          "Upgrade: websocket",
          "Connection: Upgrade",
          `Sec-WebSocket-Accept: ${digest3}`
        ];
        const ws = new this.options.WebSocket(null, void 0, this.options);
        if (protocols.size) {
          const protocol = this.options.handleProtocols ? this.options.handleProtocols(protocols, req) : protocols.values().next().value;
          if (protocol) {
            headers.push(`Sec-WebSocket-Protocol: ${protocol}`);
            ws._protocol = protocol;
          }
        }
        if (extensions[PerMessageDeflate2.extensionName]) {
          const params = extensions[PerMessageDeflate2.extensionName].params;
          const value = extension2.format({
            [PerMessageDeflate2.extensionName]: [params]
          });
          headers.push(`Sec-WebSocket-Extensions: ${value}`);
          ws._extensions = extensions;
        }
        this.emit("headers", headers, req);
        socket.write(headers.concat("\r\n").join("\r\n"));
        socket.removeListener("error", socketOnError);
        ws.setSocket(socket, head, {
          allowSynchronousEvents: this.options.allowSynchronousEvents,
          maxBufferedChunks: this.options.maxBufferedChunks,
          maxFragments: this.options.maxFragments,
          maxPayload: this.options.maxPayload,
          skipUTF8Validation: this.options.skipUTF8Validation
        });
        if (this.clients) {
          this.clients.add(ws);
          ws.on("close", () => {
            this.clients.delete(ws);
            if (this._shouldEmitClose && !this.clients.size) {
              process.nextTick(emitClose, this);
            }
          });
        }
        cb(ws, req);
      }
    };
    module2.exports = WebSocketServer2;
    function addListeners(server, map) {
      for (const event of Object.keys(map)) server.on(event, map[event]);
      return function removeListeners() {
        for (const event of Object.keys(map)) {
          server.removeListener(event, map[event]);
        }
      };
    }
    function emitClose(server) {
      server._state = CLOSED;
      server.emit("close");
    }
    function socketOnError() {
      this.destroy();
    }
    function abortHandshake(socket, code, message, headers) {
      message = message || http.STATUS_CODES[code];
      headers = {
        Connection: "close",
        "Content-Type": "text/html",
        "Content-Length": Buffer.byteLength(message),
        ...headers
      };
      socket.once("finish", socket.destroy);
      socket.end(
        `HTTP/1.1 ${code} ${http.STATUS_CODES[code]}\r
` + Object.keys(headers).map((h) => `${h}: ${headers[h]}`).join("\r\n") + "\r\n\r\n" + message
      );
    }
    function abortHandshakeOrEmitwsClientError(server, req, socket, code, message, headers) {
      if (server.listenerCount("wsClientError")) {
        const err = new Error(message);
        Error.captureStackTrace(err, abortHandshakeOrEmitwsClientError);
        server.emit("wsClientError", err, socket, req);
      } else {
        abortHandshake(socket, code, message, headers);
      }
    }
  }
});

// src/provider-kit/index.ts
var index_exports = {};
__export(index_exports, {
  AgentHostAdapter: () => AgentHostAdapter,
  NativeTaskRunner: () => NativeTaskRunner,
  NativeTransportFacade: () => NativeTransportFacade,
  ahpHash: () => ahpHash,
  ahpTextHash: () => ahpTextHash,
  captureConfiguration: () => captureConfiguration,
  captureNativeStartupManifest: () => captureNativeStartupManifest,
  createHeadlessNativeHost: () => createHeadlessNativeHost,
  defaultHomes: () => defaultHomes,
  hashOk: () => hashOk2,
  mafActionHash: () => mafActionHash,
  mafRuntimeHash: () => mafRuntimeHash,
  nativeEnvironment: () => nativeEnvironment,
  nativeHash: () => nativeHash,
  nativeIdOk: () => nativeIdOk,
  nativeLaunchArguments: () => nativeLaunchArguments,
  nativeSelectionBinding: () => nativeSelectionBinding,
  nativeStartupReviewHash: () => nativeStartupReviewHash,
  nativeToolPolicy: () => nativeToolPolicy,
  nativeTransportVersion: () => nativeTransportVersion,
  preflightNativeTransport: () => preflightNativeTransport,
  prepareNativeTask: () => prepareNativeTask,
  providerKitSchema: () => providerKitSchema,
  providerKitVersion: () => providerKitVersion,
  qualifiedAHPEfforts: () => qualifiedAHPEfforts,
  readNativeRepositoryIdentity: () => readNativeRepositoryIdentity,
  safeLocalSource: () => safeLocalSource,
  selectedEndpointHost: () => selectedEndpointHost,
  validateMafAction: () => validateMafAction,
  validateNativePlatformVerifier: () => validateNativePlatformVerifier,
  validateNativeSelection: () => validateNativeSelection,
  validateSelectedEndpoint: () => validateSelectedEndpoint,
  verifyAHPProject: () => verifyAHPProject,
  verifyMafRuntime: () => verifyMafRuntime,
  verifyNativePlatformProof: () => verifyNativePlatformProof,
  verifyNativeProjectScope: () => verifyNativeProjectScope
});
module.exports = __toCommonJS(index_exports);

// src/cockpit/configuration.ts
var fs5 = __toESM(require("node:fs/promises"));
var path6 = __toESM(require("node:path"));

// src/feeds/settings.ts
var fs2 = __toESM(require("fs"));
var os = __toESM(require("os"));
var path2 = __toESM(require("path"));

// src/util/redact.ts
var MARK = "[REDACTED]";
var NAME_CORE = "token|secret|passw(?:or)?d|pwd|passphrase|api[_-]?key|access[_-]?key|private[_-]?key|account[_-]?key|shared[_-]?access[_-]?(?:key|signature)|subscription[_-]?key|client[_-]?secret|credentials?|session[_-]?(?:id|token|key)|cookie|auth[_-]?(?:token|key|code)|signing[_-]?key|encryption[_-]?key|conn(?:ection)?[_-]?string|[_-]key";
var NAME = `[A-Za-z0-9_.-]{0,40}(?:${NAME_CORE})[A-Za-z0-9_.-]{0,40}`;
var NAME_RE = new RegExp(`^(?:${NAME})$`, "i");
var COUNT_NAME = /tokens|_count$/i;
var VALUE = `(\\\\"(?:(?!\\\\")[^\\n])*\\\\"|"(?:[^"\\\\\\n]|\\\\.)*"|'[^'\\n]*'|(?![{\\[])[^\\s,;}\\]&"'\\\\<>]+)`;
function keyValue(m, pre, name2, value) {
  if (COUNT_NAME.test(name2) && /^\\?["']?\d{1,12}\\?["']?$/.test(value)) return m;
  if (value.startsWith('\\"')) return `${pre}\\"${MARK}\\"`;
  if (value.startsWith('"')) return `${pre}"${MARK}"`;
  if (value.startsWith("'")) return `${pre}'${MARK}'`;
  return `${pre}${MARK}`;
}
var quoted = (v) => v.startsWith('"') ? `"${MARK}"` : v.startsWith("'") ? `'${MARK}'` : MARK;
var RULES = [
  // PEM private keys (RSA / EC / OPENSSH / ENCRYPTED / PGP ... BLOCK), real or JSON-escaped newlines; a block cut
  // by truncation (no END line) is redacted to the end of the text.
  { re: /-----BEGIN [A-Z0-9 ]{0,40}PRIVATE KEY[A-Z ]{0,10}-----[\s\S]*?(?:-----END [A-Z0-9 ]{0,40}PRIVATE KEY[A-Z ]{0,10}-----|$)/g },
  // AWS secret access key without a label, on the same line as an access key id or the word "aws".
  {
    // Without a 40-character candidate, repeated "aws " would each search the next 160 characters.
    // This single linear scan cannot exclude anything the full rule could match.
    requires: /[A-Za-z0-9/+]{40}/,
    re: /(\b(?:AKIA|ASIA)[0-9A-Z]{16}\b|\baws\b)([^\n]{0,160}?)(?<![A-Za-z0-9/+])([A-Za-z0-9/+]{40})(?![A-Za-z0-9/+=])/gi,
    to: (m, a, mid, s2) => /[A-Z]/.test(s2) && /[a-z]/.test(s2) ? `${a}${mid}${MARK}` : m
  },
  // Token formats.
  { re: /\bsk-ant-[A-Za-z0-9_-]{8,}/g },
  { re: /\b(?:sk|pk|rk)-[A-Za-z0-9_-]{12,}/g },
  // OpenAI (sk-, sk-proj-) and similar
  { re: /\b(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{10,}/g },
  // Stripe
  { re: /\bgithub_pat_[A-Za-z0-9_]{20,}/g },
  // GitHub fine-grained PAT
  { re: /\bgh[pousr]_[A-Za-z0-9]{20,}/g },
  // GitHub classic tokens
  { re: /\bglpat-[A-Za-z0-9_-]{16,}/g },
  // GitLab
  { re: /\bnpm_[A-Za-z0-9]{30,}/g },
  // npm
  { re: /\bAIza[0-9A-Za-z_-]{30,}/g },
  // Google API key
  { re: /\bya29\.[0-9A-Za-z_-]{20,}/g },
  // Google OAuth access token
  { re: /\bxox[abprse]-[A-Za-z0-9-]{10,}/g },
  // Slack
  { re: /\bxapp-[A-Za-z0-9-]{10,}/g },
  // Slack app token
  { re: /\b(?:AKIA|ASIA)[0-9A-Z]{16}\b/g },
  // AWS access key id
  { re: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/g },
  // JWT
  // Authorization headers ("Bearer xyz" / "Basic xyz" / quoted JSON value).
  {
    re: /\b((?:proxy-)?authorization["']?\s*[:=]\s*)("(?:[^"\\\n]|\\.)*"|'[^'\n]*'|[^\s,;"']+(?:[ \t]+[^\s,;"']+)?)/gi,
    to: (_m, pre, v) => `${pre}${quoted(v)}`
  },
  // Secret headers: curl -H "x-api-key: ...", Cookie: a=b; c=d, Ocp-Apim-Subscription-Key: ...
  {
    re: /\b((?:x-api-key|api-key|x-auth-token|x-goog-api-key|ocp-apim-subscription-key|set-cookie|cookie)[ \t]*:[ \t]*)(?!["'\\])[^\r\n"'\\]+/gi,
    to: (_m, pre) => `${pre}${MARK}`
  },
  { re: /\b(bearer|basic)\s+[A-Za-z0-9._~+/-]{12,}=*/gi, to: (_m, kind) => `${kind} ${MARK}` },
  // Query-string secrets, also after &amp; in HTML-encoded URLs.
  {
    re: /([?&](?:amp;)?(?:key|sig|signature|code|auth|password|pwd|passwd|token|access_token|refresh_token|id_token|api_key|apikey|secret|client_secret|x-amz-signature|x-amz-credential|x-amz-security-token)=)[^&\s#"'<>]+/gi,
    to: (_m, pre) => `${pre}${MARK}`
  },
  // Credentials in URLs; the password may contain '@' (user:p@ss@host): it runs to the last '@' before the host.
  { re: /(:\/\/[^/\s:@]+:)[^\s/]*@(?=[^@\s/]*(?:[/?#\s"'<>]|$))/g, to: (_m, pre) => `${pre}${MARK}@` },
  // name = value / "name": "value" / name: value (env, JSON, escaped JSON, YAML, TOML, connection strings).
  {
    re: new RegExp(`(?<![A-Za-z0-9_.-])((\\\\?["']?)(${NAME})\\\\?["']?(\\s*[:=]\\s*))${VALUE}`, "gi"),
    to: (m, pre, _q, name2, _sep, value) => keyValue(m, pre, name2, value)
  },
  // CLI flags: --password x, --token=x, -password x.
  { re: /(--?(?:password|passwd|pwd|token|secret|api-key|apikey|access-token|auth-token|client-secret)[= ])(\S+)/gi, to: (_m, pre) => `${pre}${MARK}` },
  // mysql-family -p<password> / -p <password> (only after a mysql command on the same line: -p means other things elsewhere).
  { re: /(\b(?:mysql|mysqldump|mysqladmin|mariadb|mariadb-dump)\b[^\n|;&]{0,200}?\s-p)([ \t]*)(?!-)(\S+)/g, to: (_m, pre, sp) => `${pre}${sp}${MARK}` }
];
function redact(text) {
  if (typeof text !== "string") return "";
  if (!text) return text;
  let out = text;
  for (const r of RULES) {
    if (r.requires && !r.requires.test(out)) continue;
    out = out.replace(r.re, (m, ...g) => r.to ? r.to(m, ...g) : MARK);
  }
  for (const re of [
    /sk-[A-Za-z0-9_-]{20,}/g,
    /gh[pousr]_[A-Za-z0-9]{20,}/g,
    /github_pat_[A-Za-z0-9_]{20,}/g,
    /AKIA[0-9A-Z]{16}/g,
    /xox[baprs]-[A-Za-z0-9-]{10,}/g,
    /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{5,}/g
  ]) out = out.replace(re, MARK);
  return out;
}
function bounded(text, max = 100) {
  if (typeof text !== "string") return "";
  const one = redact(text).replace(/\s+/g, " ").trim();
  return one.length > max ? one.slice(0, max - 1) + "\u2026" : one;
}
function boundedMultiline(text, max = 32 * 1024) {
  if (typeof text !== "string") return "";
  const safe = redact(text), bytes = Buffer.from(safe);
  return bytes.length <= max ? safe : bytes.subarray(0, Math.max(0, max - 3)).toString("utf8").replace(/\uFFFD$/, "") + "\u2026";
}
var ENV_ALLOW_LIST = ["USERPROFILE", "HOME", "CODEX_HOME", "CLAUDE_CONFIG_DIR"];
function safeEnv(env = process.env) {
  const out = {};
  for (const k of ENV_ALLOW_LIST) if (typeof env[k] === "string") out[k] = env[k];
  return out;
}
var CREDENTIAL_FILE = /(^|[\\/])(\.credentials\.jsonl?|auth\.jsonl?|credentials(\.jsonl?)?|(?:tokens?|cookies?|secrets?)\.jsonl?|\.netrc|_netrc|\.npmrc|\.pypirc|\.git-credentials|\.env(\..*)?|id_(rsa|dsa|ecdsa|ed25519)|[^\\/]*\.(pem|key|pfx|p12))$/i;
function isCredentialPath(file) {
  return typeof file === "string" && CREDENTIAL_FILE.test(file.replace(/[\\/]+$/, ""));
}

// src/util/paths.ts
var fs = __toESM(require("fs"));
var path = __toESM(require("path"));
function isPlausibleLocalPath(p) {
  if (typeof p !== "string" || p.length === 0 || p.length > 1024) return false;
  if (p.includes("\0")) return false;
  if (/^\\\\[?.]\\/.test(p)) return false;
  if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(p)) return false;
  return path.isAbsolute(p);
}
function normalizeCase(p) {
  return process.platform === "win32" ? p.replace(/\//g, "\\").toLowerCase() : p;
}
function hasLinkedAncestor(file) {
  try {
    for (let p = file; p !== path.dirname(p); p = path.dirname(p)) if (fs.lstatSync(p).isSymbolicLink()) return true;
    return false;
  } catch {
    return true;
  }
}

// src/feeds/settings.ts
var LAYER_ORDER = ["managed", "local", "project", "user"];
var MAX_BYTES = 1e6;
var MAX_ROOTS = 60;
var MAX_LIST = 200;
var FORBIDDEN = /(^|[\\/])(\.credentials\.json|auth\.json|\.env(\..*)?|.*\.pem|.*\.key)$/i;
var SECRET_NAME = /(token|secret|passw|api_?key|apikey|access_?key|private|credential|auth|bearer|cookie|session_?id)/i;
function isForbidden(file) {
  return FORBIDDEN.test(file);
}
function defaultHomes() {
  const env = safeEnv();
  const home = env.USERPROFILE ?? env.HOME ?? os.homedir();
  return {
    claudeHome: env.CLAUDE_CONFIG_DIR ?? path2.join(home, ".claude"),
    codexHome: env.CODEX_HOME ?? path2.join(home, ".codex"),
    managedFile: process.platform === "win32" ? "C:\\Program Files\\ClaudeCode\\managed-settings.json" : process.platform === "darwin" ? "/Library/Application Support/ClaudeCode/managed-settings.json" : "/etc/claude-code/managed-settings.json"
  };
}
function stat(file) {
  if (hasLinkedAncestor(file)) return void 0;
  try {
    return fs2.statSync(file);
  } catch {
    return void 0;
  }
}
function readSmall(file) {
  if (isForbidden(file)) return { error: "not read (credential file)" };
  const st = stat(file);
  if (!st || !st.isFile()) return {};
  if (st.size > MAX_BYTES) return { st, error: `too large (${st.size} bytes)` };
  try {
    return { text: fs2.readFileSync(file, "utf8"), st };
  } catch (e) {
    return { st, error: String(e.message ?? e).slice(0, 120) };
  }
}
var str = (v, max = 80) => typeof v === "string" && v.trim() ? bounded(v, max) : void 0;
var strArr = (v) => Array.isArray(v) ? v.filter((x) => typeof x === "string").slice(0, MAX_LIST).map((x) => bounded(x, 140)) : [];
function parseJsonLoose(text) {
  try {
    return JSON.parse(text);
  } catch {
    const noComments = text.replace(/("(?:\\.|[^"\\])*")|\/\/[^\n]*|\/\*[\s\S]*?\*\//g, (m, s2) => s2 ?? "");
    return JSON.parse(noComments.replace(/,(\s*[}\]])/g, "$1"));
  }
}
function hooksOf(v) {
  const out = [];
  if (!v || typeof v !== "object") return out;
  for (const [event, groups] of Object.entries(v)) {
    if (!Array.isArray(groups)) continue;
    for (const g of groups) {
      if (!g || typeof g !== "object") continue;
      const matcher = str(g.matcher, 60) ?? "";
      const hs = g.hooks;
      for (const h of Array.isArray(hs) ? hs : []) {
        if (!h || typeof h !== "object") continue;
        const r = h;
        const args = Array.isArray(r.args) ? r.args.filter((a) => typeof a === "string").map((a) => /\s/.test(a) ? `"${a}"` : a) : [];
        const command = typeof r.command === "string" ? str([r.command, ...args].join(" "), 160) : void 0;
        out.push({ event: bounded(event, 40), matcher, type: str(r.type, 20) ?? "command", command: command ?? str(r.url, 160) ?? (typeof r.prompt === "string" ? "prompt" : ""), timeout: typeof r.timeout === "number" ? r.timeout : void 0 });
        if (out.length >= MAX_LIST) return out;
      }
    }
  }
  return out;
}
var KNOWN_CLAUDE = /* @__PURE__ */ new Set(["model", "effortLevel", "permissions", "hooks", "outputStyle", "statusLine", "env", "enabledPlugins", "apiKeyHelper"]);
function readClaudeLayer(kind, file, root) {
  const layer = { kind, root, file, exists: false, allow: [], deny: [], ask: [], additionalDirectories: 0, hooks: [], envNames: [], envHidden: 0, enabledPlugins: [], otherKeys: [], apiKeyHelper: false };
  const { text, st, error } = readSmall(file);
  if (st) Object.assign(layer, { exists: true, bytes: st.size, mtime: st.mtimeMs });
  if (error) layer.error = error;
  if (text === void 0) return layer;
  let j;
  try {
    j = parseJsonLoose(text);
  } catch (e) {
    layer.error = `invalid JSON: ${bounded(String(e.message ?? e), 80)}`;
    return layer;
  }
  if (!j || typeof j !== "object" || Array.isArray(j)) {
    layer.error = "not a JSON object";
    return layer;
  }
  const o = j;
  layer.model = str(o.model);
  layer.effortLevel = str(o.effortLevel, 20);
  layer.outputStyle = str(o.outputStyle, 40);
  const p = o.permissions && typeof o.permissions === "object" ? o.permissions : {};
  layer.defaultMode = str(p.defaultMode, 30);
  layer.allow = strArr(p.allow);
  layer.deny = strArr(p.deny);
  layer.ask = strArr(p.ask);
  layer.additionalDirectories = Array.isArray(p.additionalDirectories) ? p.additionalDirectories.length : 0;
  layer.hooks = hooksOf(o.hooks);
  const sl = o.statusLine;
  if (sl && typeof sl === "object") layer.statusLine = str(sl.command, 120) ? `command: ${str(sl.command, 120)}` : "set";
  else if (typeof sl === "string") layer.statusLine = bounded(sl, 120);
  if (o.env && typeof o.env === "object") {
    for (const k of Object.keys(o.env)) {
      if (SECRET_NAME.test(k)) layer.envHidden++;
      else if (layer.envNames.length < 50) layer.envNames.push(bounded(k, 60));
    }
  }
  if (o.enabledPlugins && typeof o.enabledPlugins === "object") {
    layer.enabledPlugins = Object.entries(o.enabledPlugins).filter(([, v]) => v !== false).map(([k]) => bounded(k, 80)).slice(0, MAX_LIST);
  }
  layer.apiKeyHelper = o.apiKeyHelper !== void 0;
  layer.otherKeys = Object.keys(o).filter((k) => !KNOWN_CLAUDE.has(k)).map((k) => SECRET_NAME.test(k) ? "(hidden key)" : bounded(k, 50)).slice(0, 60);
  return layer;
}
function frontMatter(text) {
  const m = /^\uFEFF?---\r?\n([\s\S]*?)\r?\n---/.exec(text);
  const out = {};
  if (!m) return out;
  const lines = m[1].split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const kv = /^([A-Za-z][\w-]*):\s*(.*)$/.exec(lines[i]);
    if (!kv) continue;
    let v = kv[2].trim();
    if (v === "" || v === "|" || v === ">" || v === "|-" || v === ">-") {
      const parts = [];
      while (i + 1 < lines.length && /^\s+\S/.test(lines[i + 1])) parts.push(lines[++i].trim().replace(/^-\s*/, ""));
      v = parts.join(v.startsWith("|") || v.startsWith(">") ? " " : ", ");
    }
    out[kv[1]] = v.replace(/^["']|["']$/g, "");
  }
  return out;
}
function listMd(dir, kind, scope, root, out) {
  let names;
  try {
    names = fs2.readdirSync(dir);
  } catch {
    return;
  }
  for (const n of names.sort()) {
    if (out.length >= 2e3) return;
    let file = path2.join(dir, n);
    const st = stat(file);
    if (!st) continue;
    if (kind === "skill") {
      if (!st.isDirectory()) continue;
      file = path2.join(file, "SKILL.md");
      if (!stat(file)) {
        let sub = [];
        try {
          sub = fs2.readdirSync(path2.join(dir, n));
        } catch {
        }
        for (const s2 of sub.slice(0, 50)) {
          const f = path2.join(dir, n, s2, "SKILL.md");
          if (stat(f)) pushMd(f, kind, scope, root, out, `${n}/${s2}`);
        }
        continue;
      }
      pushMd(file, kind, scope, root, out, n);
    } else if (st.isFile() && n.toLowerCase().endsWith(".md")) pushMd(file, kind, scope, root, out, n.replace(/\.md$/i, ""));
    else if (kind === "command" && st.isDirectory()) {
      let sub = [];
      try {
        sub = fs2.readdirSync(file);
      } catch {
      }
      for (const s2 of sub.filter((x) => x.toLowerCase().endsWith(".md")).slice(0, 100)) pushMd(path2.join(file, s2), kind, scope, root, out, `${n}:${s2.replace(/\.md$/i, "")}`);
    }
  }
}
function pushMd(file, kind, scope, root, out, fallback) {
  const { text, st } = readSmall(file);
  const fm = text ? frontMatter(text) : {};
  out.push({
    kind,
    scope,
    root,
    file,
    name: bounded(fm.name || fallback, 60),
    description: fm.description ? bounded(fm.description, 180) : void 0,
    model: fm.model ? bounded(fm.model, 40) : void 0,
    effort: fm.effort ? bounded(fm.effort, 20) : void 0,
    tools: fm.tools || fm["allowed-tools"] ? bounded(fm.tools || fm["allowed-tools"], 140) : void 0,
    mtime: st?.mtimeMs
  });
}
function memory(file, provider, scope, root, out) {
  const st = stat(file);
  if (!st || !st.isFile()) return;
  let lines = 0;
  if (st.size <= MAX_BYTES) {
    try {
      lines = fs2.readFileSync(file, "utf8").split("\n").length;
    } catch {
    }
  }
  out.push({ provider, scope, root, file, bytes: st.size, mtime: st.mtimeMs, lines });
}
function splitKey(s2) {
  const parts = [];
  let cur = "";
  let q;
  for (let i = 0; i < s2.length; i++) {
    const c = s2[i];
    if (q) {
      if (c === q) q = void 0;
      else if (c === "\\" && q === '"' && i + 1 < s2.length) cur += s2[++i];
      else cur += c;
    } else if (c === '"' || c === "'") q = c;
    else if (c === ".") {
      parts.push(cur.trim());
      cur = "";
    } else cur += c;
  }
  parts.push(cur.trim());
  return parts.filter((p) => p !== "");
}
function parseValue(s2, i) {
  while (s2[i] === " " || s2[i] === "	") i++;
  const c = s2[i];
  if (s2.startsWith('"""', i) || s2.startsWith("'''", i)) {
    const q = s2.slice(i, i + 3);
    const end = s2.indexOf(q, i + 3);
    const e = end < 0 ? s2.length : end;
    return [s2.slice(i + 3, e).replace(/^\r?\n/, ""), e + 3];
  }
  if (c === '"') {
    let out = "";
    let j = i + 1;
    for (; j < s2.length && s2[j] !== '"'; j++) {
      if (s2[j] === "\\" && j + 1 < s2.length) {
        const n = s2[++j];
        out += n === "n" ? "\n" : n === "t" ? "	" : n;
      } else out += s2[j];
    }
    return [out, j + 1];
  }
  if (c === "'") {
    const e = s2.indexOf("'", i + 1);
    return [s2.slice(i + 1, e < 0 ? s2.length : e), (e < 0 ? s2.length : e) + 1];
  }
  if (c === "[") {
    const arr = [];
    let j = i + 1;
    for (; ; ) {
      while (j < s2.length && /[\s,]/.test(s2[j])) j++;
      if (s2[j] === "#") {
        while (j < s2.length && s2[j] !== "\n") j++;
        continue;
      }
      if (j >= s2.length || s2[j] === "]") return [arr, j + 1];
      const [v2, n] = parseValue(s2, j);
      arr.push(v2);
      j = n;
    }
  }
  if (c === "{") {
    const obj2 = {};
    let j = i + 1;
    for (; ; ) {
      while (j < s2.length && /[\s,]/.test(s2[j])) j++;
      if (j >= s2.length || s2[j] === "}") return [obj2, j + 1];
      const eq = s2.indexOf("=", j);
      if (eq < 0) return [obj2, s2.length];
      const key = splitKey(s2.slice(j, eq));
      const [v2, n] = parseValue(s2, eq + 1);
      setPath(obj2, key, v2);
      j = n;
    }
  }
  const m = /^[^,\]}\r\n#]*/.exec(s2.slice(i))[0];
  const raw = m.trim();
  const v = raw === "true" ? true : raw === "false" ? false : /^[+-]?\d[\d_]*(\.\d+)?$/.test(raw) ? Number(raw.replace(/_/g, "")) : raw;
  return [v, i + m.length];
}
function setPath(obj2, keys, v) {
  let o = obj2;
  for (const k of keys.slice(0, -1)) {
    const cur = o[k];
    if (!cur || typeof cur !== "object" || Array.isArray(cur)) o[k] = {};
    o = o[k];
  }
  o[keys[keys.length - 1]] = v;
}
function parseToml(text) {
  const root = {};
  let table = [];
  let i = 0;
  const s2 = text.replace(/^\uFEFF/, "");
  while (i < s2.length) {
    while (i < s2.length && /\s/.test(s2[i])) i++;
    if (i >= s2.length) break;
    if (s2[i] === "#") {
      while (i < s2.length && s2[i] !== "\n") i++;
      continue;
    }
    if (s2[i] === "[") {
      const arrayTable = s2[i + 1] === "[";
      const end = s2.indexOf(arrayTable ? "]]" : "]", i);
      const header = s2.slice(i + (arrayTable ? 2 : 1), end < 0 ? s2.length : end);
      table = splitKey(header);
      if (arrayTable) table = [...table, String(Date.now() + i)];
      setPath(root, table, {});
      i = (end < 0 ? s2.length : end) + (arrayTable ? 2 : 1);
      continue;
    }
    const eq = s2.indexOf("=", i);
    const nl = s2.indexOf("\n", i);
    if (eq < 0 || nl >= 0 && nl < eq) {
      i = nl < 0 ? s2.length : nl + 1;
      continue;
    }
    const key = splitKey(s2.slice(i, eq));
    const [v, n] = parseValue(s2, eq + 1);
    if (key.length) setPath(root, [...table, ...key], v);
    i = n;
    while (i < s2.length && s2[i] !== "\n") i++;
  }
  return root;
}
var tstr = (v, max = 60) => typeof v === "string" && v ? bounded(v, max) : void 0;
var ttab = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var KNOWN_CODEX = /* @__PURE__ */ new Set(["model", "model_reasoning_effort", "approval_policy", "sandbox_mode", "sandbox", "service_tier", "profile", "profiles", "mcp_servers", "notify", "features", "projects", "plugins"]);
function readCodexConfig(file, scope, root) {
  const c = { scope, root, file, exists: false, profiles: [], mcpServers: [], notify: false, features: [], trustedProjects: 0, plugins: [], otherKeys: [] };
  const { text, st, error } = readSmall(file);
  if (st) Object.assign(c, { exists: true, bytes: st.size, mtime: st.mtimeMs });
  if (error) c.error = error;
  if (text === void 0) return c;
  let t;
  try {
    t = parseToml(text);
  } catch (e) {
    c.error = `unreadable TOML: ${bounded(String(e.message ?? e), 80)}`;
    return c;
  }
  c.model = tstr(t.model);
  c.effort = tstr(t.model_reasoning_effort, 20);
  c.approval = tstr(t.approval_policy, 30);
  c.sandbox = tstr(t.sandbox_mode, 30) ?? tstr(t.sandbox, 30);
  c.serviceTier = tstr(t.service_tier, 20);
  c.profile = tstr(t.profile, 40);
  for (const [name2, p] of Object.entries(ttab(t.profiles)).slice(0, 50)) {
    const q = ttab(p);
    c.profiles.push({ name: bounded(name2, 40), model: tstr(q.model), effort: tstr(q.model_reasoning_effort, 20), approval: tstr(q.approval_policy, 30), sandbox: tstr(q.sandbox_mode, 30) ?? tstr(q.sandbox, 30) });
  }
  c.mcpServers = Object.keys(ttab(t.mcp_servers)).slice(0, MAX_LIST).map((k) => bounded(k, 50));
  c.notify = Array.isArray(t.notify) ? t.notify.length > 0 : t.notify !== void 0 && t.notify !== "" && t.notify !== false;
  c.features = Object.entries(ttab(t.features)).filter(([, v]) => typeof v === "boolean").map(([k, v]) => ({ name: bounded(k, 40), on: v === true })).slice(0, 60);
  c.trustedProjects = Object.values(ttab(t.projects)).filter((p) => ttab(p).trust_level === "trusted").length;
  c.plugins = Object.entries(ttab(t.plugins)).map(([k, v]) => ({ name: bounded(k, 60), on: ttab(v).enabled !== false })).slice(0, 80);
  c.otherKeys = Object.keys(t).filter((k) => !KNOWN_CODEX.has(k)).map((k) => SECRET_NAME.test(k) ? "(hidden key)" : bounded(k, 40)).slice(0, 40);
  return c;
}
function collectSettings(input) {
  const homeKey = normalizeCase(path2.dirname(input.claudeHome));
  const roots = [];
  const seen = /* @__PURE__ */ new Set();
  for (const r of input.roots) {
    if (!isPlausibleLocalPath(r)) continue;
    const k = normalizeCase(path2.resolve(r));
    if (seen.has(k) || k === homeKey) continue;
    seen.add(k);
    if (!stat(r)?.isDirectory()) continue;
    roots.push({ path: r, name: path2.basename(r) || r });
    if (roots.length >= MAX_ROOTS) break;
  }
  const layers = [];
  if (input.managedFile) layers.push(readClaudeLayer("managed", input.managedFile));
  layers.push(readClaudeLayer("user", path2.join(input.claudeHome, "settings.json")));
  for (const r of roots) {
    layers.push(readClaudeLayer("project", path2.join(r.path, ".claude", "settings.json"), r.path));
    layers.push(readClaudeLayer("local", path2.join(r.path, ".claude", "settings.local.json"), r.path));
  }
  const items = [];
  const scan = (base, scope, root) => {
    listMd(path2.join(base, "agents"), "agent", scope, root, items);
    listMd(path2.join(base, "skills"), "skill", scope, root, items);
    listMd(path2.join(base, "commands"), "command", scope, root, items);
    listMd(path2.join(base, "output-styles"), "output-style", scope, root, items);
  };
  scan(input.claudeHome, "user");
  for (const r of roots) scan(path2.join(r.path, ".claude"), "project", r.path);
  const mem = [];
  memory(path2.join(input.claudeHome, "CLAUDE.md"), "claude", "user", void 0, mem);
  memory(path2.join(input.codexHome, "AGENTS.md"), "codex", "user", void 0, mem);
  for (const r of roots) {
    memory(path2.join(r.path, "CLAUDE.md"), "claude", "project", r.path, mem);
    memory(path2.join(r.path, ".claude", "CLAUDE.md"), "claude", "project", r.path, mem);
    memory(path2.join(r.path, "CLAUDE.local.md"), "claude", "project", r.path, mem);
    memory(path2.join(r.path, "AGENTS.md"), "codex", "project", r.path, mem);
  }
  const codex = [readCodexConfig(path2.join(input.codexHome, "config.toml"), "user")];
  for (const r of roots) {
    const f = path2.join(r.path, ".codex", "config.toml");
    if (stat(f)) codex.push(readCodexConfig(f, "project", r.path));
  }
  const files = [...layers.filter((l) => l.exists).map((l) => l.file), ...items.map((i) => i.file), ...mem.map((m) => m.file), ...codex.filter((c) => c.exists).map((c) => c.file)].filter((f) => !isForbidden(f));
  return { at: input.now ?? Date.now(), claudeHome: input.claudeHome, codexHome: input.codexHome, roots, layers, items, memory: mem, codex, files };
}
function layersFor(report, root) {
  const k = root ? normalizeCase(root) : void 0;
  return report.layers.filter((l) => l.exists && !l.error && (l.kind === "managed" || l.kind === "user" || k !== void 0 && l.root !== void 0 && normalizeCase(l.root) === k)).sort((a, b) => LAYER_ORDER.indexOf(a.kind) - LAYER_ORDER.indexOf(b.kind));
}
function effective(layers, key) {
  const set = layers.filter((l) => l[key] !== void 0);
  const win = set[0];
  return { value: win?.[key], layer: win?.kind, file: win?.file, shadowed: set.slice(1).map((l) => ({ layer: l.kind, value: l[key] })) };
}
function mergedRules(layers) {
  const u = (f) => new Set(layers.flatMap(f)).size;
  return { allow: u((l) => l.allow), deny: u((l) => l.deny), ask: u((l) => l.ask), hooks: layers.reduce((n, l) => n + l.hooks.length, 0) };
}

// src/feeds/catalog.ts
var fs4 = __toESM(require("fs"));
var path4 = __toESM(require("path"));

// src/git/git.ts
var fs3 = __toESM(require("fs"));
var path3 = __toESM(require("path"));
var HARDEN = ["-c", "core.fsmonitor=false", "-c", "core.untrackedCache=false", "-c", "core.quotepath=off", "-c", "diff.external=", "-c", "core.pager=cat", "-c", "credential.helper=", "--no-optional-locks", "--no-pager"];
var exeCache = /* @__PURE__ */ new Map();
function findExe(name2, pathVar, platform = process.platform) {
  if (!/^[A-Za-z0-9][\w.\-]*$/.test(name2)) return void 0;
  const win = platform === "win32";
  const p = win ? path3.win32 : path3.posix;
  const exts = win ? /\.(exe|com)$/i.test(name2) ? [""] : [".exe", ".com"] : [""];
  for (const raw of (pathVar ?? "").split(win ? ";" : ":")) {
    const dir = raw.trim().replace(/^"(.*)"$/, "$1");
    if (!dir || (win ? !/^(?:[A-Za-z]:[\\/]|\\\\[^\\/])/.test(dir) : !p.isAbsolute(dir))) continue;
    for (const ext of exts) {
      const f = p.join(dir, name2 + ext);
      try {
        if (!fs3.statSync(f).isFile()) continue;
        if (!win) fs3.accessSync(f, fs3.constants.X_OK);
        return f;
      } catch {
      }
    }
    if (win && NPM_NATIVE[name2] && fs3.existsSync(p.join(dir, name2 + ".cmd"))) {
      for (const rel of NPM_NATIVE[name2]) {
        const f = p.join(dir, "node_modules", rel);
        try {
          if (fs3.statSync(f).isFile()) return f;
        } catch {
        }
      }
    }
  }
  return void 0;
}
var NPM_NATIVE = {
  codex: [["x64", "x86_64"], ["arm64", "aarch64"]].map(([a, t]) => `@openai/codex/node_modules/@openai/codex-win32-${a}/vendor/${t}-pc-windows-msvc/bin/codex.exe`)
};
function resolveExe(name2) {
  if (exeCache.has(name2)) return exeCache.get(name2);
  const key = Object.keys(process.env).find((k) => k.toUpperCase() === "PATH");
  const exe = findExe(name2, key ? process.env[key] : void 0);
  exeCache.set(name2, exe);
  return exe;
}

// src/feeds/catalog.ts
var MAX_BYTES2 = 1e6;
var MAX_JSON_BYTES = 8e6;
var MAX_ITEMS = 4e3;
var MAX_PLUGINS = 300;
var SECRET_NAME2 = /(token|secret|passw|api_?key|apikey|access_?key|private|credential|auth|bearer|cookie|session_?id|helper)/i;
var SKIP_DIR = /^(secrets?|node_modules|\.git|credentials?)$/i;
var fsp = fs4.promises;
async function stat2(file) {
  if (hasLinkedAncestor(file)) return void 0;
  try {
    return await fsp.stat(file);
  } catch {
    return void 0;
  }
}
async function dirs(dir) {
  if (hasLinkedAncestor(dir)) return [];
  try {
    return (await fsp.readdir(dir, { withFileTypes: true })).filter((e) => (e.isDirectory() || e.isSymbolicLink()) && !SKIP_DIR.test(e.name)).map((e) => e.name).sort();
  } catch {
    return [];
  }
}
async function filesIn(dir, re) {
  if (hasLinkedAncestor(dir)) return [];
  try {
    return (await fsp.readdir(dir, { withFileTypes: true })).filter((e) => e.isFile() && re.test(e.name)).map((e) => e.name).sort();
  } catch {
    return [];
  }
}
async function readText(file, max = MAX_BYTES2) {
  if (isForbidden(file)) return void 0;
  const st = await stat2(file);
  if (!st || !st.isFile() || st.size > max) return void 0;
  try {
    return await fsp.readFile(file, "utf8");
  } catch {
    return void 0;
  }
}
async function readHead(file, max = 16384) {
  if (isForbidden(file)) return void 0;
  let fh;
  try {
    fh = await fsp.open(file, "r");
    const buf = Buffer.alloc(max);
    const { bytesRead } = await fh.read(buf, 0, max, 0);
    return buf.subarray(0, bytesRead).toString("utf8");
  } catch {
    return void 0;
  } finally {
    if (fh) await fh.close().catch(() => void 0);
  }
}
function parseJsonObject(t) {
  try {
    const j = JSON.parse(t.replace(/^\uFEFF/, ""));
    return j && typeof j === "object" && !Array.isArray(j) ? j : void 0;
  } catch {
    try {
      const noComments = t.replace(/("(?:\\.|[^"\\])*")|\/\/[^\n]*|\/\*[\s\S]*?\*\//g, (m, s2) => s2 ?? "").replace(/,(\s*[}\]])/g, "$1");
      const j = JSON.parse(noComments);
      return j && typeof j === "object" && !Array.isArray(j) ? j : void 0;
    } catch {
      return void 0;
    }
  }
}
async function readJson(file, max = MAX_BYTES2) {
  const t = await readText(file, max);
  return t === void 0 ? void 0 : parseJsonObject(t);
}
var obj = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
var s = (v, max = 80) => typeof v === "string" && v.trim() ? bounded(v, max) : void 0;
async function countFiles(dir, depth = 4, cap = 500) {
  let n = 0;
  const walk = async (d, left) => {
    let es;
    try {
      es = await fsp.readdir(d, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of es) {
      if (n >= cap) return;
      if (e.isFile()) n++;
      else if (e.isDirectory() && left > 0 && !SKIP_DIR.test(e.name)) await walk(path4.join(d, e.name), left - 1);
    }
  };
  await walk(dir, depth);
  return n;
}
function programOf(command) {
  if (typeof command !== "string" || !command.trim()) return "";
  const words = [];
  const re = /"([^"]*)"|'([^']*)'|(\S+)/g;
  let m;
  while ((m = re.exec(command.trim())) && words.length < 2) words.push(m[1] ?? m[2] ?? m[3]);
  const base = (w) => w.replace(/[\\/]+$/, "").split(/[\\/]/).pop() ?? w;
  const prog = base(words[0] ?? "");
  const second = words[1] && /\.(py|js|mjs|cjs|ts|ps1|sh|bash|cmd|bat|rb|pl)$/i.test(words[1]) && !/^-/.test(words[1]) ? base(words[1]) : "";
  return bounded([prog, second].filter(Boolean).join(" "), 60);
}
function headingsOf(text, max = 40) {
  const out = [];
  let fence = false;
  for (const line of text.split(/\r?\n/)) {
    if (/^\s*(```|~~~)/.test(line)) fence = !fence;
    if (fence) continue;
    const m = /^(#{1,3})\s+(.+?)\s*#*\s*$/.exec(line);
    if (m) out.push(`${"  ".repeat(m[1].length - 1)}${bounded(m[2], 90)}`);
    if (out.length >= max) break;
  }
  return out;
}
async function pushItem(out, file, kind, c, fallback, files) {
  if (out.length >= MAX_ITEMS) return;
  const text = await readHead(file);
  const fm = text ? frontMatter(text) : {};
  out.push({
    provider: c.provider,
    kind,
    source: c.source,
    plugin: c.plugin,
    active: c.active,
    root: c.root,
    file,
    name: bounded(fm.name || fallback, 70),
    description: fm.description ? bounded(fm.description, 220) : void 0,
    model: fm.model ? bounded(fm.model, 40) : void 0,
    effort: fm.effort ? bounded(fm.effort, 20) : void 0,
    tools: fm.tools || fm["allowed-tools"] ? bounded(fm.tools || fm["allowed-tools"], 160) : void 0,
    argumentHint: fm["argument-hint"] ? bounded(fm["argument-hint"], 80) : void 0,
    files
  });
}
async function scanSkills(dir, c, out) {
  let n = 0;
  for (const d of await dirs(dir)) {
    if (d.startsWith(".")) continue;
    const f = path4.join(dir, d, "SKILL.md");
    if ((await stat2(f))?.isFile()) {
      await pushItem(out, f, "skill", c, d, c.active ? await countFiles(path4.join(dir, d)) : void 0);
      n++;
      continue;
    }
    for (const sub of (await dirs(path4.join(dir, d))).slice(0, 60)) {
      const g = path4.join(dir, d, sub, "SKILL.md");
      if ((await stat2(g))?.isFile()) {
        await pushItem(out, g, "skill", c, `${d}/${sub}`, c.active ? await countFiles(path4.join(dir, d, sub)) : void 0);
        n++;
      }
    }
  }
  return n;
}
async function scanMd(dir, kind, c, out, ns = "", depth = 3) {
  let n = 0;
  for (const f of await filesIn(dir, /\.md$/i)) {
    if (/^readme\.md$/i.test(f)) continue;
    const base = f.replace(/\.md$/i, "");
    await pushItem(out, path4.join(dir, f), kind, c, ns ? `${ns}:${base}` : base);
    n++;
  }
  if (depth > 0) for (const d of (await dirs(dir)).slice(0, 80)) n += await scanMd(path4.join(dir, d), kind, c, out, ns ? `${ns}:${d}` : d, depth - 1);
  return n;
}
async function scanClaudeDir(base, c, out) {
  const skills = await scanSkills(path4.join(base, "skills"), c, out);
  const agents = await scanMd(path4.join(base, "agents"), "agent", c, out, "", 1);
  const commands = await scanMd(path4.join(base, "commands"), "command", c, out);
  const styles = await scanMd(path4.join(base, "output-styles"), "output-style", c, out, "", 0);
  return { skills, agents, commands, styles };
}
function hooksFrom(v, base, out) {
  let n = 0;
  for (const [event, groups] of Object.entries(obj(v))) {
    if (!Array.isArray(groups)) continue;
    for (const g of groups) {
      const go = obj(g);
      const matcher = s(go.matcher, 60) ?? "";
      for (const h of Array.isArray(go.hooks) ? go.hooks : []) {
        const r = obj(h);
        const type = s(r.type, 20) ?? "command";
        const program = typeof r.command === "string" ? programOf(r.command) : type === "http" || r.url ? "http" : typeof r.prompt === "string" ? "prompt" : "";
        out.push({ ...base, event: bounded(event, 40), matcher, type, program, timeout: typeof r.timeout === "number" ? r.timeout : void 0 });
        n++;
        if (out.length >= MAX_ITEMS) return n;
      }
    }
  }
  return n;
}
function mcpFrom(v, base, out) {
  let n = 0;
  for (const [name2, cfg] of Object.entries(obj(v)).slice(0, 200)) {
    const c = obj(cfg);
    const transport = s(c.type, 20) ?? s(c.transport, 20) ?? (typeof c.command === "string" ? "stdio" : typeof c.url === "string" ? "http" : "?");
    out.push({ ...base, name: SECRET_NAME2.test(name2) && name2.length > 40 ? "(hidden name)" : bounded(name2, 60), transport, program: typeof c.command === "string" ? programOf(c.command).split(" ")[0] : void 0 });
    n++;
  }
  return n;
}
var SHOW_STRING = /* @__PURE__ */ new Set(["model", "effortLevel", "outputStyle", "theme", "language", "defaultMode", "preferredNotifChannel", "forceLoginMethod", "defaultShell", "agent", "autoUpdatesChannel", "subagentModel", "spinnerTipsEnabled", "editorMode", "viewMode"]);
var HIDE_KEYS = /* @__PURE__ */ new Set(["env", "apiKeyHelper", "awsAuthRefresh", "awsCredentialExport", "otelHeadersHelper"]);
function shape(v) {
  if (Array.isArray(v)) return `${v.length} item${v.length === 1 ? "" : "s"}`;
  if (v && typeof v === "object") {
    const n = Object.keys(v).length;
    return `${n} key${n === 1 ? "" : "s"}`;
  }
  return "set";
}
function settingRows(j, layer, file, root, out) {
  const push = (key, value) => out.length < MAX_ITEMS && out.push({ key, value, layer, root, file });
  const val = (name2, v) => typeof v === "boolean" || typeof v === "number" ? String(v) : typeof v === "string" ? SHOW_STRING.has(name2) && !SECRET_NAME2.test(name2) ? bounded(v, 60) : "set" : shape(v);
  for (const [k, v] of Object.entries(j)) {
    if (SECRET_NAME2.test(k) && !HIDE_KEYS.has(k)) {
      push("(hidden key)", "set");
      continue;
    }
    if (k === "env") {
      push("env", `${Object.keys(obj(v)).length} variable name(s), values never read`);
      continue;
    }
    if (HIDE_KEYS.has(k)) {
      push(k, "set");
      continue;
    }
    if (k === "hooks" || k === "enabledPlugins" || k === "mcpServers") {
      push(k, shape(v));
      continue;
    }
    if (v && typeof v === "object" && !Array.isArray(v)) {
      const sub = Object.entries(v);
      if (!sub.length) push(k, "0 keys");
      for (const [k2, v2] of sub.slice(0, 40)) push(`${k}.${SECRET_NAME2.test(k2) ? "(hidden key)" : bounded(k2, 40)}`, SECRET_NAME2.test(k2) ? "set" : val(k2, v2));
    } else push(bounded(k, 50), val(k, v));
  }
}
async function claudePluginRefs(home, enabledIds, errors) {
  const refs = /* @__PURE__ */ new Map();
  const pdir = path4.join(home, "plugins");
  const inst = await readJson(path4.join(pdir, "installed_plugins.json"));
  const ip = obj(inst?.plugins);
  for (const [id, raw] of Object.entries(ip).slice(0, MAX_PLUGINS)) {
    const e = obj(Array.isArray(raw) ? raw[0] : raw);
    const [name2, marketplace] = id.split("@");
    const dir = typeof e.installPath === "string" ? e.installPath : "";
    if (dir) refs.set(id, { name: name2, marketplace, dir, installed: true, version: s(e.version, 30) });
  }
  const known = await readJson(path4.join(pdir, "known_marketplaces.json"));
  const mks = /* @__PURE__ */ new Map();
  for (const [m, e] of Object.entries(obj(known))) if (typeof obj(e).installLocation === "string") mks.set(m, obj(e).installLocation);
  for (const m of await dirs(path4.join(pdir, "marketplaces"))) if (!mks.has(m)) mks.set(m, path4.join(pdir, "marketplaces", m));
  for (const [m, loc] of mks) {
    if (!isPlausibleLocalPath(loc)) continue;
    const cat = await readJson(path4.join(loc, ".claude-plugin", "marketplace.json"), 4e6);
    const list = Array.isArray(cat?.plugins) ? cat.plugins : [];
    if (!cat && await stat2(loc)) errors.push(`marketplace ${bounded(m, 40)}: no readable .claude-plugin/marketplace.json`);
    for (const p of list.slice(0, MAX_PLUGINS)) {
      const o = obj(p);
      const name2 = s(o.name, 60);
      if (!name2) continue;
      const id = `${name2}@${m}`;
      if (refs.has(id)) continue;
      const src = typeof o.source === "string" ? o.source : void 0;
      const dir = src && !/^[a-z]+:/i.test(src) ? path4.resolve(loc, src) : path4.join(loc, "plugins", name2);
      refs.set(id, { name: name2, marketplace: m, dir, installed: false, version: s(o.version, 30) });
    }
  }
  for (const m of await dirs(path4.join(pdir, "cache"))) {
    for (const p of await dirs(path4.join(pdir, "cache", m))) {
      const id = `${p}@${m}`;
      const vs = await dirs(path4.join(pdir, "cache", m, p));
      const v = vs.includes("latest") ? "latest" : vs[vs.length - 1];
      const dir = v ? path4.join(pdir, "cache", m, p, v) : path4.join(pdir, "cache", m, p);
      const prev = refs.get(id);
      if (!prev || !prev.installed) refs.set(id, { name: p, marketplace: m, dir, installed: true, version: prev?.version ?? (v && v !== "latest" ? bounded(v, 30) : void 0) });
    }
  }
  for (const id of enabledIds) if (!refs.has(id)) {
    const [name2, marketplace] = id.split("@");
    refs.set(id, { name: name2, marketplace, dir: "", installed: false });
  }
  return [...refs.values()].slice(0, MAX_PLUGINS);
}
async function scanPlugin(ref, provider, enabled, items, hooks, mcp, files) {
  const id = ref.marketplace ? `${ref.name}@${ref.marketplace}` : ref.name;
  const active = ref.installed || enabled === true;
  const info = { provider, id, name: ref.name, marketplace: ref.marketplace, version: ref.version, enabled, installed: ref.installed, dir: ref.dir, skills: 0, agents: 0, commands: 0, hooks: 0, mcp: 0, projects: [] };
  if (!ref.dir || !(await stat2(ref.dir))?.isDirectory()) return info;
  let manifest;
  for (const f of [path4.join(ref.dir, provider === "codex" ? ".codex-plugin" : ".claude-plugin", "plugin.json"), path4.join(ref.dir, "plugin.json")]) {
    if ((await stat2(f))?.isFile()) {
      manifest = f;
      break;
    }
  }
  if (manifest) {
    const m = await readJson(manifest);
    info.manifest = manifest;
    files.push(manifest);
    info.version = s(m?.version, 30) ?? info.version;
    info.description = s(m?.description, 220);
  }
  if (!active) {
    info.skills = (await dirs(path4.join(ref.dir, "skills"))).filter((d) => !d.startsWith(".")).length;
    info.agents = (await filesIn(path4.join(ref.dir, "agents"), /\.md$/i)).length;
    info.commands = (await filesIn(path4.join(ref.dir, provider === "claude" ? "commands" : "prompts"), /\.md$/i)).length;
    info.hooks = await stat2(path4.join(ref.dir, "hooks", "hooks.json")) ? 1 : 0;
    info.mcp = await stat2(path4.join(ref.dir, ".mcp.json")) ? 1 : 0;
    return info;
  }
  const c = { provider, source: "plugin", plugin: id, active };
  const before = items.length;
  info.skills = await scanSkills(path4.join(ref.dir, "skills"), c, items);
  if (provider === "claude") {
    info.agents = await scanMd(path4.join(ref.dir, "agents"), "agent", c, items, "", 1);
    info.commands = await scanMd(path4.join(ref.dir, "commands"), "command", c, items);
    await scanMd(path4.join(ref.dir, "output-styles"), "output-style", c, items, "", 0);
  } else info.commands = await scanMd(path4.join(ref.dir, "prompts"), "prompt", c, items, "", 0);
  for (const it of items.slice(before)) files.push(it.file);
  const hf = path4.join(ref.dir, "hooks", "hooks.json");
  const hj = await readJson(hf);
  if (hj) {
    info.hooks = hooksFrom(hj.hooks ?? hj, { source: "plugin", plugin: id, file: hf }, hooks);
    files.push(hf);
  }
  const mf = path4.join(ref.dir, ".mcp.json");
  const mj = await readJson(mf);
  if (mj) {
    info.mcp = mcpFrom(mj.mcpServers ?? mj, { provider, source: "plugin", plugin: id, file: mf }, mcp);
    files.push(mf);
  }
  return info;
}
async function instr(file, provider, source, root, out) {
  const st = await stat2(file);
  if (!st || !st.isFile()) return;
  const text = await readText(file) ?? "";
  out.push({ provider, source, root, file, bytes: st.size, lines: text ? text.split("\n").length : 0, headings: headingsOf(text) });
}
async function memoryDirs(home) {
  const out = [];
  const base = path4.join(home, "projects");
  for (const p of await dirs(base)) {
    const dir = path4.join(base, p, "memory");
    const names = await filesIn(dir, /\.md$/i);
    if (!names.length) continue;
    out.push({ project: bounded(p, 120), dir, count: names.length, names: names.slice(0, 100).map((n) => bounded(n, 80)) });
    if (out.length >= 500) break;
  }
  return out;
}
async function collectCatalog(input) {
  const errors = [];
  const homeParent = normalizeCase(path4.dirname(input.claudeHome));
  const roots = [];
  const seen = /* @__PURE__ */ new Set();
  for (const r of input.roots) {
    if (!isPlausibleLocalPath(r)) continue;
    const k = normalizeCase(path4.resolve(r));
    if (seen.has(k) || k === homeParent) continue;
    seen.add(k);
    if ((await stat2(r))?.isDirectory()) roots.push(r);
    if (roots.length >= 80) break;
  }
  const items = [];
  const hooks = [];
  const mcp = [];
  const settings = [];
  const instructions = [];
  const files = [];
  const layers = [];
  if (input.managedFile) layers.push({ kind: "managed", file: input.managedFile });
  layers.push({ kind: "user", file: path4.join(input.claudeHome, "settings.json") });
  for (const r of roots) {
    layers.push({ kind: "project", file: path4.join(r, ".claude", "settings.json"), root: r });
    layers.push({ kind: "local", file: path4.join(r, ".claude", "settings.local.json"), root: r });
  }
  const enabled = /* @__PURE__ */ new Map();
  const enabledBy = /* @__PURE__ */ new Map();
  for (const l of layers) {
    const j = await readJson(l.file);
    if (!j) {
      if ((await stat2(l.file))?.isFile()) errors.push(`${bounded(l.file, 120)}: unreadable or too large`);
      continue;
    }
    files.push(l.file);
    settingRows(j, l.kind, l.file, l.root, settings);
    hooksFrom(j.hooks, { source: l.kind === "project" ? "project" : l.kind, root: l.root, file: l.file }, hooks);
    for (const [id, on] of Object.entries(obj(j.enabledPlugins))) {
      const v = on !== false;
      if (!l.root) {
        if (!enabled.has(id)) enabled.set(id, v);
      } else enabledBy.set(id, (enabledBy.get(id) ?? /* @__PURE__ */ new Set()).add(`${path4.basename(l.root) || l.root}${v ? "" : " (off)"}`));
    }
  }
  const mark = items.length;
  await scanClaudeDir(input.claudeHome, { provider: "claude", source: "user", active: true }, items);
  for (const r of roots) await scanClaudeDir(path4.join(r, ".claude"), { provider: "claude", source: "project", root: r, active: true }, items);
  for (const it of items.slice(mark)) files.push(it.file);
  const plugins = [];
  const enabledIds = /* @__PURE__ */ new Set([...enabled.keys(), ...enabledBy.keys()]);
  for (const ref of await claudePluginRefs(input.claudeHome, enabledIds, errors)) {
    const id = ref.marketplace ? `${ref.name}@${ref.marketplace}` : ref.name;
    const userOn = enabled.has(id) ? enabled.get(id) : void 0;
    const p = await scanPlugin(ref, "claude", userOn, items, hooks, mcp, files);
    p.projects = [...enabledBy.get(id) ?? []].sort();
    plugins.push(p);
  }
  if (input.claudeJson) {
    const cj = await readJson(input.claudeJson, MAX_JSON_BYTES);
    if (cj) {
      mcpFrom(cj.mcpServers, { provider: "claude", source: "user", file: input.claudeJson }, mcp);
      for (const [p, e] of Object.entries(obj(cj.projects)).slice(0, 2e3)) {
        if (!isPlausibleLocalPath(p)) continue;
        mcpFrom(obj(e).mcpServers, { provider: "claude", source: "local", root: p, file: input.claudeJson }, mcp);
      }
    }
  }
  for (const r of roots) {
    const f = path4.join(r, ".mcp.json");
    const j = await readJson(f);
    if (!j) continue;
    files.push(f);
    mcpFrom(j.mcpServers ?? j, { provider: "claude", source: "project", root: r, file: f }, mcp);
  }
  await instr(path4.join(input.claudeHome, "CLAUDE.md"), "claude", "user", void 0, instructions);
  await instr(path4.join(input.codexHome, "AGENTS.md"), "codex", "user", void 0, instructions);
  for (const r of roots) {
    await instr(path4.join(r, "CLAUDE.md"), "claude", "project", r, instructions);
    await instr(path4.join(r, ".claude", "CLAUDE.md"), "claude", "project", r, instructions);
    await instr(path4.join(r, "CLAUDE.local.md"), "claude", "local", r, instructions);
    await instr(path4.join(r, "AGENTS.md"), "codex", "project", r, instructions);
  }
  for (const i of instructions) files.push(i.file);
  const cx = input.codexHome;
  let codexConfig;
  const cfgFile = path4.join(cx, "config.toml");
  if ((await stat2(cfgFile))?.isFile()) {
    codexConfig = readCodexConfig(cfgFile, "user");
    files.push(cfgFile);
    const t = await readText(cfgFile);
    if (t) {
      let toml = {};
      try {
        toml = parseToml(t);
      } catch {
      }
      mcpFrom(toml.mcp_servers, { provider: "codex", source: "user", file: cfgFile }, mcp);
    }
  }
  const cmark = items.length;
  const userSkills = path4.join(cx, "skills");
  await scanSkills(userSkills, { provider: "codex", source: "user", active: true }, items);
  await scanSkills(path4.join(userSkills, ".system"), { provider: "codex", source: "system", active: true }, items);
  await scanMd(path4.join(cx, "prompts"), "prompt", { provider: "codex", source: "user", active: true }, items, "", 0);
  for (const r of roots) await scanSkills(path4.join(r, ".codex", "skills"), { provider: "codex", source: "project", root: r, active: true }, items);
  for (const it of items.slice(cmark)) files.push(it.file);
  const codexOn = new Map((codexConfig?.plugins ?? []).map((p) => [p.name, p.on]));
  for (const m of await dirs(path4.join(cx, "plugins", "cache"))) {
    for (const p of await dirs(path4.join(cx, "plugins", "cache", m))) {
      if (plugins.length >= MAX_PLUGINS * 2) break;
      const vs = await dirs(path4.join(cx, "plugins", "cache", m, p));
      const v = vs.includes("latest") ? "latest" : vs[vs.length - 1];
      const dir = v ? path4.join(cx, "plugins", "cache", m, p, v) : path4.join(cx, "plugins", "cache", m, p);
      const id = `${p}@${m}`;
      const on = codexOn.has(id) ? codexOn.get(id) : codexOn.has(p) ? codexOn.get(p) : void 0;
      plugins.push(await scanPlugin({ name: p, marketplace: m, dir, installed: true, version: v && v !== "latest" ? bounded(v, 30) : vs.filter((x) => x !== "latest").pop() }, "codex", on, items, hooks, mcp, files));
    }
  }
  const codexRules = [];
  for (const f of (await filesIn(path4.join(cx, "rules"), /\.rules$/i)).slice(0, 50)) {
    const file = path4.join(cx, "rules", f);
    const t = await readText(file) ?? "";
    codexRules.push({ file, rules: (t.match(/^\s*prefix_rule\s*\(/gm) ?? []).length });
    files.push(file);
  }
  return {
    at: input.now ?? Date.now(),
    claudeHome: input.claudeHome,
    codexHome: input.codexHome,
    roots,
    items,
    plugins,
    hooks,
    mcp,
    settings,
    instructions,
    memory: await memoryDirs(input.claudeHome),
    codexConfig,
    codexRules,
    files: [...new Set(files)].filter((f) => !isForbidden(f) && (!input.claudeJson || normalizeCase(f) !== normalizeCase(input.claudeJson))),
    errors: errors.slice(0, 20)
  };
}

// src/galaxy/index.ts
var import_crypto = require("crypto");
var CONFIG_SNAPSHOT_SCHEMA = "galaxy.agent-config-snapshot/1";
function sha256(text) {
  return (0, import_crypto.createHash)("sha256").update(text, "utf8").digest("hex");
}
function pathRef(p) {
  if (!p) return void 0;
  const norm = p.replace(/\\/g, "/").replace(/\/+$/, "").toLowerCase();
  const name2 = norm.split("/").filter(Boolean).pop() ?? "";
  return { name: name2, hash: sha256(norm).slice(0, 16) };
}
function iso(ms) {
  return ms === void 0 || !Number.isFinite(ms) ? void 0 : new Date(ms).toISOString();
}
function canonicalJson(v) {
  if (v === void 0) return "null";
  if (v === null || typeof v !== "object") return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(canonicalJson).join(",")}]`;
  const o = v;
  return `{${Object.keys(o).filter((k) => o[k] !== void 0).sort().map((k) => `${JSON.stringify(k)}:${canonicalJson(o[k])}`).join(",")}}`;
}
function compactObj(o) {
  return Object.fromEntries(Object.entries(o).filter(([, v]) => v !== void 0));
}

// src/galaxy/configSnapshot.ts
var name = (s2, max = 80) => bounded(s2, max);
var uniq = (xs) => [...new Set(xs)].sort();
var byKey = (xs, key) => [...xs].sort((a, b) => key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0);
function claudePart(r) {
  const layers = r.layers.filter((l) => l.exists && !l.error).map((l) => compactObj({
    kind: l.kind,
    root: pathRef(l.root),
    model: l.model,
    effortLevel: l.effortLevel,
    defaultMode: l.defaultMode,
    outputStyle: l.outputStyle,
    allow: l.allow.length,
    deny: l.deny.length,
    ask: l.ask.length,
    hookEvents: uniq(l.hooks.map((h) => name(h.event, 40))),
    hooks: l.hooks.length,
    env: l.envNames.length + l.envHidden,
    enabledPlugins: uniq(l.enabledPlugins.map((p) => name(p))),
    apiKeyHelper: l.apiKeyHelper
  }));
  const user = layersFor(r);
  return {
    layers: byKey(layers, (l) => `${l.kind}|${l.root?.hash ?? ""}`),
    effective: compactObj({ model: effective(user, "model").value, effortLevel: effective(user, "effortLevel").value, defaultMode: effective(user, "defaultMode").value }),
    rules: mergedRules(user),
    items: byKey(r.items.map((i) => ({ kind: i.kind, scope: i.scope, name: name(i.name) })), (i) => `${i.kind}|${i.scope}|${i.name}`)
  };
}
function codexPart(c) {
  return compactObj({
    scope: c.scope,
    root: pathRef(c.root),
    model: c.model,
    effort: c.effort,
    approval: c.approval,
    sandbox: c.sandbox,
    serviceTier: c.serviceTier,
    profile: c.profile,
    profiles: uniq(c.profiles.map((p) => name(p.name))),
    mcpServers: uniq(c.mcpServers.map((m) => name(m))),
    features: byKey(c.features.map((f) => ({ name: name(f.name), on: f.on })), (f) => f.name),
    plugins: byKey(c.plugins.map((p) => ({ name: name(p.name), on: p.on })), (p) => p.name),
    trustedProjects: c.trustedProjects,
    notify: c.notify
  });
}
function catalogPart(c) {
  return {
    items: byKey(c.items.map((i) => compactObj({ provider: i.provider, kind: i.kind, source: i.source, name: name(i.name), active: i.active, plugin: i.plugin ? name(i.plugin) : void 0 })), (i) => `${i.provider}|${i.kind}|${i.source}|${i.name}`),
    plugins: byKey(c.plugins.map((p) => compactObj({ provider: p.provider, id: name(p.id), version: p.version ? name(p.version, 40) : void 0, enabled: p.enabled, installed: p.installed })), (p) => `${p.provider}|${p.id}`),
    hooks: byKey(c.hooks.map((h) => ({ event: name(h.event, 40), matcher: name(h.matcher, 80), type: h.type, program: name(h.program, 60), source: h.source })), (h) => `${h.event}|${h.matcher}|${h.program}`),
    mcp: byKey(c.mcp.map((m) => ({ provider: m.provider, name: name(m.name), transport: m.transport, source: m.source })), (m) => `${m.provider}|${m.name}`),
    settingsKeys: uniq(c.settings.map((s2) => name(s2.key, 80)))
  };
}
function toConfigSnapshot(input) {
  const codexConfigs = input.settings?.codex.filter((c) => c.exists && !c.error);
  const content = compactObj({
    claude: input.settings ? claudePart(input.settings) : void 0,
    codex: codexConfigs ? byKey(codexConfigs.map(codexPart), (c) => `${c.scope}|${c.root?.hash ?? ""}`) : void 0,
    catalog: input.catalog ? catalogPart(input.catalog) : void 0,
    cli: input.cli ? byKey(input.cli.map((c) => compactObj({ tool: c.tool, status: c.status, version: c.version ? name(c.version, 40) : void 0 })), (c) => c.tool) : void 0
  });
  const kinds = {
    claude: input.settings ? "OBSERVED" : "UNKNOWN",
    "claude.effective": input.settings ? "DERIVED" : "UNKNOWN",
    "claude.rules": input.settings ? "DERIVED" : "UNKNOWN",
    codex: input.settings ? "OBSERVED" : "UNKNOWN",
    catalog: input.catalog ? "OBSERVED" : "UNKNOWN",
    cli: input.cli ? "OBSERVED" : "UNKNOWN",
    contentHash: "DERIVED",
    capturedAt: "OBSERVED"
  };
  return {
    schema: CONFIG_SNAPSHOT_SCHEMA,
    capturedAt: iso(input.capturedAt) ?? (/* @__PURE__ */ new Date(0)).toISOString(),
    contentHash: sha256(canonicalJson(content)),
    kinds,
    ...content
  };
}

// src/cockpit/policy.ts
var import_node_crypto = require("node:crypto");
var path5 = __toESM(require("node:path"));
var digest = (value) => (0, import_node_crypto.createHash)("sha256").update(JSON.stringify(value)).digest("hex");
var repoId = (root) => {
  const p = path5.resolve(root).replace(/\\/g, "/");
  return "repo:" + digest(process.platform === "win32" ? p.toLowerCase() : p).slice(0, 24);
};
var idOk = (v) => typeof v === "string" && /^[a-zA-Z0-9._:/-]{1,160}$/.test(v);
function validateRequest(value) {
  if (!value || typeof value !== "object") return false;
  const r = value, s2 = r.scope;
  return idOk(r.requestId) && !!s2 && idOk(s2.scopeId) && ["organizationIds", "privacyDomainIds", "projectIds", "repoIds"].every((k) => {
    const a = s2[k];
    return Array.isArray(a) && a.length <= 100 && a.every(idOk);
  }) && typeof s2.policyHash === "string" && typeof s2.sourceVectorHash === "string" && /^[a-f0-9]{64}$/.test(s2.policyHash) && /^[a-f0-9]{64}$/.test(s2.sourceVectorHash) && (r.limit === void 0 || Number.isInteger(r.limit) && r.limit > 0 && r.limit <= 500) && (r.cursor === void 0 || /^[0-9]{1,6}$/.test(r.cursor)) && (r.epoch === void 0 || Number.isSafeInteger(r.epoch) && r.epoch >= 0) && (r.generation === void 0 || idOk(r.generation));
}
var ScopePolicy = class {
  grants = /* @__PURE__ */ new Map();
  revision = 0;
  get epoch() {
    return this.revision;
  }
  set(grant) {
    if (!this.grants.has(grant.scope.scopeId) && this.grants.size >= 100) throw new Error("Reviewed scope bound exceeded.");
    this.grants.set(grant.scope.scopeId, structuredClone(grant));
    this.revision++;
  }
  clear() {
    this.grants.clear();
    this.revision++;
  }
  scopes() {
    return [...this.grants.values()].map((g) => structuredClone(g.scope));
  }
  authorize(request) {
    if (!validateRequest(request) || request.epoch !== void 0 && request.epoch !== this.revision || request.generation !== void 0 && !idOk(request.generation)) return void 0;
    const g = this.grants.get(request.scope.scopeId);
    const same = g && Object.keys(g.scope).every((k) => JSON.stringify(g.scope[k]) === JSON.stringify(request.scope[k]));
    return same ? structuredClone(g) : void 0;
  }
  sessions(g, sessions) {
    const keys = new Set(g.sessionKeys);
    return sessions.filter((s2) => {
      const root = s2.repository ?? s2.cwd;
      return keys.has(s2.key) && (root ? g.scope.repoIds.includes(repoId(root)) : g.scope.repoIds.length === 0);
    });
  }
};

// src/cockpit/configuration.ts
async function safeLocalSource(file) {
  if (isForbidden(file) || isCredentialPath(file) || !path6.isAbsolute(file)) return false;
  try {
    for (let p = file; p !== path6.dirname(p); p = path6.dirname(p)) if ((await fs5.lstat(p)).isSymbolicLink()) return false;
    return (await fs5.stat(file)).isFile();
  } catch {
    return false;
  }
}
async function collectConfiguration(selection, provider, sessions, homes) {
  const grant = { roots: selection.roots, scope: { policyHash: selection.policyHash } };
  const at = Date.now();
  const settings = collectSettings({ ...homes, roots: grant.roots, now: at });
  const catalog = await collectCatalog({ ...homes, roots: grant.roots, now: at });
  const snapshot = toConfigSnapshot({ settings, catalog, capturedAt: at });
  const sources = /* @__PURE__ */ new Map();
  for (const file of [...settings.files, ...catalog.files].slice(0, 500)) {
    if (await safeLocalSource(file)) sources.set("source:" + digest([grant.scope.policyHash, file]).slice(0, 32), file);
  }
  const fact = (value, sourceIds = [], kind = "DERIVED") => ({ value: value ? bounded(value, 80) : null, kind: value ? kind : "UNKNOWN", sourceIds, observedAt: new Date(at).toISOString() });
  const sourceFor = (file) => [...sources].filter(([, f]) => f === file).map(([id]) => id);
  const configured = {};
  let layers;
  if (provider === "claude") {
    layers = snapshot.claude?.layers ?? [];
    for (const key of ["model", "effortLevel", "defaultMode"]) {
      const e = grant.roots.length > 1 ? { value: void 0, file: void 0 } : effective(layersFor(settings, grant.roots[0]), key);
      configured[key] = { ...fact(e.value, e.file ? sourceFor(e.file) : []), reason: "Configured precedence only; CLI overrides and active runtime may differ." };
    }
  } else {
    layers = snapshot.codex ?? [];
    const configs = settings.codex.filter((c) => c.exists && !c.error);
    for (const key of ["model", "effort", "approval", "sandbox", "serviceTier", "profile"]) {
      const c = grant.roots.length > 1 ? void 0 : [...configs].reverse().find((c2) => c2[key] !== void 0);
      configured[key] = { ...fact(c?.[key], c ? sourceFor(c.file) : []), reason: "Configured value; profile selection, CLI overrides and runtime resolution are incomplete." };
    }
  }
  const inventory = [
    ...(snapshot.catalog?.items ?? []).filter((i) => i.provider === provider).map((i) => {
      const plugin = i.plugin ? snapshot.catalog?.plugins.find((p) => p.provider === provider && p.id === i.plugin) : void 0;
      return { ...i, installed: i.source === "plugin" ? plugin?.installed ?? "UNKNOWN" : true, enabled: i.source === "plugin" ? plugin?.enabled ?? "UNKNOWN" : "UNKNOWN", authenticated: "UNKNOWN", probed: "UNKNOWN", used: "UNKNOWN" };
    }),
    ...catalog.items.filter((i) => i.provider === provider).map((i) => ({ kind: "declared-native-role", itemKind: i.kind, name: bounded(i.name, 80), source: i.source, sourceIds: sourceFor(i.file), requestedModel: i.model ? bounded(i.model, 80) : null, requestedEffort: i.effort ? bounded(i.effort, 30) : null, declaredTools: i.tools ? bounded(i.tools, 140) : null, observedModel: null, inheritance: "NATIVE_PROVIDER_OWNED" })),
    ...catalog.hooks.filter((h) => {
      const relative3 = path6.relative(homes.codexHome, h.file), isCodex = relative3 !== "" && !relative3.startsWith("..") && !path6.isAbsolute(relative3);
      return provider === "codex" ? isCodex : !isCodex;
    }).map((h) => ({ kind: "hook", event: bounded(h.event, 40), matcher: bounded(h.matcher, 80), type: bounded(h.type, 30), source: h.source, sourceIds: sourceFor(h.file), payload: "OMITTED", execution: "INERT" })),
    ...(snapshot.catalog?.plugins ?? []).filter((i) => i.provider === provider).map((i) => ({ ...i, kind: "plugin", probed: "UNKNOWN", used: "UNKNOWN" })),
    ...(snapshot.catalog?.mcp ?? []).filter((i) => i.provider === provider).map((i) => ({ ...i, kind: "mcp", enabled: "UNKNOWN", probed: "UNKNOWN", used: "UNKNOWN" })),
    ...catalog.instructions.filter((i) => i.provider === provider).map((i) => ({ kind: "instruction", source: i.source, bytes: i.bytes, sourceId: sourceFor(i.file)[0], execution: "INERT" }))
  ].slice(0, 500);
  const observed = sessions.filter((s2) => s2.provider === provider);
  return { at, sources, config: { provider, cliVersion: { value: null, kind: "UNKNOWN", sourceIds: [], reason: "No CLI execution during inventory; session-recorded versions are separate." }, layers, effective: configured, resolution: "PARTIAL", inventory, observedSessions: observed, sourceOpenIds: [...sources.keys()] } };
}

// src/provider-kit/nativeTransport.ts
var fs8 = __toESM(require("node:fs/promises"));
var import_node_fs = require("node:fs");
var import_node_crypto5 = require("node:crypto");

// src/provider-kit/nativeStartup.ts
var fs6 = __toESM(require("node:fs/promises"));
var path7 = __toESM(require("node:path"));
var import_node_crypto2 = require("node:crypto");
var hash = (value) => sha256(canonicalJson(value));
async function captureNativeStartupManifest(selection) {
  const s2 = { ...structuredClone(selection), home: selection.providerHome ?? selection.home };
  if (!s2 || !["codex-app-server", "codex-cli", "claude-cli", "maf-harness"].includes(s2.transport) || ![s2.cwd, s2.home].every((p) => isPlausibleLocalPath(p) && !hasLinkedAncestor(p))) throw Error("Invalid bounded startup inventory.");
  if (s2.transport === "maf-harness") {
    if (!/^[a-f0-9]{64}$/.test(s2.mafRuntimeHash ?? "")) throw Error("MAF runtime binding is missing.");
    const value2 = {
      schema: "datapass.native-startup-manifest/1",
      transport: s2.transport,
      cwd: s2.cwd,
      home: s2.home,
      files: [],
      directories: [],
      localState: "VERIFIED_NO_CUSTOMIZATIONS",
      managedState: "UNKNOWN",
      isolationState: "ASSERTED",
      omissions: ["Fixed MAF startup; no native configuration discovery.", "Runtime binding: " + s2.mafRuntimeHash, "Runtime bytes and independent platform isolation still require preflight verification."]
    };
    return { ...value2, manifestHash: hash(value2) };
  }
  const files = [], directories = [], issues = [];
  const codex = s2.transport !== "claude-cli";
  const file = async (id, p, read) => {
    try {
      const stat4 = await fs6.lstat(p);
      if (stat4.isSymbolicLink() || hasLinkedAncestor(p) || !stat4.isFile() || stat4.size > 256 * 1024) {
        files.push({ id, state: "UNKNOWN", sha256: null, bytes: null });
        issues.push(id);
        return;
      }
      if (!read || isForbidden(p)) {
        files.push({ id, state: "PRESENT_UNREVIEWED", sha256: null, bytes: stat4.size });
        issues.push(id);
        return;
      }
      const bytes = await fs6.readFile(p);
      if (bytes.length !== stat4.size) {
        files.push({ id, state: "UNKNOWN", sha256: null, bytes: null });
        issues.push(id);
        return;
      }
      files.push({ id, state: "HASHED", sha256: (0, import_node_crypto2.createHash)("sha256").update(bytes).digest("hex"), bytes: bytes.length });
      const text = bytes.toString("utf8").replace(/^\uFEFF/, "");
      const parsed = path7.extname(p) === ".toml" ? parseToml(text) : path7.extname(p) === ".json" ? JSON.parse(text) : null;
      if (parsed) {
        const allowed = codex ? /* @__PURE__ */ new Set(["model", "model_reasoning_effort", "approval_policy", "sandbox_mode"]) : /* @__PURE__ */ new Set(["model", "effortLevel"]);
        if (!parsed || Array.isArray(parsed) || Object.keys(parsed).some((k) => !allowed.has(k))) issues.push(id);
      }
    } catch (e) {
      if (e.code === "ENOENT") files.push({ id, state: "ABSENT", sha256: null, bytes: null });
      else {
        files.push({ id, state: "UNKNOWN", sha256: null, bytes: null });
        issues.push(id);
      }
    }
  };
  const directory = async (id, p) => {
    try {
      const stat4 = await fs6.lstat(p);
      if (stat4.isSymbolicLink() || hasLinkedAncestor(p) || !stat4.isDirectory()) {
        directories.push({ id, state: "UNKNOWN" });
        issues.push(id);
        return;
      }
      const handle = await fs6.opendir(p);
      let nonempty = false;
      try {
        for await (const entry of handle) {
          nonempty = true;
          break;
        }
      } finally {
      }
      directories.push({ id, state: nonempty ? "PRESENT_UNREVIEWED" : "EMPTY" });
      if (nonempty) issues.push(id);
    } catch (e) {
      if (e.code === "ENOENT") directories.push({ id, state: "ABSENT" });
      else {
        directories.push({ id, state: "UNKNOWN" });
        issues.push(id);
      }
    }
  };
  const homeFiles = codex ? ["config.toml", "hooks.json", "requirements.toml", "AGENTS.md"] : ["settings.json", "managed-settings.json", ".mcp.json", "hooks/hooks.json", "CLAUDE.md"];
  for (const relative3 of homeFiles) await file("home/" + relative3, path7.join(s2.home, relative3), true);
  if (!codex) await file("home/.claude.json", path7.join(s2.home, ".claude.json"), false);
  for (const relative3 of codex ? ["plugins", "skills", "agents", "rules", "hooks"] : ["plugins", "skills", "agents", "rules", "hooks"]) await directory("home/" + relative3, path7.join(s2.home, relative3));
  const projectFiles = codex ? [".codex/config.toml", ".codex/hooks.json", "AGENTS.md"] : [".claude/settings.json", ".claude/settings.local.json", ".mcp.json", "CLAUDE.md"];
  for (const relative3 of projectFiles) await file("project/" + relative3, path7.join(s2.cwd, relative3), true);
  for (const relative3 of codex ? [".codex/plugins", ".codex/skills", ".codex/agents", ".codex/rules", ".agents/skills"] : [".claude/plugins", ".claude/skills", ".claude/agents", ".claude/rules", ".claude/hooks"]) await directory("project/" + relative3, path7.join(s2.cwd, relative3));
  try {
    await fs6.lstat(path7.join(s2.cwd, ".git"));
  } catch {
    issues.push("project-root-unverified");
  }
  let depth = 0;
  for (let ancestor = path7.dirname(s2.cwd); ancestor !== path7.dirname(ancestor) && depth < 32; ancestor = path7.dirname(ancestor), depth++) {
    for (const relative3 of projectFiles) await file("ancestor/" + depth + "/" + relative3, path7.join(ancestor, relative3), false);
    for (const relative3 of codex ? [".codex/rules", ".codex/plugins", ".agents/skills"] : [".claude/rules", ".claude/plugins", ".claude/hooks"]) await directory("ancestor/" + depth + "/" + relative3, path7.join(ancestor, relative3));
  }
  if (depth >= 32) issues.push("ancestor-bound");
  const managed = codex ? process.platform === "win32" ? [] : ["/etc/codex/config.toml", "/etc/codex/requirements.toml", "/etc/codex/hooks.json"] : [process.platform === "win32" ? "C:/Program Files/ClaudeCode/managed-settings.json" : process.platform === "darwin" ? "/Library/Application Support/ClaudeCode/managed-settings.json" : "/etc/claude-code/managed-settings.json"];
  for (let i = 0; i < managed.length; i++) await file("system-managed/" + i, managed[i], false);
  const value = {
    schema: "datapass.native-startup-manifest/1",
    transport: s2.transport,
    cwd: s2.cwd,
    home: s2.home,
    files,
    directories,
    localState: issues.length ? "PARTIAL" : "VERIFIED_NO_CUSTOMIZATIONS",
    managedState: "UNKNOWN",
    isolationState: "ASSERTED",
    omissions: ["No auth/history read, credential payload, hook/MCP command or arbitrary startup source exported.", "MDM, cloud-managed settings, version-specific sources and OS isolation cannot be established by a local file inventory.", "Nonempty customization trees, unknown configuration keys, unreadable or inherited/system sources require a separate verified startup audit."]
  };
  return { ...value, manifestHash: hash(value) };
}
function nativeStartupReviewHash(selection, manifest) {
  return hash({ manifestHash: manifest.manifestHash, transport: selection.transport, executableSha256: selection.executableSha256, nativeVersion: selection.nativeVersion, hostId: selection.hostId, capabilityAssertions: selection.startup.supported, isolationAssertion: selection.startup.isolated, hooksAssertion: selection.startup.hooks, mcpAssertion: selection.startup.mcp, managedAssertion: selection.startup.managed });
}

// src/provider-kit/nativePlatform.ts
var import_node_crypto3 = require("node:crypto");
function validateNativePlatformVerifier(value) {
  try {
    if (typeof value.publicKeyPem !== "string" || value.publicKeyPem.length > 2048 || !/^-----BEGIN PUBLIC KEY-----\r?\n[A-Za-z0-9+/=\r\n]+-----END PUBLIC KEY-----\s*$/.test(value.publicKeyPem)) return false;
    const key = (0, import_node_crypto3.createPublicKey)(value.publicKeyPem);
    return /^[a-zA-Z0-9._:-]{1,160}$/.test(value.issuerId) && key.asymmetricKeyType === "ed25519" && (0, import_node_crypto3.createHash)("sha256").update(key.export({ format: "der", type: "spki" })).digest("hex") === value.fingerprint;
  } catch {
    return false;
  }
}
function verifyNativePlatformProof(selection, manifest, trustedKeys, environmentHash, toolPolicyHash, now = Date.now()) {
  const fail = (reason) => ({ state: "UNKNOWN", issuerId: null, reason });
  const proof = selection.startup.platformProof;
  if (!proof || proof.schema !== "datapass.native-platform-proof/1") return fail("An independent signed platform verification receipt is required.");
  const anchor = trustedKeys.find((k) => k.issuerId === proof.issuerId && k.fingerprint === proof.keyFingerprint && validateNativePlatformVerifier(k));
  if (!anchor) return fail("Platform verifier is not trusted by the Agent host.");
  try {
    if (typeof proof.signature !== "string" || proof.signature.length !== 88 || !(0, import_node_crypto3.verify)(null, Buffer.from(canonicalJson(proof.payload)), (0, import_node_crypto3.createPublicKey)(anchor.publicKeyPem), Buffer.from(proof.signature, "base64"))) return fail("Platform proof signature is invalid.");
    const p = proof.payload, issued = Date.parse(p.issuedAt), expires = Date.parse(p.expiresAt);
    if (!Number.isFinite(issued) || !Number.isFinite(expires) || issued > now + 3e4 || expires <= now || expires - issued > 10 * 60 * 1e3) return fail("Platform proof is expired or has an invalid bounded lifetime.");
    if (p.hostId !== selection.hostId || p.transport !== selection.transport || p.cwd !== selection.cwd || p.home !== selection.home || p.permission !== selection.permission || p.executableSha256 !== selection.executableSha256 || p.nativeVersion !== selection.nativeVersion || p.startupManifestHash !== manifest.manifestHash || p.environmentHash !== environmentHash || p.toolPolicyHash !== toolPolicyHash || canonicalJson(p.supportedCapabilities) !== canonicalJson(selection.startup.supported)) return fail("Platform proof does not bind the exact host, executable, startup inventory, permission, environment, tool policy and capability set.");
    if (p.managed?.state !== "COMPLETE_NO_STARTUP_EFFECTS" || !/^[a-f0-9]{64}$/.test(p.managed.sourceHash) || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(p.managed.sourceRef) || p.ambient?.state !== "DISABLED_OR_SEALED" || !/^[a-f0-9]{64}$/.test(p.ambient.sourceHash) || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(p.ambient.sourceRef) || p.isolation?.state !== "ENFORCED" || p.isolation.descendants !== "ENFORCED" || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(p.isolation.boundaryId) || !/^[a-f0-9]{64}$/.test(p.isolation.policyHash)) return fail("Platform managed/ambient startup-effect coverage or isolation fence is incomplete.");
    return { state: "TRUSTED_VERIFIER_REPORTED", issuerId: anchor.issuerId, reason: null };
  } catch {
    return fail("Malformed platform verification receipt.");
  }
}

// src/provider-kit/nativeMaf.ts
var fs7 = __toESM(require("node:fs/promises"));
var path8 = __toESM(require("node:path"));
var import_node_crypto4 = require("node:crypto");
var mafRuntimeHash = (runtime) => sha256(canonicalJson(runtime));
var mafActionHash = (action) => sha256(canonicalJson(action));
var hashOk = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
function validateMafAction(action) {
  return !!action && Object.keys(action).sort().join(",") === "content,filename,tool" && action.tool === "write_artifact" && typeof action.filename === "string" && /^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}\.txt$/.test(action.filename) && !/^(con|prn|aux|nul|com[0-9]|lpt[0-9])\./i.test(action.filename) && typeof action.content === "string" && Buffer.byteLength(action.content) > 0 && Buffer.byteLength(action.content) <= 16384 && !action.content.includes("\0");
}
async function verifyMafRuntime(runtime, expectedHash, python, pythonHash) {
  if (!runtime || runtime.schema !== "datapass.maf-runtime/1" || mafRuntimeHash(runtime) !== expectedHash || runtime.python !== python || runtime.pythonSha256 !== pythonHash || ![runtime.python, runtime.worker, runtime.sitePackages].every((p) => isPlausibleLocalPath(p) && !hasLinkedAncestor(p)) || !hashOk(runtime.workerSha256) || !Array.isArray(runtime.files) || !runtime.files.length || runtime.files.length > 1e4) throw Error("Exact host-registered MAF runtime is required.");
  const workerStat = await fs7.lstat(runtime.worker);
  if (!workerStat.isFile() || workerStat.size > 256 * 1024) throw Error("Invalid bounded MAF worker.");
  const worker = await fs7.readFile(runtime.worker);
  if (worker.length > 256 * 1024 || (0, import_node_crypto4.createHash)("sha256").update(worker).digest("hex") !== runtime.workerSha256) throw Error("MAF worker bytes changed.");
  const expected = /* @__PURE__ */ new Map();
  for (const f of runtime.files) {
    if (!f || typeof f.path !== "string" || f.path.length > 300 || f.path.includes("\\") || f.path.split("/").some((p) => !p || p === "." || p === "..") || path8.isAbsolute(f.path) || !hashOk(f.sha256) || expected.has(f.path)) throw Error("Invalid MAF import inventory.");
    expected.set(f.path, f.sha256);
  }
  let count = 0, bytes = 0;
  const walk = async (directory, relative3 = "") => {
    for (const entry of await fs7.readdir(directory, { withFileTypes: true })) {
      const name2 = relative3 + entry.name, full = path8.join(directory, entry.name);
      if (entry.isSymbolicLink() || hasLinkedAncestor(full)) throw Error("Linked MAF runtime file denied.");
      if (entry.isDirectory()) {
        await walk(full, name2 + "/");
        continue;
      }
      if (!entry.isFile() || ++count > 1e4 || !expected.has(name2)) throw Error("MAF import tree changed.");
      const stat4 = await fs7.lstat(full);
      if (!stat4.isFile() || bytes + stat4.size > 256 * 1024 * 1024) throw Error("Oversized MAF runtime.");
      const content = await fs7.readFile(full);
      bytes += content.length;
      if (bytes > 256 * 1024 * 1024 || (0, import_node_crypto4.createHash)("sha256").update(content).digest("hex") !== expected.get(name2)) throw Error("MAF import bytes changed.");
    }
  };
  await walk(runtime.sitePackages);
  if (count !== expected.size) throw Error("MAF import file missing.");
}

// src/provider-kit/nativeTransport.ts
var nativeTransportVersion = "1.0.3";
var nativeHash = (value) => sha256(canonicalJson(value));
function nativeSelectionBinding(selection) {
  const s2 = structuredClone(selection), proof = s2.startup.platformProof;
  if (proof) {
    const { issuedAt, expiresAt, ...stable } = proof.payload;
    s2.startup.platformProof = { ...proof, signature: "", payload: { ...stable, issuedAt: "", expiresAt: "" } };
  }
  return nativeHash(s2);
}
var hashOk2 = (v) => typeof v === "string" && /^[a-f0-9]{64}$/.test(v);
var nativeIdOk = (v) => typeof v === "string" && /^[a-zA-Z0-9._:-]{1,160}$/.test(v);
var identityOk = (v) => typeof v === "string" && /^[a-zA-Z0-9._:/-]{1,160}$/.test(v);
async function executableHash(file, expectedBytes) {
  const hash2 = (0, import_node_crypto5.createHash)("sha256");
  let bytes = 0;
  for await (const chunk of (0, import_node_fs.createReadStream)(file)) {
    bytes += chunk.length;
    if (bytes > 512 * 1024 * 1024) throw Error("Executable exceeds bounded verification");
    hash2.update(chunk);
  }
  if (bytes !== expectedBytes) throw Error("Executable changed during verification");
  return hash2.digest("hex");
}
function nativeToolPolicy(selection) {
  if (selection.transport === "maf-harness") return { configToolRefs: [], toolNames: ["write_artifact"] };
  if (selection.transport !== "claude-cli") return null;
  return selection.nativeTools ?? { configToolRefs: [], toolNames: selection.permission === "read-only" ? ["Read", "Glob", "Grep"] : ["Read", "Glob", "Grep", "Edit", "Write"] };
}
function validateNativeSelection(s2) {
  return !!s2 && ["codex-app-server", "codex-cli", "claude-cli", "maf-harness"].includes(s2.transport) && (s2.transport === "maf-harness" ? hashOk2(s2.mafRuntimeHash) && s2.nativeVersion === "agent-framework-core:1.23.0" && s2.permission === "workspace-write" && s2.requestedIdentity?.model === "offline-replay-v1" && s2.requestedIdentity.effort === null && s2.requestedIdentity.accountId === null && s2.providerHome === void 0 : s2.mafRuntimeHash === void 0) && [s2.executable, s2.cwd, s2.home, ...s2.providerHome === void 0 ? [] : [s2.providerHome]].every((p) => isPlausibleLocalPath(p) && !hasLinkedAncestor(p)) && hashOk2(s2.executableSha256) && identityOk(s2.nativeVersion) && nativeIdOk(s2.hostId) && ["read-only", "workspace-write"].includes(s2.permission) && !!s2.requestedIdentity && identityOk(s2.requestedIdentity.model) && (s2.requestedIdentity.effort === null || ["minimal", "low", "medium", "high", "xhigh", "max"].includes(s2.requestedIdentity.effort)) && (s2.requestedIdentity.accountId === null || identityOk(s2.requestedIdentity.accountId)) && (s2.nativeTools === void 0 || s2.transport === "claude-cli" && !!s2.nativeTools && Array.isArray(s2.nativeTools.configToolRefs) && s2.nativeTools.configToolRefs.length > 0 && s2.nativeTools.configToolRefs.length <= 20 && s2.nativeTools.configToolRefs.every(identityOk) && Array.isArray(s2.nativeTools.toolNames) && s2.nativeTools.toolNames.length > 0 && s2.nativeTools.toolNames.length <= 8 && new Set(s2.nativeTools.toolNames).size === s2.nativeTools.toolNames.length && s2.nativeTools.toolNames.every((t) => ["Read", "Glob", "Grep", "Edit", "Write", "Bash", "Agent", "Task"].includes(t))) && !!s2.startup && hashOk2(s2.startup.reviewHash) && hashOk2(s2.startup.configurationHash) && ["NONE", "REVIEWED"].includes(s2.startup.hooks) && ["NONE", "REVIEWED"].includes(s2.startup.mcp) && ["NONE", "REVIEWED"].includes(s2.startup.managed) && typeof s2.startup.isolated === "boolean" && Array.isArray(s2.startup.supported) && s2.startup.supported.length <= 40 && s2.startup.supported.every(identityOk);
}
async function preflightNativeTransport(selection, trustedKeys = [], mafRuntime) {
  const s2 = structuredClone(selection), reasons = [];
  let installed = "UNKNOWN", configured = "UNKNOWN";
  if (!validateNativeSelection(s2)) throw Error("Invalid native transport selection.");
  for (const directory of [s2.cwd, s2.home, s2.providerHome ?? s2.home]) {
    try {
      if (!(await fs8.lstat(directory)).isDirectory() || hasLinkedAncestor(directory)) reasons.push("Reviewed directories must be real local directories.");
    } catch {
      reasons.push("Reviewed directory is unavailable.");
    }
  }
  try {
    const stat4 = await fs8.lstat(s2.executable);
    if (!stat4.isFile() || stat4.isSymbolicLink() || /\.(cmd|bat|ps1|sh|js|cjs|mjs)$/i.test(s2.executable) || stat4.size > 512 * 1024 * 1024 || await executableHash(s2.executable, stat4.size) !== s2.executableSha256) reasons.push("Exact native executable hash is unavailable or changed.");
    else installed = "EXACT_BINARY_VERIFIED";
  } catch {
    reasons.push("Exact native executable is unavailable.");
  }
  if (s2.transport === "maf-harness") try {
    await verifyMafRuntime(mafRuntime, s2.mafRuntimeHash, s2.executable, s2.executableSha256);
  } catch {
    reasons.push("Exact host-registered MAF worker/import inventory is missing or changed.");
  }
  const current = await captureNativeStartupManifest(s2);
  if (!s2.startup.manifest || nativeHash(s2.startup.manifest) !== nativeHash(current) || s2.startup.configurationHash !== current.manifestHash || s2.startup.reviewHash !== nativeStartupReviewHash(s2, current)) reasons.push("Exact Agent startup manifest/review proof is missing or changed.");
  else if (current.localState !== "VERIFIED_NO_CUSTOMIZATIONS") reasons.push("Local startup sources/customizations are incomplete or unreviewed.");
  else configured = "LOCAL_MANIFEST_VERIFIED";
  const platform = verifyNativePlatformProof(s2, current, trustedKeys, nativeHash(nativeEnvironment(s2)), nativeHash(nativeToolPolicy(s2)));
  if (platform.state === "UNKNOWN") reasons.push(platform.reason);
  if (s2.startup.hooks !== "NONE" || s2.startup.mcp !== "NONE") reasons.push("Hook/MCP startup effects require complete dependency verification; declarations cannot authorize them.");
  if (!s2.startup.isolated) reasons.push("Verified isolated native execution host is required.");
  const required = s2.transport === "maf-harness" ? ["maf/1", "exact-tool-approval", "offline-replay", "owned-process"] : s2.transport === "codex-app-server" ? ["initialize", "thread/start", "thread/resume", "turn/start", "turn/interrupt"] : s2.transport === "codex-cli" ? ["exec", "json", "resume", "sandbox"] : ["print", "stream-json", "resume", "restricted", "tools", "strict-mcp-config", "mcp-config", "permission-mode", "input-format", "include-partial-messages", "verbose", "disallowedTools"];
  if (required.some((cap) => !s2.startup.supported.includes(cap))) reasons.push("Installed native version lacks a reviewed required capability.");
  if (s2.transport === "claude-cli" && s2.requestedIdentity.effort !== null && !s2.startup.supported.includes("effort")) reasons.push("Requested effort is not supported by this installed version.");
  if (s2.permission === "read-only" && s2.nativeTools?.toolNames.some((t) => ["Edit", "Write"].includes(t))) reasons.push("Read-only permission cannot select native file write tools.");
  return {
    schema: "datapass.native-preflight/1",
    version: nativeTransportVersion,
    state: reasons.length ? "BLOCKED" : "READY",
    selectionHash: nativeHash(s2),
    reasons,
    verification: { installed, configured, authenticated: "UNKNOWN", working: "UNKNOWN", platform, capabilities: platform.state === "TRUSTED_VERIFIER_REPORTED" ? "TRUSTED_VERIFIER_REPORTED" : "ASSERTED" },
    limitations: s2.transport === "maf-harness" ? ["Offline replay backend only; no live provider, general file access, shell, skills or subprocess tools.", "One exact host-reviewed artifact action. Completed receipt lookup does not re-execute a task; unknown outcomes require reconciliation."] : s2.transport === "claude-cli" ? ["Print CLI has no verified human permission-response transport; native denial/manual handling remains authoritative.", "Default restricted file tools do not imply Bash, testing, subagent or full task capability. Explicit mapped Config tools require the exact signed tool policy and descendant isolation.", "No --allowedTools, bypass, auto-approval or permission elevation flag."] : ["Provider-owned tools remain unprobed; installed/configured/startup-safe does not certify testing, tool execution, subagent support or account entitlement.", "Native permission requests are refused for native/manual handling."],
    tools: { policy: s2.transport === "maf-harness" ? "EXACT_MAF_ACTION" : s2.transport !== "claude-cli" ? "NATIVE_PROVIDER_OWNED_UNPROBED" : s2.nativeTools ? "MAPPED_REPORTED_UNPROBED" : "RESTRICTED_DEFAULT_UNPROBED", toolNames: nativeToolPolicy(s2)?.toolNames ?? null, working: "UNKNOWN", humanApprovalRoundTrip: s2.transport === "maf-harness" ? "EXACT_HOST_REVIEW" : s2.transport === "claude-cli" ? "UNSUPPORTED_CLI_MANUAL" : "NATIVE_REFUSAL" },
    capabilities: { start: !reasons.length, stream: !reasons.length, resume: !reasons.length && s2.transport !== "maf-harness", cancel: s2.transport === "codex-app-server" ? "OWNED_TURN" : "OWNED_PROCESS", securityRequests: "NATIVE_REFUSAL", observedIdentity: "PROVIDER_EVIDENCE_ONLY" }
  };
}
function prepareNativeTask(input) {
  const i = structuredClone(input);
  if (i.selection?.transport === "maf-harness" ? !validateMafAction(i.mafAction) || i.resumeFromTaskId !== void 0 : i.mafAction !== void 0) throw Error("Exact MAF action is required; process replay/resume is not an execution permission.");
  if (!validateNativeSelection(i.selection) || !nativeIdOk(i.taskId) || typeof i.text !== "string" || !i.text.trim() || Buffer.byteLength(i.text) > 64 * 1024 || i.text.includes("\0") || ![i.targetHash, i.permissionHash, i.configHash, i.presetHash, i.promptHash, i.bindingHash, i.scopeHash, i.configScopeHash].every(hashOk2) || i.resumeFromTaskId !== void 0 && !nativeIdOk(i.resumeFromTaskId)) throw Error("Invalid exact prepared native task.");
  const task = { ...i, schema: "datapass.native-task/1" };
  return { ...task, preparedHash: nativeHash(task) };
}
function nativeLaunchArguments(task, resumeId, mafRuntime) {
  const s2 = task.selection;
  if (s2.transport === "maf-harness") {
    if (!mafRuntime || resumeId !== void 0) throw Error("Registered MAF runtime required; resume execution is unsupported.");
    return ["-I", "-S", "-B", mafRuntime.worker, "--site-packages", mafRuntime.sitePackages];
  }
  if (resumeId !== void 0 && !nativeIdOk(resumeId)) throw Error("Invalid owned native session.");
  if (s2.transport === "codex-app-server") return ["-c", 'cli_auth_credentials_store="file"', "app-server", "--listen", "stdio://"];
  if (s2.transport === "codex-cli") {
    const args = ["exec", ...resumeId ? ["resume", resumeId] : [], "--json", "-c", 'cli_auth_credentials_store="file"', "-c", 'approval_policy="never"', "-c", `sandbox_mode="${s2.permission}"`, "-c", "sandbox_workspace_write.network_access=false", "--model", s2.requestedIdentity.model];
    if (s2.requestedIdentity.effort) args.push("-c", `model_reasoning_effort="${s2.requestedIdentity.effort}"`);
    return [...args, "-"];
  }
  const tools = nativeToolPolicy(s2).toolNames.join(",");
  return ["--print", "--input-format", "text", "--output-format", "stream-json", "--verbose", "--include-partial-messages", "--restricted", "--permission-mode", "default", "--tools", tools, "--disallowedTools", "mcp__*", "--strict-mcp-config", "--mcp-config", '{"mcpServers":{}}', "--model", s2.requestedIdentity.model, ...s2.requestedIdentity.effort ? ["--effort", s2.requestedIdentity.effort] : [], ...resumeId ? ["--resume", resumeId] : []];
}
function nativeEnvironment(selection) {
  if (selection.transport === "maf-harness") return { HOME: selection.home, USERPROFILE: selection.home, ...process.platform === "win32" ? { SystemRoot: process.env.SystemRoot } : {} };
  const providerHome = selection.providerHome ?? selection.home;
  return { HOME: selection.home, USERPROFILE: selection.home, CODEX_HOME: providerHome, CLAUDE_CONFIG_DIR: providerHome, ...process.platform === "win32" ? { SystemRoot: process.env.SystemRoot } : {} };
}

// src/provider-kit/nativeRunner.ts
var fs10 = __toESM(require("node:fs/promises"));
var fsSync = __toESM(require("node:fs"));
var path10 = __toESM(require("node:path"));
var import_node_child_process2 = require("node:child_process");
var import_node_crypto6 = require("node:crypto");

// src/provider-kit/nativeProjectScope.ts
var path9 = __toESM(require("node:path"));
var fs9 = __toESM(require("node:fs/promises"));
var import_node_child_process = require("node:child_process");
async function verifyNativeProjectScope(input) {
  if (!input || ![input.organizationId, input.privacyDomainId, input.projectId].every(nativeIdOk) || !/^[a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+$/.test(input.repoId) || !isPlausibleLocalPath(input.root) || hasLinkedAncestor(input.root) || !/^[a-f0-9]{40}$/.test(input.revision) || ![input.sourceVectorHash, input.policyHash].every(hashOk2)) throw Error("Invalid exact project execution scope.");
  const observed = await readNativeRepositoryIdentity(input.root);
  const canonical = (s2) => process.platform === "win32" ? path9.resolve(s2).toLowerCase() : path9.resolve(s2);
  if (canonical(observed.root) !== canonical(input.root) || observed.revision !== input.revision || observed.repoId.toLowerCase() !== input.repoId.toLowerCase()) throw Error("Exact project root, canonical origin or revision changed.");
}
async function readNativeRepositoryIdentity(root) {
  if (!isPlausibleLocalPath(root) || hasLinkedAncestor(root) || !(await fs9.lstat(root)).isDirectory()) throw Error("Reviewed project root is unavailable.");
  const git = resolveExe("git");
  if (!git) throw Error("Git identity verification unavailable.");
  const env = { GIT_TERMINAL_PROMPT: "0" };
  for (const key of ["PATH", "Path", "SystemRoot"]) if (process.env[key]) env[key] = process.env[key];
  const read = (args) => new Promise((resolve9, reject) => (0, import_node_child_process.execFile)(git, [...HARDEN, "-c", "core.hooksPath=NUL", ...args], { cwd: root, env, shell: false, windowsHide: true, timeout: 1e4, maxBuffer: 64 * 1024 }, (error, out) => error ? reject(Error("Project Git identity unavailable.")) : resolve9(out.toString().trim())));
  const [worktree, head, remote, common] = await Promise.all([read(["rev-parse", "--show-toplevel"]), read(["rev-parse", "HEAD"]), read(["config", "--get", "remote.origin.url"]), read(["rev-parse", "--git-common-dir"])]);
  const match = /^(?:https:\/\/|git@)(github\.com|gitlab\.com)(?:\/|:)([a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+?)(?:\.git)?$/.exec(remote);
  if (!match || !/^[a-f0-9]{40}$/.test(head)) throw Error("Exact project canonical origin or revision unavailable.");
  const commonDirectory = await fs9.realpath(path9.resolve(root, common));
  if (hasLinkedAncestor(commonDirectory)) throw Error("Linked Git metadata denied.");
  return { root: await fs9.realpath(worktree), revision: head, repoId: match[2], remoteHost: match[1], commonDirectory };
}

// src/provider-kit/nativeRunner.ts
var NativeTaskRunner = class {
  constructor(ledgerDirectory, spawnProcess = import_node_child_process2.spawn, platformVerifiers = () => [], mafRuntime) {
    this.ledgerDirectory = ledgerDirectory;
    this.spawnProcess = spawnProcess;
    this.platformVerifiers = platformVerifiers;
    this.mafRuntime = mafRuntime;
    this.mafRuntime = mafRuntime ? structuredClone(mafRuntime) : void 0;
    let ancestor = ledgerDirectory;
    while (!fsSync.existsSync(ancestor) && ancestor !== path10.dirname(ancestor)) ancestor = path10.dirname(ancestor);
    if (!isPlausibleLocalPath(ledgerDirectory) || hasLinkedAncestor(ancestor)) throw Error("A real owned ledger directory is required.");
  }
  live = /* @__PURE__ */ new Map();
  preflight(selection) {
    return preflightNativeTransport(selection, this.platformVerifiers(), this.mafRuntime);
  }
  file(id) {
    if (!nativeIdOk(id)) throw Error("Invalid owned task identity.");
    return path10.join(this.ledgerDirectory, nativeHash(id) + ".json");
  }
  async lookup(id) {
    if (this.live.has(id)) return this.live.get(id).handle.observation();
    try {
      if (!fsSync.existsSync(this.ledgerDirectory)) return null;
      if (hasLinkedAncestor(this.ledgerDirectory)) throw Error("Linked ledger denied.");
      const file = this.file(id);
      if (!fsSync.existsSync(file)) return null;
      if (hasLinkedAncestor(file)) throw Error("Linked ledger file denied.");
      const raw = await fs10.readFile(file, "utf8");
      if (raw.length > 128 * 1024) throw Error("Oversize ledger.");
      const o = JSON.parse(raw);
      if (o.schema !== "datapass.native-task-observation/1" || o.taskId !== id) throw Error("Invalid task ledger.");
      if (["SPAWN_INTENT", "RUNNING", "NEEDS_INPUT"].includes(o.state)) return { ...o, state: "UNCERTAIN", reason: "Prior owned process outcome is unknown; no blind retry or automatic resume." };
      return o;
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw e;
    }
  }
  async cancel(id) {
    const live = this.live.get(id);
    if (!live) throw Error("Cancel is limited to an active process owned by this host instance.");
    return live.cancel();
  }
  async dispose() {
    await Promise.allSettled([...this.live.values()].map((t) => t.cancel()));
  }
  async start(input, reviewedHash, stillAuthorized = () => true) {
    const task = structuredClone(input), { schema, preparedHash, ...i } = task;
    if (schema !== "datapass.native-task/1" || prepareNativeTask(i).preparedHash !== preparedHash || reviewedHash !== preparedHash || !stillAuthorized()) throw Error("Exact prepared task approval is required.");
    const preflight = await this.preflight(task.selection);
    if (preflight.state !== "READY") throw Error("Native startup blocked: " + preflight.reasons.join(" "));
    let resumeId;
    if (task.resumeFromTaskId) {
      const prior = await this.lookup(task.resumeFromTaskId);
      if (!prior || !["COMPLETED", "INTERRUPTED"].includes(prior.state) || prior.quiescence !== "NATIVE_TURN_SETTLED" || !prior.sessionId || prior.selectionHash !== nativeSelectionBinding(task.selection) || prior.targetHash !== task.targetHash || prior.permissionHash !== task.permissionHash || prior.configHash !== task.configHash || prior.presetHash !== task.presetHash || prior.bindingHash !== task.bindingHash || prior.scopeHash !== task.scopeHash || prior.configScopeHash !== task.configScopeHash) throw Error("Resume requires an owned settled native session with unchanged reviewed target, configuration and permission.");
      resumeId = prior.sessionId;
    }
    await fs10.mkdir(this.ledgerDirectory, { recursive: true });
    if (hasLinkedAncestor(this.ledgerDirectory) || !stillAuthorized()) throw Error("Owned ledger/authority changed before launch.");
    const filename = this.file(task.taskId), selection = task.selection;
    let observation = { schema: "datapass.native-task-observation/1", taskId: task.taskId, preparedHash, selectionHash: nativeSelectionBinding(selection), targetHash: task.targetHash, permissionHash: task.permissionHash, configHash: task.configHash, presetHash: task.presetHash, promptHash: task.promptHash, bindingHash: task.bindingHash, scopeHash: task.scopeHash, configScopeHash: task.configScopeHash, state: "SPAWN_INTENT", sessionId: resumeId ?? null, turnId: null, sequence: 0, requestedIdentity: selection.requestedIdentity, observedIdentity: { model: null, effort: null, accountId: null }, resultText: "", resultHash: null, reason: null, updatedAt: (/* @__PURE__ */ new Date()).toISOString(), evidence: "NO_COMPLETION_EVIDENCE", quiescence: "UNKNOWN" };
    const intent = await fs10.open(filename, "wx", 384);
    try {
      await intent.writeFile(JSON.stringify(observation));
      await intent.sync();
    } finally {
      await intent.close();
    }
    const mafDirectory = selection.transport === "maf-harness" ? path10.join(this.ledgerDirectory, "maf-" + preparedHash) : void 0;
    if (mafDirectory) {
      await fs10.mkdir(mafDirectory);
      const fd = await fs10.open(path10.join(mafDirectory, "host-approval.json"), "wx", 384);
      try {
        await fd.writeFile(JSON.stringify({ schema: "datapass.maf-host-approval/1", taskId: task.taskId, preparedHash, scopeHash: task.scopeHash, actionHash: mafActionHash(task.mafAction), runtimeHash: selection.mafRuntimeHash }));
        await fd.sync();
      } finally {
        await fd.close();
      }
    }
    const lease = resumeId ? path10.join(this.ledgerDirectory, "session-" + nativeHash(resumeId) + ".lease") : void 0;
    if (lease) {
      const fd = await fs10.open(lease, "wx", 384);
      try {
        await fd.writeFile(task.taskId);
        await fd.sync();
      } finally {
        await fd.close();
      }
    }
    const repoLeases = [];
    if (selection.permission === "workspace-write") {
      const identity = await readNativeRepositoryIdentity(selection.cwd);
      const keys = [nativeHash({ host: identity.remoteHost, repo: identity.repoId.toLowerCase() }), nativeHash(process.platform === "win32" ? identity.commonDirectory.toLowerCase() : identity.commonDirectory)];
      try {
        for (const key of [...new Set(keys)].sort()) {
          const file = path10.join(this.ledgerDirectory, "repo-" + key + ".lease"), fd = await fs10.open(file, "wx", 384);
          try {
            await fd.writeFile(JSON.stringify({ taskId: task.taskId, preparedHash, identityHash: nativeHash(identity) }));
            await fd.sync();
          } finally {
            await fd.close();
          }
          repoLeases.push(file);
        }
      } catch (e) {
        for (const file of repoLeases) await fs10.unlink(file);
        throw Error("Another owned native writer or uncertain write lease holds this canonical repository.");
      }
    }
    let child, finished = false, cancelRequested = false, cliCompleted = false, nativeTerminal = false, buffer = "", resultText = "", queued = Promise.resolve();
    let mafStarted = false, mafApproved = false;
    const mafBinding = { schema: "datapass.maf-wire/1", taskId: task.taskId, preparedHash, scopeHash: task.scopeHash, sessionId: "maf:" + preparedHash };
    let complete;
    const result = new Promise((resolve9) => {
      complete = resolve9;
    });
    const listeners = /* @__PURE__ */ new Set();
    const messageLines = /* @__PURE__ */ new Map(), completedMessages = /* @__PURE__ */ new Set();
    const snapshot = () => structuredClone(observation);
    const persist = async (value) => {
      const temporary = filename + "." + (0, import_node_crypto6.randomUUID)() + ".tmp", fd = await fs10.open(temporary, "wx", 384);
      try {
        await fd.writeFile(JSON.stringify(value));
        await fd.sync();
      } finally {
        await fd.close();
      }
      await fs10.rename(temporary, filename);
    };
    const emit = (type) => {
      for (const fn of listeners) try {
        fn({ type, observation: snapshot() });
      } catch {
      }
    };
    const update = async (fields, type = "STATE") => {
      const next = { ...observation, ...fields, sequence: observation.sequence + 1, updatedAt: (/* @__PURE__ */ new Date()).toISOString() };
      await persist(next);
      observation = next;
      emit(type);
    };
    const enqueue = (action) => {
      queued = queued.then(action).catch(() => {
        finished = true;
        observation = { ...observation, state: "UNCERTAIN", reason: "Durable native state commit failed; do not retry." };
        child?.kill();
        clearTimeout(timeout);
        clearInterval(authorityWatch);
        this.live.delete(task.taskId);
        complete(snapshot());
      });
    };
    const finish = async (state, reason = null, settled = false) => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      clearInterval(authorityWatch);
      await update({ state, reason, resultText: boundedMultiline(resultText, 32 * 1024), resultHash: resultText ? nativeHash(boundedMultiline(resultText, 32 * 1024)) : null, evidence: state === "COMPLETED" ? "NATIVE_REPORTED" : "NO_COMPLETION_EVIDENCE", quiescence: settled ? "NATIVE_TURN_SETTLED" : "UNKNOWN" });
      if (lease && settled) await fs10.unlink(lease);
      if (settled) for (const file of repoLeases) await fs10.unlink(file);
      this.live.delete(task.taskId);
      complete(snapshot());
      child?.stdin.end();
      child?.kill();
    };
    const send = (value) => {
      if (!child || !child.stdin.writable) throw Error("Owned native stdin closed.");
      child.stdin.write(JSON.stringify(value) + "\n");
    };
    const cancel = async () => {
      if (finished) return snapshot();
      cancelRequested = true;
      if (selection.transport === "codex-app-server" && observation.sessionId && observation.turnId) {
        send({ id: 4, method: "turn/interrupt", params: { threadId: observation.sessionId, turnId: observation.turnId } });
      } else child?.kill();
      return snapshot();
    };
    const handle = { taskId: task.taskId, observation: snapshot, result, subscribe: (fn) => {
      if (listeners.size >= 20) throw Error("Native subscription bound exceeded.");
      listeners.add(fn);
      return { dispose: () => listeners.delete(fn) };
    }, cancel };
    this.live.set(task.taskId, { handle, cancel });
    const timeout = setTimeout(() => {
      enqueue(() => finish("UNCERTAIN", "Native completion deadline reached; owned process cancellation requested, no automatic retry."));
    }, 10 * 60 * 1e3);
    const authorityWatch = setInterval(() => {
      if (!finished && !stillAuthorized()) enqueue(() => finish("UNCERTAIN", "Reviewed authority was revoked; owned process stopped, native descendants require reconciliation."));
    }, 250);
    const threadParams = { cwd: selection.cwd, model: selection.requestedIdentity.model, approvalPolicy: "never", sandbox: selection.permission, ...resumeId ? { threadId: resumeId } : {} };
    const turnParams = () => ({ threadId: observation.sessionId, input: [{ type: "text", text: task.text }], cwd: selection.cwd, model: selection.requestedIdentity.model, ...selection.requestedIdentity.effort ? { effort: selection.requestedIdentity.effort } : {}, approvalPolicy: "never", sandboxPolicy: selection.permission === "read-only" ? { type: "readOnly", networkAccess: false } : { type: "workspaceWrite", writableRoots: [selection.cwd], networkAccess: false } });
    const consume = async (message) => {
      if (finished) return;
      if (!stillAuthorized()) {
        await cancel();
        return;
      }
      if (selection.transport === "maf-harness") {
        if (cancelRequested) return;
        if (!message || Object.entries(mafBinding).some(([k, v]) => message[k] !== v) || nativeTerminal) {
          await finish("UNCERTAIN", "MAF event identity/order mismatch; retain the attempt and write lease.");
          return;
        }
        if (message.type === "started" && !mafStarted) {
          mafStarted = true;
          await update({ sessionId: mafBinding.sessionId, turnId: preparedHash, observedIdentity: { model: "offline-replay-v1", effort: null, accountId: null } });
          return;
        }
        if (message.type === "approval" && mafStarted && !mafApproved && typeof message.approvalId === "string" && message.approvalId.length <= 160 && message.actionHash === mafActionHash(task.mafAction)) {
          await update({ state: "NEEDS_INPUT" });
          const fd = await fs10.open(path10.join(mafDirectory, "tool-approval.json"), "wx", 384);
          try {
            await fd.writeFile(JSON.stringify({ ...mafBinding, approvalId: message.approvalId, actionHash: message.actionHash, approved: true }));
            await fd.sync();
          } finally {
            await fd.close();
          }
          if (cancelRequested || !stillAuthorized()) {
            await cancel();
            return;
          }
          mafApproved = true;
          send({ ...mafBinding, type: "approval-response", approvalId: message.approvalId, actionHash: message.actionHash, approved: true });
          await update({ state: "RUNNING" });
          return;
        }
        if (message.type === "completed" && mafStarted && mafApproved && message.actionHash === mafActionHash(task.mafAction)) {
          const artifact = message.artifact, artifactFile = path10.join(selection.cwd, task.mafAction.filename), sessionFile = path10.join(mafDirectory, "session.json");
          if (!artifact || artifact.filename !== task.mafAction.filename || artifact.bytes !== Buffer.byteLength(task.mafAction.content) || artifact.sha256 !== (0, import_node_crypto6.createHash)("sha256").update(task.mafAction.content).digest("hex") || hasLinkedAncestor(artifactFile) || hasLinkedAncestor(sessionFile)) throw Error("MAF artifact identity mismatch.");
          const artifactStat = await fs10.lstat(artifactFile), sessionStat = await fs10.lstat(sessionFile);
          if (!artifactStat.isFile() || artifactStat.size !== artifact.bytes || !sessionStat.isFile() || sessionStat.size > 1024 * 1024) throw Error("MAF evidence is not a bounded regular file.");
          const bytes = await fs10.readFile(artifactFile), session = await fs10.readFile(sessionFile);
          if (bytes.length !== artifact.bytes || (0, import_node_crypto6.createHash)("sha256").update(bytes).digest("hex") !== artifact.sha256 || session.length > 1024 * 1024 || (0, import_node_crypto6.createHash)("sha256").update(session).digest("hex") !== message.sessionSha256) throw Error("MAF artifact/session evidence changed.");
          resultText = "Wrote approved artifact " + artifact.filename;
          await update({ maf: { mode: "offline-replay", actionHash: message.actionHash, artifact: { filename: artifact.filename, sha256: artifact.sha256, bytes: artifact.bytes }, sessionSha256: message.sessionSha256 } });
          cliCompleted = true;
          nativeTerminal = true;
          return;
        }
        await finish("UNCERTAIN", "Unrecognized MAF event or tool request; no additional action is authorized.");
        return;
      } else if (selection.transport === "codex-app-server") {
        if (message.error) {
          await finish("FAILED", "Native protocol request failed.");
          return;
        }
        if (message.id === 0 && message.result) {
          send({ method: "initialized", params: {} });
          send({ id: 1, method: resumeId ? "thread/resume" : "thread/start", params: threadParams });
          return;
        }
        if (message.id === 1 && message.result?.thread) {
          const thread = message.result.thread;
          if (!nativeIdOk(thread.id) || resumeId && thread.id !== resumeId) {
            await finish("UNCERTAIN", "Native thread identity mismatch.");
            return;
          }
          await update({ sessionId: thread.id, observedIdentity: { model: typeof message.result.model === "string" ? bounded(message.result.model, 160) : null, effort: null, accountId: null } });
          send({ id: 2, method: "turn/start", params: turnParams() });
          return;
        }
        if (message.id === 2 && message.result?.turn) {
          const t = message.result.turn;
          if (!nativeIdOk(t.id)) {
            await finish("UNCERTAIN", "Invalid native turn identity.");
            return;
          }
          await update({ turnId: t.id });
          return;
        }
        if (message.method && message.id !== void 0) {
          send({ id: message.id, error: { code: -32e3, message: "Agent transport requires native/manual handling for server requests." } });
          await finish("INTERRUPTED", "Native input/security request requires the owned native interface; refused automatically.");
          return;
        }
        const p = message.params;
        if (!p || p.threadId !== observation.sessionId || observation.turnId && (p.turnId ?? p.turn?.id) !== observation.turnId) return;
        if (message.method === "item/agentMessage/delta") {
          if (observation.turnId && p.turnId === observation.turnId && nativeIdOk(p.itemId) && typeof p.delta === "string" && !completedMessages.has(p.itemId)) {
            if (!messageLines.has(p.itemId) && messageLines.size >= 16) {
              await finish("UNCERTAIN", "Native message stream exceeded bounded item limit.");
              return;
            }
            const accumulated = (messageLines.get(p.itemId) ?? "") + p.delta;
            if (Buffer.byteLength(accumulated) > 64 * 1024) {
              await finish("UNCERTAIN", "Native message stream exceeded bounded text limit.");
              return;
            }
            messageLines.set(p.itemId, accumulated);
            const boundary = accumulated.lastIndexOf("\n");
            if (boundary >= 0) {
              const safe = boundedMultiline(accumulated.slice(0, boundary + 1), 32 * 1024);
              if (safe !== resultText) {
                resultText = safe;
                await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
                return;
              }
            }
          }
          await update({}, "PROGRESS");
          return;
        }
        if (message.method === "item/completed" && p.item?.type === "agentMessage" && typeof p.item.text === "string") {
          if (nativeIdOk(p.item.id)) {
            messageLines.delete(p.item.id);
            if (completedMessages.size < 256) completedMessages.add(p.item.id);
          }
          resultText = boundedMultiline(p.item.text, 32 * 1024);
          await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
        }
        if (message.method === "turn/completed") {
          if (!observation.turnId && nativeIdOk(p.turn?.id)) await update({ turnId: p.turn.id });
          if (p.turn?.id !== observation.turnId) {
            await finish("UNCERTAIN", "Native completion identity mismatch.");
            return;
          }
          if (!["completed", "failed", "interrupted"].includes(p.turn.status)) {
            await finish("UNCERTAIN", "Unknown native terminal status; retain owned leases.");
            return;
          }
          await finish(p.turn.status === "completed" ? "COMPLETED" : p.turn.status === "interrupted" ? "INTERRUPTED" : "FAILED", p.turn.status === "completed" ? null : "Native turn did not complete successfully.", true);
        }
      } else if (selection.transport === "codex-cli") {
        if (message.type === "thread.started" && nativeIdOk(message.thread_id)) {
          if (resumeId && resumeId !== message.thread_id) {
            await finish("UNCERTAIN", "Resumed native session mismatch.");
            return;
          }
          await update({ sessionId: message.thread_id });
        } else if (message.type === "item.completed" && message.item?.type === "agent_message" && typeof message.item.text === "string") {
          resultText = boundedMultiline(message.item.text, 32 * 1024);
          await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
        } else if (message.type === "turn.completed") {
          if (observation.sessionId) {
            cliCompleted = true;
            nativeTerminal = true;
          } else await finish("UNCERTAIN", "Native session identity missing.");
        } else if (message.type === "turn.failed") {
          nativeTerminal = true;
          await update({ reason: "Native CLI reported failed turn." });
        } else if (message.type === "error") await finish("FAILED", "Native CLI reported failure.");
        else if (message.type === "item.started") await update({}, "PROGRESS");
      } else {
        if (message.type === "system" && message.subtype === "init") {
          if (!nativeIdOk(message.session_id) || resumeId && resumeId !== message.session_id) {
            await finish("UNCERTAIN", "Native session identity mismatch.");
            return;
          }
          await update({ sessionId: message.session_id, observedIdentity: { model: typeof message.model === "string" ? bounded(message.model, 160) : null, effort: null, accountId: null } });
        } else if (message.type === "stream_event") await update({}, "PROGRESS");
        else if (message.type === "assistant") {
          const text = Array.isArray(message.message?.content) ? message.message.content.filter((b) => b.type === "text" && typeof b.text === "string").map((b) => b.text).join("\n") : "";
          if (text) {
            resultText = boundedMultiline(text, 32 * 1024);
            await update({ resultText, resultHash: nativeHash(resultText) }, "MESSAGE");
          }
        } else if (message.type === "result") {
          if (message.session_id !== observation.sessionId) {
            await finish("UNCERTAIN", "Native result session mismatch.");
            return;
          }
          if (typeof message.result === "string") resultText = boundedMultiline(message.result, 32 * 1024);
          nativeTerminal = true;
          if (!message.is_error && message.subtype === "success") cliCompleted = true;
          else await update({ reason: "Native CLI reported failed result." });
        }
      }
    };
    try {
      if (!stillAuthorized()) throw Error("Native authority revoked before spawn.");
      const immediate = await this.preflight(selection);
      if (immediate.state !== "READY") throw Error("Native startup proof drifted before process creation.");
      child = this.spawnProcess(selection.executable, nativeLaunchArguments(task, resumeId, this.mafRuntime), { cwd: selection.cwd, env: nativeEnvironment(selection), windowsHide: true, shell: false, stdio: ["pipe", "pipe", "pipe"] });
      child.on("error", () => enqueue(() => finish("UNCERTAIN", "Native process startup outcome uncertain; no blind retry.")));
      child.stdin.on("error", () => {
        if (!cancelRequested) enqueue(() => finish("UNCERTAIN", "Native stdin failed after launch; no blind retry."));
      });
      child.on("spawn", () => enqueue(async () => {
        if (finished || cancelRequested) {
          child?.kill();
          return;
        }
        await update({ state: "RUNNING" });
        if (finished || cancelRequested) {
          child?.kill();
          return;
        }
        if (selection.transport === "maf-harness") send({ ...mafBinding, type: "start", action: task.mafAction, cwd: selection.cwd, stateDirectory: mafDirectory });
        else if (selection.transport === "codex-app-server") send({ id: 0, method: "initialize", params: { clientInfo: { name: "datapass_agent", title: "DataPass Agent", version: "1.0.0" } } });
        else child.stdin.end(task.text + "\n");
      }));
      let totalBytes = 0, totalRecords = 0;
      child.stdout.setEncoding("utf8");
      child.stdout.on("data", (data) => {
        if (finished) return;
        buffer += data;
        totalBytes += Buffer.byteLength(data);
        if (buffer.length > 1024 * 1024 || totalBytes > 8 * 1024 * 1024) {
          enqueue(() => finish("UNCERTAIN", "Native output exceeded bounded parser limit."));
          return;
        }
        let newline;
        while ((newline = buffer.indexOf("\n")) >= 0) {
          const line = buffer.slice(0, newline);
          buffer = buffer.slice(newline + 1);
          if (!line.trim()) continue;
          if (++totalRecords > 2e4) {
            enqueue(() => finish("UNCERTAIN", "Native event count exceeded bounded parser limit."));
            return;
          }
          try {
            const message = JSON.parse(line);
            enqueue(() => consume(message));
          } catch {
            enqueue(() => finish("UNCERTAIN", "Malformed native event; no retry."));
          }
        }
      });
      child.stderr.on("data", () => {
      });
      child.on("close", (code, signal) => enqueue(async () => {
        if (buffer.trim()) {
          try {
            await consume(JSON.parse(buffer));
          } catch {
            await finish("UNCERTAIN", "Incomplete native event on process close.");
          }
        }
        if (!finished && selection.transport === "maf-harness" && !cancelRequested && !(code === 0 && cliCompleted)) {
          await finish("UNCERTAIN", "MAF worker exited without a verified successful terminal result; retain the attempt and write lease.");
          return;
        }
        if (!finished) await finish(cancelRequested ? "INTERRUPTED" : code === 0 && cliCompleted ? "COMPLETED" : nativeTerminal ? "FAILED" : code === 0 ? "UNCERTAIN" : "FAILED", cancelRequested ? "Owned process cancellation observed." : code === 0 && cliCompleted ? null : "Native process exited without a matching successful completion event.", !cancelRequested && nativeTerminal);
      }));
    } catch {
      await finish("UNCERTAIN", "Native spawn attempt could not be confirmed; intent is retained, no blind retry.");
    }
    return handle;
  }
};

// src/provider-kit/nativeFacade.ts
var fs11 = __toESM(require("node:fs/promises"));
var path11 = __toESM(require("node:path"));
var NativeTransportFacade = class {
  constructor(runner, policy, hostId, review, trusted = () => true, reviewProject = async () => false) {
    this.runner = runner;
    this.policy = policy;
    this.hostId = hostId;
    this.review = review;
    this.trusted = trusted;
    this.reviewProject = reviewProject;
    this.api = Object.freeze({
      major: 1,
      version: nativeTransportVersion,
      reviewProjectScope: async (i) => this.projectScope(i),
      captureStartup: async (r, s2) => {
        this.selection(r, s2);
        const selection = structuredClone(s2), manifest = await captureNativeStartupManifest(selection);
        selection.startup.manifest = manifest;
        selection.startup.configurationHash = manifest.manifestHash;
        selection.startup.reviewHash = nativeStartupReviewHash(selection, manifest);
        const check = await this.runner.preflight(selection);
        return { manifest, configurationHash: manifest.manifestHash, reviewHash: selection.startup.reviewHash, verification: check.verification };
      },
      preflight: async (r, s2) => {
        this.selection(r, s2);
        return this.runner.preflight(s2);
      },
      prepare: async (r, i) => this.prepare(r, i),
      review: async (r, h) => this.approve(r, h),
      start: async (r, i) => this.start(r, i),
      lookup: async (r, i) => this.lookup(r, i.taskId),
      cancel: async (r, i) => {
        await this.lookupRequired(r, i.taskId);
        return this.runner.cancel(i.taskId);
      },
      subscribe: async (r, i, listener) => {
        await this.lookupRequired(r, i.taskId);
        const handle = this.handles.get(i.taskId);
        if (!handle) throw Error("Owned live stream unavailable; poll the durable ledger.");
        return handle.subscribe((event) => {
          if (this.allowed(r, event.observation)) listener(event);
        });
      },
      getRoleRuntime: async (i) => this.roleRuntime(i)
    });
  }
  api;
  preparations = /* @__PURE__ */ new Map();
  handles = /* @__PURE__ */ new Map();
  executionPolicies = /* @__PURE__ */ new Map();
  projectScopes = /* @__PURE__ */ new Map();
  activePolicy(r) {
    const execution = this.executionPolicies.get(r?.scope?.scopeId);
    return execution?.authorize(r) ? execution : this.policy.authorize(r) ? this.policy : void 0;
  }
  async projectScope(input) {
    const i = structuredClone(input);
    if (!this.trusted()) throw Error("Trusted owned workspace is required.");
    await verifyNativeProjectScope(i);
    const { revision, ...stable } = i, scopeId = "native-project:" + nativeHash(stable).slice(0, 32), existing = this.executionPolicies.get(scopeId);
    if (existing && nativeHash(this.projectScopes.get(scopeId)) === nativeHash(i)) {
      const scope2 = existing.scopes()[0];
      return { approved: true, scope: scope2, epoch: existing.epoch, scopeHash: digest(scope2) };
    }
    const approved = await this.reviewProject(i);
    if (!approved) return { approved: false, scope: null, epoch: existing?.epoch ?? 0, scopeHash: null };
    if (!this.trusted()) throw Error("Workspace trust changed during local review.");
    await verifyNativeProjectScope(i);
    const scope = { scopeId, organizationIds: [i.organizationId], privacyDomainIds: [i.privacyDomainId], projectIds: [i.projectId], repoIds: [repoId(i.root)], sourceVectorHash: i.sourceVectorHash, policyHash: i.policyHash };
    if (!existing && this.executionPolicies.size >= 100) throw Error("Native project scope bound exceeded.");
    const policy = existing ?? new ScopePolicy();
    policy.set({ scope, roots: [i.root], sessionKeys: [], configuration: false, exportConsent: false });
    this.executionPolicies.set(scopeId, policy);
    this.projectScopes.set(scope.scopeId, i);
    return { approved: true, scope: structuredClone(scope), epoch: policy.epoch, scopeHash: digest(scope) };
  }
  selection(r, s2) {
    const p = this.activePolicy(r), g = p?.authorize(r);
    if (!this.trusted() || !g || s2.hostId !== this.hostId || !g.roots.includes(s2.cwd) || !g.scope.repoIds.includes(repoId(s2.cwd))) throw Error("Reviewed Agent target and current trusted host scope are required.");
  }
  allowed(r, o) {
    return !!this.activePolicy(r) && this.trusted() && digest(r.scope) === o.scopeHash;
  }
  async prepare(r, i) {
    const request = structuredClone(r), task = prepareNativeTask(i);
    this.selection(request, task.selection);
    const project = this.projectScopes.get(request.scope.scopeId);
    if (project) await verifyNativeProjectScope(project);
    if (task.scopeHash !== digest(request.scope)) throw Error("Exact reviewed scope hash mismatch.");
    if (this.preparations.size >= 100) throw Error("Prepared native task bound exceeded.");
    if (await this.runner.lookup(task.taskId)) throw Error("Task already has a durable spawn intent; do not retry.");
    this.preparations.set(task.preparedHash, { task, request, epoch: this.activePolicy(request).epoch, approved: false });
    return structuredClone(task);
  }
  prepared(r, hash2) {
    const p = this.preparations.get(hash2);
    if (!p || p.epoch !== this.activePolicy(r)?.epoch || digest(r.scope) !== p.task.scopeHash || !this.trusted()) throw Error("Prepared native task scope/epoch is stale or unavailable.");
    this.selection(r, p.task.selection);
    return p;
  }
  async approve(r, hash2) {
    const p = this.prepared(r, hash2), check = await this.runner.preflight(p.task.selection);
    if (check.state !== "READY") throw Error("Native startup effects or capabilities are blocked: " + check.reasons.join(" "));
    const accepted = await this.review(structuredClone(p.task));
    this.prepared(r, hash2);
    p.approved = accepted;
    return { approved: accepted, preparedHash: hash2 };
  }
  async start(r, i) {
    const p = this.prepared(r, i.preparedHash);
    if (!p.approved || p.task.taskId !== i.taskId) throw Error("Independent exact host-owned execution approval is required.");
    const project = this.projectScopes.get(r.scope.scopeId);
    if (project) await verifyNativeProjectScope(project);
    p.approved = false;
    const handle = await this.runner.start(p.task, i.preparedHash, () => this.trusted() && p.epoch === this.activePolicy(p.request)?.epoch);
    this.handles.set(i.taskId, handle);
    void handle.result.finally(() => this.handles.delete(i.taskId));
    return handle.observation();
  }
  async lookup(r, id) {
    if (!this.activePolicy(r) || !this.trusted()) throw Error("Reviewed Agent scope is required.");
    const o = await this.runner.lookup(id);
    if (o && !this.allowed(r, o)) throw Error("Owned native task is outside this reviewed scope.");
    return o;
  }
  async lookupRequired(r, id) {
    const o = await this.lookup(r, id);
    if (!o) throw Error("Owned native task unavailable.");
    return o;
  }
  async roleRuntime(i) {
    const unknown = { ...i, state: "UNKNOWN", nativeSessionId: null, nativeReceiptRef: null, observedAt: null };
    if (!hashOk2(i.bindingHash) || !hashOk2(i.scopeHash) || !this.trusted()) return unknown;
    let files;
    try {
      files = await fs11.readdir(this.runner.ledgerDirectory);
    } catch {
      return unknown;
    }
    const names = files.filter((f) => /^[a-f0-9]{64}\.json$/.test(f));
    if (names.length > 1e3) return unknown;
    const matches = [];
    for (const f of names) {
      try {
        const raw = await fs11.readFile(path11.join(this.runner.ledgerDirectory, f), "utf8");
        if (raw.length > 128 * 1024) continue;
        const o2 = JSON.parse(raw);
        if (o2.bindingHash === i.bindingHash && o2.configScopeHash === i.scopeHash && [...this.policy.scopes(), ...[...this.executionPolicies.values()].flatMap((p) => p.scopes())].some((s2) => digest(s2) === o2.scopeHash)) {
          const current = await this.runner.lookup(o2.taskId);
          if (current) matches.push(current);
        }
      } catch {
      }
    }
    const o = matches.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))[0];
    if (!o || !o.sessionId || !["RUNNING", "NEEDS_INPUT", "COMPLETED", "INTERRUPTED", "FAILED"].includes(o.state) || ["COMPLETED", "INTERRUPTED", "FAILED"].includes(o.state) && o.quiescence !== "NATIVE_TURN_SETTLED") return unknown;
    return { ...i, state: ["RUNNING", "NEEDS_INPUT"].includes(o.state) ? "RUNNING" : "STOPPED", nativeSessionId: o.sessionId, nativeReceiptRef: nativeHash(o), observedAt: o.updatedAt };
  }
  async dispose() {
    this.preparations.clear();
    for (const policy of this.executionPolicies.values()) policy.clear();
    this.executionPolicies.clear();
    this.projectScopes.clear();
    await this.runner.dispose();
  }
};

// src/provider-kit/headlessNativeHost.ts
function createHeadlessNativeHost(options) {
  if (typeof options.review !== "function" || typeof options.trusted !== "function" || typeof options.platformVerifiers !== "function") throw Error("Explicit host authority and review callbacks are required.");
  const policy = new ScopePolicy();
  policy.set(structuredClone(options.grant));
  const runner = new NativeTaskRunner(options.ledgerDirectory, void 0, options.platformVerifiers, options.mafRuntime);
  const facade = new NativeTransportFacade(runner, policy, options.hostId, options.review, options.trusted);
  return Object.freeze({ api: facade.api, epoch: policy.epoch, revoke: () => policy.clear(), dispose: () => facade.dispose() });
}

// src/provider-kit/agentHost.ts
var import_node_crypto7 = require("node:crypto");
var path12 = __toESM(require("node:path"));
var import_node_url = require("node:url");

// src/provider-kit/agentHostPolicy.ts
var readOnlyConfig = () => ({
  "codex.sandboxMode": "read-only",
  "codex.approvalPolicy": "never",
  "codex.networkAccessEnabled": false,
  "codex.webSearchMode": "disabled",
  "codex.additionalDirectories": [],
  permissions: { allow: [], deny: [] }
});
var AHPPermissionError = class extends Error {
  constructor(message) {
    super(message);
    this.name = "AHPPermissionError";
  }
};
function validExecutionPolicy(p) {
  const v = p;
  return !!v && Object.keys(v).sort().join(",") === "mode,sourcePolicyHash" && v.mode === "READ_ONLY_NO_DELEGATION" && /^[a-f0-9]{64}$/.test(v.sourcePolicyHash);
}
var object = (v) => !!v && typeof v === "object" && !Array.isArray(v);
var empty = (v) => Array.isArray(v) && v.length === 0;
function restrictiveValues(v) {
  if (!object(v) || Object.hasOwn(v, "codex.permissionsPreset")) return false;
  return v["codex.sandboxMode"] === "read-only" && v["codex.approvalPolicy"] === "never" && v["codex.networkAccessEnabled"] === false && v["codex.webSearchMode"] === "disabled" && empty(v["codex.additionalDirectories"]) && object(v.permissions) && empty(v.permissions.allow) && empty(v.permissions.deny);
}
function validateResolvedPolicy(result) {
  if (!object(result) || !object(result.schema) || !object(result.schema.properties) || !restrictiveValues(result.values))
    throw new AHPPermissionError("Restrictive configuration is missing, unsafe or overridden by a permission preset.");
  const props = result.schema.properties;
  for (const [key, wanted] of Object.entries(readOnlyConfig())) {
    const p = props[key];
    if (!object(p)) throw new AHPPermissionError("Provider does not declare the required permission configuration.");
    const type = typeof wanted === "boolean" ? "boolean" : typeof wanted === "string" ? "string" : Array.isArray(wanted) ? "array" : "object";
    if (p.type !== type || Array.isArray(p.enum) && !p.enum.includes(wanted) || p.readOnly === true && JSON.stringify(p.default) !== JSON.stringify(wanted))
      throw new AHPPermissionError("Provider permission schema does not support the restrictive value.");
  }
  return readOnlyConfig();
}
function reviewedHostPolicy(root) {
  if (!object(root) || !object(root.config) || !object(root.config.values))
    throw new AHPPermissionError("Host permission configuration is unavailable.");
  const values = root.config.values, schema = root.config.schema;
  const properties = object(schema) && object(schema.properties) ? schema.properties : {};
  const selected = {};
  for (const key of ["globalAutoApproveEnabled", "terminalAutoApproveEnabled", "agentMerge.enabled", "artifactTools"]) {
    const property = properties[key];
    const value = Object.hasOwn(values, key) ? values[key] : object(property) ? property.default : void 0;
    if (value !== false) throw new AHPPermissionError("Host auto-approval, network or artifact controls are unsafe or unknown.");
    selected[key] = { value, source: Object.hasOwn(values, key) ? "SERVER_VALUE" : "SERVER_SCHEMA_DEFAULT" };
  }
  const permissions = values.permissions;
  if (!object(permissions) || !empty(permissions.allow) || !empty(permissions.deny))
    throw new AHPPermissionError("Inherited host tool permissions are unsafe or unknown.");
  selected.permissions = { allow: [], deny: [] };
  return selected;
}
function requireEffectivePermissionEvidence() {
  throw new AHPPermissionError("Effective native read-only, network and delegation enforcement and complete host-tool restrictions are UNKNOWN: public AHP exposes configuration only. No turn sent.");
}

// src/provider-kit/agentHost.ts
var ahpHash = (value) => (0, import_node_crypto7.createHash)("sha256").update(canonicalJson(value)).digest("hex");
var ahpTextHash = (value) => (0, import_node_crypto7.createHash)("sha256").update(value).digest("hex");
var ROOT = "ahp-root://";
var versions = ["1.0.0", "0.9.0"];
function qualifiedAHPEfforts(provider, model) {
  const allowed = provider === "codex" ? ["none", "minimal", "low", "medium", "high", "xhigh", "max", "ultra"] : provider === "claude" ? ["low", "medium", "high", "xhigh", "max"] : [];
  const property = model.configSchema?.properties?.thinkingLevel;
  if (!allowed.length || !property || property.type !== "string" || property.readOnly || !Array.isArray(property.enum) || !property.enum.length || property.enum.length > allowed.length || property.enum.some((v) => typeof v !== "string" || !allowed.includes(v)) || new Set(property.enum).size !== property.enum.length) return [];
  return property.enum;
}
var sdk = () => Promise.all([Promise.resolve().then(() => (init_types(), types_exports)), Promise.resolve().then(() => (init_client2(), client_exports))]);
function bindingOk(b, r) {
  return !!b && Object.keys(b).every((k) => ["taskId", "roleId", "root", "revision", "authorityHash", "preparedTaskHash", "compiledPromptHash", "configScopeHash", "presetHash", "provider", "requestedModel", "requestedEffort", "prompt", "promptHash", "requestedMode", "testPolicyHash", "outputPolicyHash", "taskRevision", "executionPolicy"].includes(k)) && (b.taskRevision === void 0 || Number.isSafeInteger(b.taskRevision) && b.taskRevision > 0) && [b.taskId, b.roleId].every(idOk) && ["codex", "claude"].includes(b.provider) && path12.isAbsolute(b.root) && !/[\x00-\x1f]/.test(b.root) && /^[a-f0-9]{40}$/.test(b.revision) && [b.authorityHash, b.preparedTaskHash, b.compiledPromptHash, b.configScopeHash, b.presetHash, b.promptHash].every((h) => typeof h === "string" && /^[a-f0-9]{64}$/.test(h)) && typeof b.prompt === "string" && b.prompt.trim().length > 0 && b.prompt.length <= 32768 && ahpTextHash(b.prompt) === b.promptHash && [b.testPolicyHash, b.outputPolicyHash].every((h) => h === void 0 || typeof h === "string" && /^[a-f0-9]{64}$/.test(h)) && [b.requestedModel, b.requestedEffort ?? null].every((s2) => s2 === null || typeof s2 === "string" && /^[a-zA-Z0-9_.:@/+ -]{1,160}$/.test(s2)) && r.scope.repoIds.length > 0 && (b.executionPolicy === void 0 || validExecutionPolicy(b.executionPolicy) && b.executionPolicy.sourcePolicyHash === b.testPolicyHash);
}
var sameRoot = (a, b) => path12.resolve(a).replace(/\\/g, "/").toLowerCase() === path12.resolve(b).replace(/\\/g, "/").toLowerCase();
var safeUri = (v, kind) => typeof v === "string" && new RegExp("^ahp-" + kind + ":/[a-zA-Z0-9._-]{1,160}$").test(v);
var ledgerHash = (r) => ahpHash(r);
var taskActionKey = (p) => ahpHash({ hostId: p.hostId, provider: p.binding.provider, root: process.platform === "win32" ? path12.resolve(p.binding.root).toLowerCase() : path12.resolve(p.binding.root), taskId: p.binding.taskId, taskRevision: p.binding.taskRevision ?? null, revisionGit: p.binding.revision, authorityHash: p.binding.authorityHash, promptHash: p.binding.promptHash });
var AgentHostAdapter = class {
  constructor(services) {
    this.services = services;
    const stored = services.storage.load();
    if (stored !== void 0) try {
      if (!Array.isArray(stored) || stored.length > 100) throw Error();
      for (const item of stored) {
        const { integrityHash, ...rest } = item;
        if (integrityHash !== ledgerHash(rest) || !idOk(item.observation?.handleId) || item.prepared?.preparedHash !== ahpHash({ ...item.prepared, preparedHash: void 0 })) throw Error();
        this.records.set(item.observation.handleId, structuredClone(item));
        this.prepared.set(item.prepared.preparedHash, structuredClone(item.prepared));
      }
    } catch {
      this.corrupt = true;
    }
    this.api = { major: 1, inspect: (i) => this.inspect(i.request, i.target.provider, i.target.hostId), reviewProject: (i) => this.reviewProject(i.request, i.binding), reviewHostConnection: (i) => this.reviewConnection(i.request, i.binding), prepare: (i) => this.prepare(i.request, i.binding, i.hostId), execute: (i) => this.execute(i.request, i.preparedHash, i.approval), observe: (i) => this.observe(i.request, i.handleId, false), recover: (i) => this.observe(i.request, i.handleId, true), cancel: (i) => this.cancel(i.request, i.handleId), reveal: async (i) => this.reply(i.request, "UNAVAILABLE", { opened: false }, "No documented public same-session Agents Window reveal action is qualified."), subscribe: (i, listener) => this.subscribe(i.request, i.handleId, listener) };
  }
  api;
  hosts = /* @__PURE__ */ new Map();
  connections = /* @__PURE__ */ new Map();
  prepared = /* @__PURE__ */ new Map();
  records = /* @__PURE__ */ new Map();
  sourceGrants = /* @__PURE__ */ new Map();
  listeners = /* @__PURE__ */ new Set();
  writes = Promise.resolve();
  execution = /* @__PURE__ */ new Set();
  corrupt = false;
  reply(r, state, data, message = "") {
    return { schema: "datapass.agent-host-reply/1", requestId: idOk(r?.requestId) ? r.requestId : "invalid", scopeHash: r?.scope ? ahpHash(r.scope) : "", state, data: structuredClone(data), message: bounded(message, 1e3) };
  }
  authorized(r, b) {
    return validateRequest(r) && this.services.sourceGrantCurrent?.(r) !== false && (!b || bindingOk(b, r)) && (this.services.authorize(r) || this.sourceGrants.get(ahpHash(r.scope)) === ahpHash({ scope: r.scope, epoch: r.epoch ?? null, root: b?.root ?? this.rootFor(r) }));
  }
  reviewedRoots = /* @__PURE__ */ new Map();
  reviewedBindings = /* @__PURE__ */ new Map();
  rootFor(r) {
    return this.reviewedRoots.get(ahpHash(r.scope)) ?? [...this.records.values()].find((x) => x.observation.scopeHash === ahpHash(r.scope))?.observation.root ?? [...this.prepared.values()].find((x) => x.scopeHash === ahpHash(r.scope))?.binding.root;
  }
  async reviewProject(r, b) {
    if (!validateRequest(r) || !bindingOk(b, r) || !await this.services.verifySource(b, r)) return this.reply(r, "DENIED", { authorized: false }, "Exact source root/revision is unavailable.");
    if (!await this.services.reviewProject(r, structuredClone(b)) || !await this.services.verifySource(b, r)) return this.reply(r, "DENIED", { authorized: false }, "Source review declined or source changed.");
    this.sourceGrants.set(ahpHash(r.scope), ahpHash({ scope: r.scope, epoch: r.epoch ?? null, root: b.root }));
    this.reviewedRoots.set(ahpHash(r.scope), b.root);
    this.reviewedBindings.set(ahpHash(r.scope), structuredClone(b));
    return this.reply(r, "AHP_AVAILABLE", { authorized: true });
  }
  async reviewConnection(r, b) {
    if (!this.authorized(r, b) || !await this.services.verifySource(b, r)) return this.reply(r, "DENIED", this.empty("DENIED"), "Review exact source scope first.");
    let selection;
    try {
      selection = await this.services.reviewConnection(r, structuredClone(b));
    } catch {
      return this.reply(r, "UNAVAILABLE", this.empty("UNAVAILABLE"), "Selected endpoint unavailable, unsafe or stale; credentials and raw connection errors are not exposed.");
    }
    if (!selection) return this.reply(r, "UNAVAILABLE", this.empty("UNAVAILABLE"), "No reviewed endpoint or connection authorization; actual host liveness is unknown. No host is started automatically.");
    if (!this.authorized(r, b) || !await this.services.verifySource(b, r) || selection.scopeHash !== ahpHash(r.scope) || !sameRoot(selection.root, b.root) || selection.revision !== b.revision || !selection.authorized()) return this.reply(r, "DENIED", this.empty("DENIED"), "Host connection authority does not match this source scope.");
    this.registerHost(selection);
    return this.inspect(r, b.provider, selection.host.hostId, b);
  }
  /** Host-owned only; synthetic fixtures use this same entry point with explicit SYNTHETIC identity. */
  registerHost(selection) {
    if (!idOk(selection.host.hostId) || !["SYNTHETIC", "VSCODE_AGENT_HOST", "STANDALONE_AGENT_HOST"].includes(selection.host.kind) || !/^[a-f0-9]{64}$/.test(selection.host.identityHash) || !selection.authorized()) throw Error("Invalid independently reviewed host connection.");
    const previous = this.hosts.get(selection.host.hostId);
    if (previous && previous.host.identityHash !== selection.host.identityHash) throw Error("Ambiguous host identity.");
    this.hosts.set(selection.host.hostId, selection);
  }
  empty(state) {
    return { state, hosts: [], providers: [], capabilities: [], selectedHostId: null, protocolVersion: null, sessions: [], message: state === "HOST_NOT_RUNNING" ? "No reviewed running endpoint." : "Review the exact source and local host connection separately." };
  }
  async connect(host) {
    const existing = this.connections.get(host.host.hostId);
    if (existing?.active) return existing;
    if (!host.authorized()) throw Error("DENIED");
    const libs = await sdk(), transport = await host.open();
    if (!host.authorized()) {
      await transport.close();
      throw Error("DENIED");
    }
    const client = new libs[1].AhpClient(transport, { requestTimeoutMs: 5e3, subscriptionBuffer: 512 });
    const c = { descriptor: host, client, sdk: libs, agents: [], protocolVersion: "", inventoryHash: "", sessions: /* @__PURE__ */ new Map(), chats: /* @__PURE__ */ new Map(), seq: /* @__PURE__ */ new Map(), active: true, root: void 0 };
    const stream = client.events();
    client.connect();
    try {
      const init = await client.initialize({ clientId: "datapass-agent-" + host.host.identityHash.slice(0, 24), protocolVersions: versions, initialSubscriptions: [ROOT] });
      if (!versions.includes(init.protocolVersion)) throw Error("PROTOCOL_UNSUPPORTED");
      c.protocolVersion = init.protocolVersion;
      for (const snap of init.snapshots) this.snapshot(c, snap);
      c.inventoryHash = ahpHash(this.inventory(c));
      this.connections.set(host.host.hostId, c);
      void this.pump(c, stream);
      void this.monitor(c);
      return c;
    } catch (error) {
      await client.shutdown();
      throw error;
    }
  }
  inventory(c) {
    return c.agents.slice(0, 30).map((a) => ({ provider: bounded(a.provider, 160), state: a.models.length ? "AHP_AVAILABLE" : "AUTH_REQUIRED", models: a.models.slice(0, 100).filter((m) => m.provider && m.id && m.policyState !== "disabled").map((m) => ({ id: bounded(m.id, 160), provider: bounded(m.provider, 160), name: bounded(m.name, 160), efforts: qualifiedAHPEfforts(a.provider, m) })) }));
  }
  snapshot(c, s2) {
    if (!Number.isSafeInteger(s2.fromSeq) || s2.fromSeq < 0) throw Error("Malformed snapshot");
    c.seq.set(s2.resource, s2.fromSeq);
    if (s2.resource === ROOT) {
      const state = s2.state;
      if (!Array.isArray(state.agents) || state.agents.length > 100) throw Error("Malformed inventory");
      c.agents = state.agents;
      c.root = s2.state;
    } else if (safeUri(s2.resource, "session")) c.sessions.set(s2.resource, s2.state);
    else if (safeUri(s2.resource, "chat")) c.chats.set(s2.resource, s2.state);
  }
  async pump(c, stream) {
    try {
      for await (const event of stream) {
        if (!c.active) break;
        if (!c.descriptor.authorized()) throw Error("DENIED");
        if (event.event.type === "authRequired") {
          for (const rec of this.records.values()) if (rec.observation.hostId === c.descriptor.host.hostId && event.channel === rec.observation.chatId) this.transition(rec, "AUTH_REQUIRED", "Native authentication is required.");
          continue;
        }
        if (event.event.type !== "action") continue;
        const env = event.event.params;
        if (!Number.isSafeInteger(env.serverSeq) || env.serverSeq < 0) throw Error("Malformed sequence");
        if (env.serverSeq <= (c.seq.get(env.channel) ?? -1)) continue;
        c.seq.set(env.channel, env.serverSeq);
        if (env.channel === ROOT) {
          c.root = c.sdk[0].rootReducer(c.root, env.action);
          c.agents = c.root.agents;
        } else if (c.sessions.has(env.channel)) c.sessions.set(env.channel, c.sdk[0].sessionReducer(c.sessions.get(env.channel), env.action));
        else if (c.chats.has(env.channel)) c.chats.set(env.channel, c.sdk[0].chatReducer(c.chats.get(env.channel), env.action));
        for (const rec of this.records.values()) if (rec.observation.hostId === c.descriptor.host.hostId && [rec.observation.sessionId, rec.observation.chatId].includes(env.channel)) {
          if (rec.prepared.binding.executionPolicy && env.channel === rec.observation.chatId && env.action.type === c.sdk[0].ActionType.ChatToolCallReady && env.action.turnId === rec.observation.turnId) {
            c.client.dispatch(env.channel, { type: c.sdk[0].ActionType.ChatToolCallConfirmed, turnId: env.action.turnId, toolCallId: env.action.toolCallId, approved: false, reason: c.sdk[0].ToolCallCancellationReason.Denied });
          }
          await this.project(c, rec, env);
        }
      }
    } catch {
      c.active = false;
      for (const rec of this.records.values()) if (rec.observation.hostId === c.descriptor.host.hostId && !["COMPLETED", "FAILED", "STOPPED"].includes(rec.observation.state)) this.transition(rec, "UNCERTAIN", "Host stream unavailable. Recovery never resends.");
    }
  }
  async monitor(c) {
    for await (const state of c.client.stateChanges()) if (state.status === "closed") {
      c.active = false;
      for (const rec of this.records.values()) if (rec.observation.hostId === c.descriptor.host.hostId && !["COMPLETED", "FAILED", "STOPPED"].includes(rec.observation.state)) this.transition(rec, "UNCERTAIN", "Connection closed. Recover exact session; no retry.");
    }
  }
  async inspect(r, provider, hostId, b) {
    if (!this.authorized(r, b) || !["codex", "claude"].includes(provider)) return this.reply(r, "DENIED", this.empty("DENIED"));
    const source = b ?? this.reviewedBindings.get(ahpHash(r.scope)) ?? [...this.records.values()].find((x) => x.observation.scopeHash === ahpHash(r.scope))?.prepared.binding;
    if (source && !await this.services.verifySource(source, r)) return this.reply(r, "DENIED", this.empty("DENIED"), "Reviewed source root/revision or repository identity changed.");
    const hosts = [...this.hosts.values()].filter((h) => h.scopeHash === ahpHash(r.scope) && h.authorized());
    if (!hosts.length) return this.reply(r, "UNAVAILABLE", this.empty("UNAVAILABLE"), "No reviewed endpoint or connection authorization; actual host liveness is unknown. Its credentials are not implicitly authorized.");
    const selected = hostId ? hosts.find((h) => h.host.hostId === hostId) : hosts.length === 1 ? hosts[0] : void 0;
    if (!selected) return this.reply(r, "DENIED", { ...this.empty("DENIED"), hosts: hosts.map((h) => h.host) }, "Select one exact host. Multiple hosts cannot be inferred.");
    try {
      const c = await this.connect(selected);
      const providers = this.inventory(c), state = providers.find((p) => p.provider === provider)?.state ?? "PROVIDER_UNSUPPORTED";
      return this.reply(r, state, { state, hosts: hosts.map((h) => ({ ...h.host, protocolVersion: h === selected ? c.protocolVersion : null, connectionState: h === selected ? "AHP_AVAILABLE" : "UNAVAILABLE" })), providers, capabilities: ["createSession", "subscribe", "chat/turnStarted", "chat/delta", "chat/turnComplete", "ownedSnapshotRecovery", "ownedCancel"], selectedHostId: selected.host.hostId, protocolVersion: c.protocolVersion, sessions: [...this.records.values()].filter((x) => x.observation.scopeHash === ahpHash(r.scope) && x.observation.hostId === selected.host.hostId && x.observation.sessionId).map((x) => ({ hostId: x.observation.hostId, sessionId: x.observation.sessionId, taskId: x.observation.taskId })), message: "Negotiated public AHP. Provider inventory is observed; authentication remains native." });
    } catch (error) {
      const state = this.errorState(error);
      return this.reply(r, state, { ...this.empty(state), hosts: [selected.host] }, "Connection/negotiation unavailable; raw endpoint errors are suppressed.");
    }
  }
  errorState(e) {
    const code = e?.code;
    return code === -32002 ? "PROVIDER_UNSUPPORTED" : code === -32007 || String(e).includes("AUTH_REQUIRED") ? "AUTH_REQUIRED" : code === -32005 || String(e).includes("PROTOCOL_UNSUPPORTED") ? "PROTOCOL_UNSUPPORTED" : code === -32009 ? "PERMISSION_REQUIRED" : String(e).includes("DENIED") ? "DENIED" : "UNAVAILABLE";
  }
  async resolvePolicy(c, b) {
    if (!b.executionPolicy) return void 0;
    if (b.provider !== "codex") throw new AHPPermissionError("Read-only policy is not supported by this provider contract.");
    const before = ahpHash(reviewedHostPolicy(c.root));
    const result = await c.client.request("resolveSessionConfig", { channel: ROOT, provider: b.provider, workingDirectory: (0, import_node_url.pathToFileURL)(b.root).href, config: readOnlyConfig() });
    const config = validateResolvedPolicy(result);
    const after = ahpHash(reviewedHostPolicy(c.root));
    if (before !== after) throw new AHPPermissionError("Host permission configuration changed during resolution.");
    return { policyHash: ahpHash(b.executionPolicy), resolvedConfigHash: ahpHash(config), hostConfigHash: after, configuration: "SUPPORTED", nativeEffective: "UNKNOWN", hostTools: "UNVERIFIED", stage: "RESOLVED", message: "Restrictive configuration resolved; independent native and host-tool enforcement evidence remains unavailable." };
  }
  verifySessionPolicy(c, rec) {
    if (!rec.prepared.binding.executionPolicy) return;
    const review = rec.prepared.permissionReview, s2 = c.sessions.get(rec.observation.sessionId);
    if (!review || rec.observation.executionPolicyHash !== review.policyHash || review.policyHash !== ahpHash(rec.prepared.binding.executionPolicy) || ahpHash(reviewedHostPolicy(c.root)) !== review.hostConfigHash)
      throw new AHPPermissionError("Reviewed task policy or host permission configuration changed.");
    if (!s2 || !restrictiveValues(s2.config?.values)) throw new AHPPermissionError("Session permission configuration is missing, unsafe or overridden.");
    rec.observation.permissionReview = { ...review, stage: "SESSION_CONFIG_OBSERVED", message: "Server session configuration observed; this is not proof of native enforcement." };
    requireEffectivePermissionEvidence();
  }
  async prepare(r, b, hostId) {
    if (!this.authorized(r, b) || !await this.services.verifySource(b, r)) return this.reply(r, "DENIED", null, "Source scope, task or revision unavailable.");
    const inspection = await this.inspect(r, b.provider, hostId, b);
    if (!["AHP_AVAILABLE", "AUTH_REQUIRED"].includes(inspection.state)) return this.reply(r, inspection.state, null, inspection.message);
    let permissionReview;
    try {
      permissionReview = await this.resolvePolicy(this.connections.get(hostId), b);
    } catch (error) {
      return this.reply(r, "PERMISSION_REQUIRED", null, error instanceof AHPPermissionError ? error.message : "Supported permission configuration could not be resolved.");
    }
    if (inspection.state !== "AHP_AVAILABLE") return this.reply(r, inspection.state, null, permissionReview?.message ?? inspection.message);
    const c = this.connections.get(hostId);
    const models = c.agents.find((a) => a.provider === b.provider)?.models.filter((m) => m.id === b.requestedModel && m.policyState !== "disabled") ?? [];
    const model = models.length === 1 ? models[0] : void 0;
    if (b.requestedMode && b.requestedMode !== "DEFAULT") return this.reply(r, "PROVIDER_UNSUPPORTED", null, "Native PLAN/GOAL mode mapping is not qualified.");
    if (b.requestedModel && !model) return this.reply(r, "PROVIDER_UNSUPPORTED", null, "Requested model is absent from this exact provider inventory.");
    if (b.requestedEffort && (!model || !qualifiedAHPEfforts(b.provider, model).includes(b.requestedEffort))) return this.reply(r, "PROVIDER_UNSUPPORTED", null, "Requested effort is absent from the qualified thinkingLevel enum for this exact native model. No other configuration key or permission mapping is used.");
    const data = { schema: "datapass.agent-host-prepared/1", handleId: "ahp:" + (0, import_node_crypto7.randomUUID)(), hostId, hostIdentityHash: c.descriptor.host.identityHash, protocolVersion: c.protocolVersion, scopeHash: ahpHash(r.scope), binding: structuredClone(b), ...permissionReview ? { permissionReview } : {}, inventoryHash: ahpHash(this.inventory(c)), capturedAt: (/* @__PURE__ */ new Date()).toISOString() };
    const prepared = { ...data, preparedHash: ahpHash(data) };
    this.prepared.set(prepared.preparedHash, prepared);
    const observation = this.initialObservation(prepared, c, permissionReview ? "PERMISSION_REQUIRED" : "AHP_AVAILABLE");
    await this.persist({ prepared, observation, request: structuredClone(r), clientId: "datapass-agent-" + prepared.hostIdentityHash.slice(0, 24), phase: "PREPARED", integrityHash: "" });
    return this.reply(r, permissionReview ? "PERMISSION_REQUIRED" : "AHP_AVAILABLE", prepared, permissionReview?.message ?? "");
  }
  async persist(rec) {
    const { integrityHash, ...rest } = rec;
    rec.integrityHash = ledgerHash(rest);
    this.records.set(rec.observation.handleId, rec);
    const records = structuredClone([...this.records.values()]);
    if (records.length > 100) throw Error("Owned handle bound exceeded");
    this.writes = this.writes.then(() => this.services.storage.save(records));
    await this.writes;
  }
  transition(rec, state, message) {
    rec.observation = { ...rec.observation, state, message: bounded(message, 1e3), capturedAt: (/* @__PURE__ */ new Date()).toISOString() };
    void this.persist(rec).then(() => this.emit(rec.observation)).catch(() => {
      rec.observation.state = "UNCERTAIN";
    });
  }
  emit(o) {
    for (const sub of this.listeners) if (sub.handleId === o.handleId && this.authorized(sub.request) && ahpHash(sub.request.scope) === o.scopeHash) try {
      sub.listener(structuredClone(o));
    } catch {
    }
  }
  async execute(r, hash2, a) {
    const p = this.prepared.get(hash2);
    if (this.corrupt || !p || !this.authorized(r, p.binding) || p.scopeHash !== ahpHash(r.scope) || !await this.services.verifySource(p.binding, r)) return this.reply(r, "DENIED", null, "Reviewed immutable preparation unavailable.");
    const executionKey = taskActionKey(p);
    const existing = [...this.records.values()].find((x) => x.phase !== "PREPARED" && taskActionKey(x.prepared) === executionKey);
    if (existing && existing.observation.scopeHash !== ahpHash(r.scope)) return this.reply(r, "DENIED", null, "This exact action has a durable intent in another scope; no resend or cross-scope result disclosure.");
    if (existing && ahpHash(existing.prepared.binding.executionPolicy ?? null) !== ahpHash(p.binding.executionPolicy ?? null)) return this.reply(r, "DENIED", null, "Durable task policy differs; recovery cannot downgrade or resend.");
    if (existing) return this.reply(r, existing.observation.state, existing.observation, "Existing durable intent. No duplicate task or resend.");
    if (this.execution.has(executionKey)) return this.reply(r, "UNCERTAIN", null, "This exact task is already being submitted.");
    if (!a || a.preparedHash !== hash2 || a.taskId !== p.binding.taskId || a.promptHash !== p.binding.promptHash || a.hostId !== p.hostId || a.provider !== p.binding.provider || a.protocolVersion !== p.protocolVersion) return this.reply(r, "DENIED", null, "Exact task approval binding differs.");
    this.execution.add(executionKey);
    let rec;
    try {
      const c = this.connections.get(p.hostId);
      if (!c?.active || c.protocolVersion !== p.protocolVersion || c.descriptor.host.identityHash !== p.hostIdentityHash || !c.descriptor.authorized() || ahpHash(this.inventory(c)) !== p.inventoryHash) return this.reply(r, "PROTOCOL_UNSUPPORTED", null, "Host identity, protocol or provider capability changed.");
      if (!await this.services.reviewTask(structuredClone(p)) || !this.authorized(r, p.binding) || !await this.services.verifySource(p.binding, r)) return this.reply(r, "DENIED", null, "Native task review declined or source changed.");
      if (p.binding.executionPolicy) {
        const current = await this.resolvePolicy(c, p.binding);
        if (!current || !p.permissionReview || ahpHash(current) !== ahpHash(p.permissionReview)) throw new AHPPermissionError("Prepared permission policy is stale or missing.");
      }
      const handleId = p.handleId, sessionId = "ahp-session:/" + (0, import_node_crypto7.randomUUID)(), turnId = "turn-" + (0, import_node_crypto7.randomUUID)();
      const observation = { schema: "datapass.agent-host-observation/1", handleId, taskId: p.binding.taskId, roleId: p.binding.roleId, preparedHash: hash2, scopeHash: p.scopeHash, hostId: p.hostId, hostIdentityHash: p.hostIdentityHash, protocolVersion: p.protocolVersion, provider: p.binding.provider, root: p.binding.root, revision: p.binding.revision, promptHash: p.binding.promptHash, sessionId, chatId: null, turnId, state: "RUNNING", resultText: "", resultHash: ahpTextHash(""), requestedModel: p.binding.requestedModel, requestedEffort: p.binding.requestedEffort ?? null, observedModel: null, observedEffort: null, lastServerSeq: 0, capturedAt: (/* @__PURE__ */ new Date()).toISOString(), evidence: c.descriptor.host.kind === "SYNTHETIC" ? "SYNTHETIC" : "NATIVE_AHP_OBSERVED", message: "Durable create intent recorded; native completion is separate from task acceptance.", acceptedTaskCompletion: false, ...p.permissionReview ? { executionPolicyHash: p.permissionReview.policyHash, permissionReview: structuredClone(p.permissionReview) } : {} };
      rec = { prepared: p, observation, request: structuredClone(r), clientId: "datapass-agent-" + p.hostIdentityHash.slice(0, 24), phase: "CREATE_INTENT", integrityHash: "" };
      await this.persist(rec);
      if (!this.authorized(r, p.binding) || !c.descriptor.authorized()) throw Error("DENIED");
      if (p.binding.executionPolicy && ahpHash(reviewedHostPolicy(c.root)) !== p.permissionReview?.hostConfigHash) throw new AHPPermissionError("Host permission configuration changed before creation.");
      await c.client.request("createSession", { channel: sessionId, provider: p.binding.provider, workingDirectories: [(0, import_node_url.pathToFileURL)(p.binding.root).href], ...p.binding.executionPolicy ? { config: readOnlyConfig() } : {} });
      const subscribed = await c.client.subscribe(sessionId);
      if (!subscribed.result.snapshot) throw Error("Missing session snapshot");
      this.snapshot(c, subscribed.result.snapshot);
      const session = await this.readySession(c, sessionId);
      if (!this.sessionMatches(rec, session) || !safeUri(session.defaultChat, "chat")) throw Error("Session binding changed");
      rec.observation.chatId = session.defaultChat;
      rec.phase = "SESSION_BOUND";
      await this.persist(rec);
      const chat = await c.client.subscribe(rec.observation.chatId);
      if (!chat.result.snapshot) throw Error("Missing chat snapshot");
      this.snapshot(c, chat.result.snapshot);
      if (!this.chatMatches(rec, c.chats.get(rec.observation.chatId)) || !this.authorized(r, p.binding) || !c.descriptor.authorized() || !await this.services.verifySource(p.binding, r)) throw Error("DENIED");
      this.verifySessionPolicy(c, rec);
      rec.phase = "SEND_INTENT";
      await this.persist(rec);
      c.client.dispatch(rec.observation.chatId, { type: c.sdk[0].ActionType.ChatTurnStarted, turnId, startedAt: (/* @__PURE__ */ new Date()).toISOString(), message: { text: p.binding.prompt, origin: { kind: c.sdk[0].MessageKind.User }, ...p.binding.requestedModel ? { model: { id: p.binding.requestedModel, ...p.binding.requestedEffort ? { config: { thinkingLevel: p.binding.requestedEffort } } : {} } } : {} } });
      rec.phase = "SENT";
      await this.persist(rec);
      this.emit(rec.observation);
      return this.reply(r, rec.observation.state, rec.observation);
    } catch (error) {
      if (rec) {
        const state = error instanceof AHPPermissionError ? "PERMISSION_REQUIRED" : String(error).includes("AHP_FAILED") ? "FAILED" : error?.code !== void 0 ? this.errorState(error) : "UNCERTAIN";
        this.transition(rec, state, state === "UNCERTAIN" ? "Submission or startup uncertain. Recover exact stored identities; do not retry." : error instanceof AHPPermissionError ? error.message : "Host reported failed or unavailable startup; no prompt retry.");
        await this.writes;
        return this.reply(r, state, rec.observation);
      }
      return this.reply(r, error instanceof AHPPermissionError ? "PERMISSION_REQUIRED" : this.errorState(error), null, error instanceof AHPPermissionError ? error.message : "Native route unavailable; raw connection errors omitted.");
    } finally {
      this.execution.delete(executionKey);
    }
  }
  initialObservation(p, c, state) {
    return { schema: "datapass.agent-host-observation/1", handleId: p.handleId, taskId: p.binding.taskId, roleId: p.binding.roleId, preparedHash: p.preparedHash, scopeHash: p.scopeHash, hostId: p.hostId, hostIdentityHash: p.hostIdentityHash, protocolVersion: p.protocolVersion, provider: p.binding.provider, root: p.binding.root, revision: p.binding.revision, promptHash: p.binding.promptHash, sessionId: null, chatId: null, turnId: null, state, resultText: "", resultHash: ahpTextHash(""), requestedModel: p.binding.requestedModel, requestedEffort: p.binding.requestedEffort ?? null, observedModel: null, observedEffort: null, lastServerSeq: 0, capturedAt: (/* @__PURE__ */ new Date()).toISOString(), evidence: c.descriptor.host.kind === "SYNTHETIC" ? "SYNTHETIC" : "NATIVE_AHP_OBSERVED", message: "Prepared ordinary task; no native session created or prompt sent.", acceptedTaskCompletion: false, ...p.permissionReview ? { executionPolicyHash: p.permissionReview.policyHash, permissionReview: structuredClone(p.permissionReview) } : {} };
  }
  sessionMatches(rec, s2) {
    return !!s2 && s2.provider === rec.observation.provider && s2.workingDirectories?.length === 1 && s2.workingDirectories[0] === (0, import_node_url.pathToFileURL)(rec.observation.root).href;
  }
  chatMatches(rec, s2) {
    return !!s2 && s2.resource === rec.observation.chatId && (!s2.workingDirectories || s2.workingDirectories.length === 1 && s2.workingDirectories[0] === (0, import_node_url.pathToFileURL)(rec.observation.root).href);
  }
  async readySession(c, id) {
    const until = Date.now() + 5e3;
    while (c.active && c.descriptor.authorized() && Date.now() < until) {
      const s2 = c.sessions.get(id);
      if (s2?.lifecycle === "ready") return s2;
      if (s2?.lifecycle === "failed") throw Error("AHP_FAILED");
      await new Promise((resolve9) => setTimeout(resolve9, 20));
    }
    throw Error("Host startup disappeared");
  }
  async project(c, rec, env) {
    if (!this.authorized(rec.request, rec.prepared.binding) || !await this.services.verifySource(rec.prepared.binding, rec.request)) {
      this.transition(rec, "DENIED", "Source permission, root or revision changed during observation.");
      return;
    }
    const o = rec.observation, s2 = c.sessions.get(o.sessionId), chat = c.chats.get(o.chatId);
    if (!s2 || !this.sessionMatches(rec, s2) || chat && !this.chatMatches(rec, chat)) {
      this.transition(rec, "DENIED", "Host session/root/provider binding changed.");
      return;
    }
    if (rec.prepared.binding.executionPolicy) {
      try {
        this.verifySessionPolicy(c, rec);
      } catch (error) {
        this.transition(rec, "PERMISSION_REQUIRED", error instanceof Error ? error.message : "Permission enforcement is unknown.");
        return;
      }
    }
    if (!chat) return;
    const turn = [...chat.turns, chat.activeTurn].filter((t) => t?.id === o.turnId);
    if (turn.length > 1) {
      this.transition(rec, "DENIED", "Ambiguous native turn identity.");
      return;
    }
    if (!turn.length) return;
    const selected = turn[0];
    if (ahpTextHash(selected.message.text) !== o.promptHash) {
      this.transition(rec, "DENIED", "Observed prompt differs from durable task.");
      return;
    }
    const parts = selected.responseParts ?? [];
    if (parts.length > 2e3) throw Error("Response part bound exceeded");
    const text = bounded(parts.filter((p) => p.kind === "markdown").map((p) => p.content.slice(0, 16384)).join("").slice(0, 16384), 12e3);
    let state = "RUNNING";
    const done = chat.turns.find((t) => t.id === o.turnId);
    if (done) state = done.state === "complete" ? "COMPLETED" : done.state === "cancelled" ? "STOPPED" : "FAILED";
    else if (parts.some((p) => p.kind === "toolCall" && p.toolCall.status === "auth-required")) state = "AUTH_REQUIRED";
    else if (parts.some((p) => p.kind === "toolCall" && ["pending-confirmation", "pending-result-confirmation"].includes(p.toolCall.status)) || parts.some((p) => p.kind === "inputRequest")) state = "PERMISSION_REQUIRED";
    rec.observation = { ...o, resultText: text, resultHash: ahpTextHash(text), state, observedModel: null, observedEffort: null, lastServerSeq: Math.max(o.lastServerSeq, env?.serverSeq ?? c.seq.get(o.chatId) ?? 0), capturedAt: (/* @__PURE__ */ new Date()).toISOString(), message: state === "PERMISSION_REQUIRED" ? "Resolve native tool/input permission in the owning host. No automatic approval." : state === "COMPLETED" ? "Native turn completed; effective model/effort remain unknown; PM task acceptance remains separate." : "" };
    await this.persist(rec);
    this.emit(rec.observation);
  }
  async observe(r, id, recover) {
    const rec = this.records.get(id);
    if (this.corrupt || !rec || !this.authorized(r, rec.prepared.binding) || rec.observation.scopeHash !== ahpHash(r.scope) || !await this.services.verifySource(rec.prepared.binding, rec.request)) return this.reply(r, "DENIED", null, "Owned durable task and renewed source scope required.");
    if (recover) {
      rec.request = structuredClone(r);
      const h = this.hosts.get(rec.observation.hostId);
      if (!h?.authorized() || h.host.identityHash !== rec.observation.hostIdentityHash) return this.reply(r, "UNAVAILABLE", rec.observation, "No reviewed connection authority for this exact host; its liveness is unknown. Review the same host connection again; endpoint secrets are never persisted.");
      try {
        const c = await this.connect(h);
        if (c.protocolVersion !== rec.observation.protocolVersion || ahpHash(this.inventory(c)) !== rec.prepared.inventoryHash) return this.reply(r, "PROTOCOL_UNSUPPORTED", rec.observation, "Recovered host protocol/capability differs.");
        if (rec.observation.sessionId) {
          const sub = await c.client.subscribe(rec.observation.sessionId);
          if (!sub.result.snapshot) throw Error("Missing session snapshot");
          this.snapshot(c, sub.result.snapshot);
          const s2 = c.sessions.get(rec.observation.sessionId);
          if (!this.sessionMatches(rec, s2)) throw Error("DENIED");
          if (!rec.observation.chatId && safeUri(s2.defaultChat, "chat")) {
            rec.observation.chatId = s2.defaultChat;
            await this.persist(rec);
          }
          if (rec.observation.chatId) {
            const chat = await c.client.subscribe(rec.observation.chatId);
            if (!chat.result.snapshot) throw Error("Missing chat snapshot");
            this.snapshot(c, chat.result.snapshot);
            await this.project(c, rec);
          }
        }
      } catch {
        this.transition(rec, "UNCERTAIN", "Recovery unavailable; no session creation or prompt resend.");
        await this.writes;
      }
    }
    return this.reply(r, rec.observation.state, rec.observation);
  }
  async cancel(r, id) {
    const rec = this.records.get(id);
    if (!rec || !this.authorized(r, rec.prepared.binding) || !await this.services.verifySource(rec.prepared.binding, rec.request)) return this.reply(r, "DENIED", null);
    const c = this.connections.get(rec.observation.hostId);
    if (!c?.active || !c.descriptor.authorized() || !rec.observation.chatId || !rec.observation.turnId || !["RUNNING", "PERMISSION_REQUIRED", "AUTH_REQUIRED"].includes(rec.observation.state)) return this.reply(r, "UNAVAILABLE", rec.observation, "Only an owned observed active turn can be cancelled.");
    try {
      c.client.dispatch(rec.observation.chatId, { type: c.sdk[0].ActionType.ChatTurnCancelled, turnId: rec.observation.turnId, duration: 0 });
      return this.reply(r, rec.observation.state, rec.observation, "Cancellation requested; native acknowledgement remains pending.");
    } catch {
      return this.reply(r, "UNCERTAIN", rec.observation, "Cancellation uncertain.");
    }
  }
  subscribe(r, id, listener) {
    const rec = this.records.get(id);
    if (!rec || !this.authorized(r, rec.prepared.binding) || typeof listener !== "function" || this.listeners.size >= 100) return { dispose() {
    } };
    const entry = { request: structuredClone(r), handleId: id, listener };
    this.listeners.add(entry);
    return { dispose: () => this.listeners.delete(entry) };
  }
  revoke() {
    this.sourceGrants.clear();
    this.reviewedRoots.clear();
    this.reviewedBindings.clear();
    this.hosts.clear();
    for (const c of this.connections.values()) void c.client.shutdown();
    this.connections.clear();
    this.prepared.clear();
    this.listeners.clear();
  }
  async dispose() {
    for (const c of this.connections.values()) await c.client.shutdown();
    this.listeners.clear();
    await this.writes;
  }
};

// src/provider-kit/agentHostEndpoint.ts
var fs12 = __toESM(require("node:fs/promises"));
var path13 = __toESM(require("node:path"));
var import_node_crypto8 = require("node:crypto");
var net = __toESM(require("node:net"));

// node_modules/ws/wrapper.mjs
var import_stream = __toESM(require_stream(), 1);
var import_extension = __toESM(require_extension(), 1);
var import_permessage_deflate = __toESM(require_permessage_deflate(), 1);
var import_receiver = __toESM(require_receiver(), 1);
var import_sender = __toESM(require_sender(), 1);
var import_subprotocol = __toESM(require_subprotocol(), 1);
var import_websocket = __toESM(require_websocket(), 1);
var import_websocket_server = __toESM(require_websocket_server(), 1);

// src/provider-kit/agentHostEndpoint.ts
var digest2 = (s2) => (0, import_node_crypto8.createHash)("sha256").update(s2).digest("hex");
function validateSelectedEndpoint(value, file, userData, pidAlive) {
  const e = value;
  if (!e || e.schemaVersion !== 2 || !["editor", "standalone"].includes(e.type) || !Number.isSafeInteger(e.pid) || e.pid < 1 || !pidAlive(e.pid) || !/^[a-zA-Z0-9_-]{8,160}$/.test(e.instanceId) || !/^[a-zA-Z0-9_-]{16,512}$/.test(e.connectionToken) || !/^\d+\.\d+\.\d+$/.test(e.protocolVersion)) return false;
  const expected = path13.join(userData, "agent-host", "local-endpoint", "entries", digest2(`${e.type}\0${e.pid}\0${e.instanceId}`) + ".json");
  if (path13.resolve(file) !== path13.resolve(expected)) return false;
  if (e.endpoint?.type === "socket") return typeof e.endpoint.path === "string" && e.endpoint.path.length <= 512 && !/[\x00-\x1f]/.test(e.endpoint.path) && (process.platform === "win32" ? /^\\\\\.\\pipe\\vscode-agent-host-[a-zA-Z0-9_-]+$/.test(e.endpoint.path) : path13.isAbsolute(e.endpoint.path) && e.endpoint.path.endsWith(".sock"));
  return e.type === "standalone" && e.endpoint?.type === "tcp" && ["127.0.0.1", "::1", "localhost"].includes(e.endpoint.host) && Number.isSafeInteger(e.endpoint.port) && e.endpoint.port > 0 && e.endpoint.port < 65536;
}
var alive = (pid) => {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
};
async function selectedEndpointHost(input) {
  if (!input.authorized() || !isPlausibleLocalPath(input.file) || !isPlausibleLocalPath(input.userData) || hasLinkedAncestor(input.file) || hasLinkedAncestor(input.userData)) throw Error("Selected endpoint access denied.");
  const stat4 = await fs12.lstat(input.file);
  if (!stat4.isFile() || stat4.size > 8192 || process.platform !== "win32" && (stat4.mode & 63) !== 0) throw Error("Unsafe endpoint metadata.");
  const bytes = await fs12.readFile(input.file, "utf8");
  if (!input.authorized()) throw Error("Selected endpoint access revoked.");
  const entry = JSON.parse(bytes);
  if (!validateSelectedEndpoint(entry, input.file, input.userData, alive)) throw Error("Selected endpoint metadata invalid or stale.");
  const identityHash = ahpHash({ type: entry.type, pid: entry.pid, instanceId: entry.instanceId, userData: path13.resolve(input.userData), endpoint: entry.endpoint });
  return {
    host: { hostId: "ahp-host:" + identityHash.slice(0, 32), kind: entry.type === "editor" ? "VSCODE_AGENT_HOST" : "STANDALONE_AGENT_HOST", label: entry.type === "editor" ? "Reviewed VS Code editor host" : "Reviewed standalone host (separate session authority)", protocolVersion: entry.protocolVersion, connectionState: "UNAVAILABLE", identityHash },
    scopeHash: input.scopeHash,
    root: input.root,
    revision: input.revision,
    authorized: input.authorized,
    open: async () => {
      if (!input.authorized() || hasLinkedAncestor(input.file) || !alive(entry.pid)) throw Error("DENIED");
      const current = await fs12.readFile(input.file, "utf8");
      if (current !== bytes || !input.authorized()) throw Error("DENIED");
      return connectEndpoint(entry, input.authorized);
    }
  };
}
async function connectEndpoint(entry, authorized) {
  if (!authorized()) throw Error("DENIED");
  const query = "/?tkn=" + encodeURIComponent(entry.connectionToken);
  const url = entry.endpoint.type === "tcp" ? `ws://${entry.endpoint.host === "::1" ? "[::1]" : entry.endpoint.host}:${entry.endpoint.port}${query}` : "ws://localhost" + query;
  const socket = entry.endpoint.type === "socket" ? entry.endpoint.path : null;
  return new Promise((resolve9, reject) => {
    const ws = new import_websocket.default(url, { handshakeTimeout: 5e3, maxPayload: 2 * 1024 * 1024, perMessageDeflate: false, ...socket ? { createConnection: () => net.createConnection(socket) } : {} });
    const queue = [];
    const waiters = [];
    let closed = false;
    const end = () => {
      closed = true;
      while (waiters.length) waiters.shift()(null);
    };
    ws.on("message", (data, isBinary) => {
      if (!authorized() || queue.length >= 512) {
        ws.close();
        end();
        return;
      }
      const text = data.toString();
      try {
        JSON.parse(text);
      } catch {
        ws.close();
        end();
        return;
      }
      const frame = isBinary ? { kind: "binary", data: new Uint8Array(Buffer.isBuffer(data) ? data : Buffer.from(data)) } : { kind: "text", text };
      const waiter = waiters.shift();
      if (waiter) waiter(frame);
      else queue.push(frame);
    });
    ws.on("close", end);
    ws.on("error", () => {
      end();
      reject(Error("Local AHP connection unavailable."));
    });
    ws.on("unexpected-response", (_request, response) => {
      end();
      response.destroy();
      reject(Error(response.statusCode === 403 ? "AUTH_REQUIRED" : "Local AHP connection unavailable."));
      ws.terminate();
    });
    ws.once("open", () => {
      if (!authorized()) {
        ws.close();
        reject(Error("DENIED"));
        return;
      }
      resolve9({ send(message) {
        if (!authorized() || closed || ws.readyState !== import_websocket.default.OPEN) throw Error("Connection closed.");
        ws.send(typeof message === "string" ? message : JSON.stringify(message));
      }, recv() {
        if (queue.length) return Promise.resolve(queue.shift());
        if (closed) return Promise.resolve(null);
        return new Promise((resolve10) => waiters.push(resolve10));
      }, close() {
        ws.close();
        end();
      } });
    });
  });
}

// src/provider-kit/agentHostProject.ts
var import_node_child_process3 = require("node:child_process");
var fs13 = __toESM(require("node:fs/promises"));
var path14 = __toESM(require("node:path"));
var import_node_crypto9 = require("node:crypto");
async function verifyAHPProject(binding, approvedRepoIds) {
  try {
    const root = binding.root;
    if (!isPlausibleLocalPath(root) || hasLinkedAncestor(root) || !(await fs13.lstat(root)).isDirectory()) return false;
    const git = resolveExe("git");
    if (!git) return false;
    const env = { GIT_TERMINAL_PROMPT: "0" };
    for (const key of ["PATH", "Path", "SystemRoot"]) if (process.env[key]) env[key] = process.env[key];
    const read = (args) => new Promise((resolve9, reject) => (0, import_node_child_process3.execFile)(git, [...HARDEN, "-c", "core.hooksPath=NUL", ...args], { cwd: root, env, shell: false, windowsHide: true, timeout: 1e4, maxBuffer: 16384 }, (e, out) => e ? reject(Error("Source unavailable")) : resolve9(out.toString().trim())));
    const [observed, revision, remoteNames] = await Promise.all([read(["rev-parse", "--show-toplevel"]), read(["rev-parse", "HEAD"]), read(["remote"])]);
    const canonical = (s2) => process.platform === "win32" ? path14.resolve(s2).toLowerCase() : path14.resolve(s2);
    const realRoot = await fs13.realpath(observed);
    if (canonical(realRoot) !== canonical(root) || revision !== binding.revision) return false;
    if (!approvedRepoIds?.length) return false;
    const names = remoteNames.split("\n").filter(Boolean);
    if (names.length > 32) return false;
    const identities = [];
    for (const name2 of names) {
      if (!/^[a-zA-Z0-9._-]{1,160}$/.test(name2)) return false;
      const remote = await read(["remote", "get-url", name2]);
      const match = /^(?:https:\/\/|git@)(github\.com|gitlab\.com)(?:\/|:)([a-zA-Z0-9_.-]+\/[a-zA-Z0-9_.-]+?)(?:\.git)?\/?$/.exec(remote);
      if (match) identities.push(match[2].toLowerCase());
    }
    const normalized = process.platform === "win32" ? realRoot.replace(/\\/g, "/").toLowerCase() : realRoot;
    const local = "local:" + (0, import_node_crypto9.createHash)("sha256").update(normalized).digest("hex");
    return approvedRepoIds.some((id) => id === repoId(realRoot) || identities.includes(id.toLowerCase()) || !identities.length && id === local);
  } catch {
    return false;
  }
}

// src/provider-kit/index.ts
var providerKitVersion = "1.2.0";
var providerKitSchema = "datapass.provider-kit-capture/1";
async function captureConfiguration(input) {
  if (!input || !["codex", "claude"].includes(input.provider) || !["CLI", "Desktop", "IDE", "API"].includes(input.surface) || !/^[a-f0-9]{64}$/.test(input.policyHash) || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(input.hostId) || !Array.isArray(input.roots) || input.roots.length > 60 || input.roots.some((r) => !isPlausibleLocalPath(r) || hasLinkedAncestor(r)) || !input.homes || ![input.homes.codexHome, input.homes.claudeHome, input.homes.managedFile].every(isPlausibleLocalPath) || [input.nativeVersion, input.accountId].some((v) => v !== null && (typeof v !== "string" || !/^[a-zA-Z0-9._:/-]{1,160}$/.test(v)))) throw new Error("Invalid reviewed capture selection.");
  const selection = structuredClone(input);
  const read = await collectConfiguration(selection, selection.provider, [], selection.homes);
  const capturedAt = new Date(read.at).toISOString();
  const identity = { provider: selection.provider, surface: selection.surface, nativeVersion: selection.nativeVersion, hostId: selection.hostId, accountId: selection.accountId };
  const sourceRefs = [...read.sources.keys()].map((id) => ({ id, kind: "LOCAL_FILE", observedAt: capturedAt }));
  const configuration = read.config;
  const hashConfig = structuredClone(configuration);
  for (const fact of Object.values(hashConfig.effective)) delete fact.observedAt;
  return {
    schema: providerKitSchema,
    kitVersion: providerKitVersion,
    capturedAt,
    sourceHash: sha256(canonicalJson({ identity, configuration: hashConfig, sources: sourceRefs.map((s2) => s2.id), policyHash: selection.policyHash })),
    identity,
    configuration,
    sourceRefs,
    omissions: [
      "Safe observed projection hash; not an exact-byte backup of native files.",
      "CLI overrides, managed native resolution and session-effective state remain PARTIAL.",
      "No auth files, environment values, hook payloads, MCP args/URLs/headers or instruction content.",
      "Installed/configured does not prove authentication or tool usability.",
      "No history reader, provider task launch, config apply or CLI execution."
    ]
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AgentHostAdapter,
  NativeTaskRunner,
  NativeTransportFacade,
  ahpHash,
  ahpTextHash,
  captureConfiguration,
  captureNativeStartupManifest,
  createHeadlessNativeHost,
  defaultHomes,
  hashOk,
  mafActionHash,
  mafRuntimeHash,
  nativeEnvironment,
  nativeHash,
  nativeIdOk,
  nativeLaunchArguments,
  nativeSelectionBinding,
  nativeStartupReviewHash,
  nativeToolPolicy,
  nativeTransportVersion,
  preflightNativeTransport,
  prepareNativeTask,
  providerKitSchema,
  providerKitVersion,
  qualifiedAHPEfforts,
  readNativeRepositoryIdentity,
  safeLocalSource,
  selectedEndpointHost,
  validateMafAction,
  validateNativePlatformVerifier,
  validateNativeSelection,
  validateSelectedEndpoint,
  verifyAHPProject,
  verifyMafRuntime,
  verifyNativePlatformProof,
  verifyNativeProjectScope
});

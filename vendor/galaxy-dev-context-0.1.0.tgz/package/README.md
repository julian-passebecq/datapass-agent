# Development context

`galaxy.dev-context/1` describes the object being inspected. It is a small optional-field
navigation pointer, not shared state. The canonical source is `src/core/context.ts`.
Run `node scripts/build-context.mjs` at the Lens root, then pack this directory.
Agent consumes this package; T3's generated browser module comes from the same source.
Regenerate consumers together when changing the version or validation semantics.

Inputs are bounded to 16 KiB. Relative files cannot escape their checkout; remote URLs
cannot contain credentials. Consumers independently verify existence and freshness.
`contextForLens` adapts this pointer to the predecessor Lens handoff contract, retaining
its exact repository/worktree/revision resolution and explicit stale result.
